prompt *** Uninstalling OOS_UTILS ***



prompt *** TABLES ***

prompt oos_util_values
drop table oos_util_values;


prompt *** PACKAGES ***

prompt oos_util
drop package oos_util;

prompt oos_util_apex
drop package oos_util_apex;

prompt oos_util_bit
drop package oos_util_bit;

prompt oos_util_crypto
drop package oos_util_crypto;

prompt oos_util_date
drop package oos_util_date;

prompt oos_util_lob
drop package oos_util_lob;

prompt oos_util_string
drop package oos_util_string;

prompt oos_util_totp
drop package oos_util_totp;

prompt oos_util_validation
drop package oos_util_validation;

prompt oos_util_web
drop package oos_util_web;

