#! /bin/bash
. ${1}/.bash_profile
find ${2}/${3}-* -type d -ctime +${4} 2> /dev/null -exec rm -rf {} \;
exit 0

