#! /bin/bash
. ${1}/.bash_profile
cd $2 2> /dev/null
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo "NO"
    exit 0
fi
touch touched
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo "NO"
    exit 0
else
    rm touched
    echo "YES"
    exit 0
fi
