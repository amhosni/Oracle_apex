#include <stdio.h>
#include <string.h>
int main( int argc, char *argv[] ){
    setuid(0);
    clearenv();
    char str1[220] = "/bin/chmod 770 ";
    char str2[200];
    strcpy(str2, argv[1]);
    system(strcat(str1, str2));
}
