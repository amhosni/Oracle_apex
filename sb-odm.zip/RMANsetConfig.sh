#! /bin/bash
. ${1}/.bash_profile
echo "RUN" > ${2}/RMANsetConfig.rman
echo "{" >> ${2}/RMANsetConfig.rman
rman target / @${2}/RMANshowAllConfig.rman | grep CONFIGURE >> ${2}/RMANsetConfig.rman
rman_exit_code=$?
if [ $rman_exit_code -ne 0 ]; then
    echo "RMANshowAllConfig.rman failed" >> ${2}/RMANsetConfig.log
    exit 1
fi
echo "}" >> ${2}/RMANsetConfig.rman
rman target / @${2}/RMANsetConfig.rman >> ${2}/RMANsetConfig.log
rman_exit_code=$?
if [ $rman_exit_code -ne 0 ]; then
    echo "RMANsetConfig.rman failed" >> ${2}/RMANsetConfig.log
    exit 1
fi
rm ${2}/RMANsetConfig.rman
rm ${2}/RMANsetConfig.log
exit 0

