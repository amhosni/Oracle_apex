#! /bin/bash
/bin/df -Ph 2> /dev/null | grep '%'
exit 0

