#! /bin/sh

cd /home/${1}

mkdir apex
mkdir backup
mkdir backupcopies
mkdir datapump
mkdir logs
mkdir scripts

chown $1 apex backup backupcopies datapump logs scripts

chgrp dba apex backup backupcopies datapump logs scripts

chmod 770 apex backup backupcopies datapump logs scripts

mv RMANsetConfig.sh scripts
mv RMANshowAllConfig.sh scripts
mv RMANshowAllConfig.rman scripts
mv testDirectoryWritable.sh scripts
mv deleteAPEXexports.sh scripts
mv dfCommand.sh scripts
mv SBODM210-CDB-USER.sql scripts
mv SBODM210-NON-CDB-USER.sql scripts


chown $1 scripts/*

chgrp $1 scripts/*

chmod 770 scripts/*

chmod 660 scripts/RMANshowAllConfig.rman

mv SBAHELP.dmp datapump

chown $1 datapump/*

chgrp dba datapump/*

chmod 770 datapump/*


