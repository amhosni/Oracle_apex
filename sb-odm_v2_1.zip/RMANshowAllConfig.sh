#! /bin/bash
. ${1}/.bash_profile
rman target / @${2}/RMANshowAllConfig.rman
rman_exit_code=$?
if [ $rman_exit_code -ne 0 ]; then
    exit 1
fi
exit 0