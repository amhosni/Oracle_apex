SPOOL SBODM210-NON-CDB-USER.log

SET ECHO ON
SET VERIFY OFF
SET SQLBLANKLINES ON
SET DEFINE ON

WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK

PROMPT Creating User

CREATE USER &&USERNAME IDENTIFIED BY &&PASSWORD;

PROMPT Granting Roles

GRANT DBA TO &&USERNAME;
GRANT SYSDBA TO &&USERNAME;
GRANT APEX_ADMINISTRATOR_ROLE TO &&USERNAME;

PROMPT Granting System Privileges

GRANT ALTER ANY INDEX TO &&USERNAME;
GRANT ALTER ANY PROCEDURE TO &&USERNAME;
GRANT ALTER ANY TABLE TO &&USERNAME;
GRANT ALTER ANY TRIGGER TO &&USERNAME;
GRANT ALTER DATABASE TO &&USERNAME;
GRANT ALTER SYSTEM TO &&USERNAME;
GRANT ALTER TABLESPACE TO &&USERNAME;
GRANT ALTER USER TO &&USERNAME;
GRANT CREATE ANY CONTEXT TO &&USERNAME;
GRANT CREATE ANY DIRECTORY TO &&USERNAME;
GRANT CREATE CLUSTER TO &&USERNAME;
GRANT CREATE DIMENSION TO &&USERNAME;
GRANT CREATE EXTERNAL JOB TO &&USERNAME;
GRANT CREATE INDEXTYPE TO &&USERNAME;
GRANT CREATE JOB TO &&USERNAME;
GRANT CREATE MATERIALIZED VIEW TO &&USERNAME;
GRANT CREATE OPERATOR TO &&USERNAME;
GRANT CREATE PROCEDURE TO &&USERNAME;
GRANT CREATE SEQUENCE TO &&USERNAME;
GRANT CREATE SESSION TO &&USERNAME;
GRANT CREATE SYNONYM TO &&USERNAME;
GRANT CREATE TABLE TO &&USERNAME;
GRANT CREATE TABLESPACE TO &&USERNAME;
GRANT CREATE TRIGGER TO &&USERNAME;
GRANT CREATE TYPE TO &&USERNAME;
GRANT CREATE USER TO &&USERNAME;
GRANT CREATE VIEW TO &&USERNAME;
GRANT CREATE DATABASE LINK TO &&USERNAME;
GRANT CREATE CREDENTIAL TO &&USERNAME;
GRANT DROP ANY DIRECTORY TO &&USERNAME;
GRANT DROP TABLESPACE TO &&USERNAME;
GRANT GRANT ANY PRIVILEGE TO &&USERNAME;
GRANT GRANT ANY ROLE TO &&USERNAME;
GRANT ADVISOR TO &&USERNAME;

PROMPT Granting Object Privileges

GRANT SELECT ON DBA_DATA_FILES TO &&USERNAME;
GRANT SELECT ON DBA_DIRECTORIES TO &&USERNAME;
GRANT SELECT ON DBA_FREE_SPACE TO &&USERNAME;
GRANT SELECT ON DBA_ROLE_PRIVS TO &&USERNAME;
GRANT SELECT ON DBA_SCHEDULER_JOB_RUN_DETAILS TO &&USERNAME;
GRANT SELECT ON DBA_SCHEDULER_JOBS TO &&USERNAME;
GRANT SELECT ON DBA_SEGMENTS TO &&USERNAME;
GRANT SELECT ON DBA_SYS_PRIVS TO &&USERNAME;
GRANT SELECT ON DBA_TABLESPACES TO &&USERNAME;
GRANT SELECT ON DBA_TEMP_FILES TO &&USERNAME;
GRANT SELECT ON DBA_USERS TO &&USERNAME;
GRANT SELECT ON V_$ASM_DISKGROUP TO &&USERNAME;
GRANT SELECT ON V_$BACKUP_FILES TO &&USERNAME;
GRANT SELECT ON V_$BACKUP_PIECE_DETAILS TO &&USERNAME;
GRANT SELECT ON V_$BACKUP_SET TO &&USERNAME;
GRANT SELECT ON V_$DATABASE TO &&USERNAME;
GRANT SELECT ON V_$DATAFILE TO &&USERNAME;
GRANT SELECT ON V_$DIAG_ALERT_EXT TO &&USERNAME;
GRANT SELECT ON V_$DIAG_DIR_EXT TO &&USERNAME;
GRANT SELECT ON V_$INSTANCE TO &&USERNAME;
GRANT SELECT ON V_$OSSTAT TO &&USERNAME;
GRANT SELECT ON V_$PARAMETER TO &&USERNAME;
GRANT SELECT ON V_$RECOVERY_AREA_USAGE TO &&USERNAME;
GRANT SELECT ON V_$RMAN_CONFIGURATION TO &&USERNAME;
GRANT SELECT ON V_$TABLESPACE TO &&USERNAME;
GRANT SELECT ON V_$TEMPFILE TO &&USERNAME;
GRANT EXECUTE ON DBMS_AQ TO &&USERNAME;
GRANT EXECUTE ON DBMS_AQADM TO &&USERNAME;
GRANT EXECUTE ON DBMS_BACKUP_RESTORE TO &&USERNAME;
GRANT EXECUTE ON DBMS_LOCK TO &&USERNAME;
GRANT EXECUTE ON DBMS_SERVER_ALERT TO &&USERNAME;
GRANT EXECUTE ON DBMS_SCHEDULER TO &&USERNAME;
GRANT EXECUTE ON DBMS_RANDOM TO &&USERNAME;
GRANT EXECUTE ON DBMS_UTILITY TO &&USERNAME;
GRANT EXECUTE ON APEX_INSTANCE_ADMIN TO &&USERNAME;
GRANT EXECUTE ON UTL_FILE TO &&USERNAME;
GRANT EXECUTE ON DBMS_ADVISOR TO &&USERNAME;

-- PROMPT System Alert Queue

BEGIN
   -- Remove subscriber
   BEGIN
      DBMS_AQADM.REMOVE_SUBSCRIBER(queue_name=>'SYS.ALERT_QUE', subscriber => SYS.AQ$_AGENT('ALERTAGENT','',0));
   EXCEPTION
      WHEN OTHERS THEN NULL;
   END;
   -- Drop Agent
   BEGIN
      DBMS_AQADM.DROP_AQ_AGENT(agent_name=> 'ALERTAGENT');
   EXCEPTION
      WHEN OTHERS THEN NULL;
   END;
   -- create a queue agent
   DBMS_AQADM.CREATE_AQ_AGENT(agent_name => 'ALERTAGENT');
   -- subscribe to alert_que
   DBMS_AQADM.ADD_SUBSCRIBER(queue_name => 'SYS.ALERT_QUE', subscriber => SYS.AQ$_AGENT('ALERTAGENT','',0));
   -- associate schema user with the secure queue
   DBMS_AQADM.ENABLE_DB_ACCESS(agent_name => 'ALERTAGENT', db_username => '&&USERNAME');
   -- grant queue privilege NOTE: This has to be done as user SYS
   DBMS_AQADM.GRANT_QUEUE_PRIVILEGE(privilege => 'DEQUEUE',queue_name => 'SYS.ALERT_QUE',grantee => '&&USERNAME', grant_option => FALSE);
   -- register queue callback procedure
   DBMS_AQ.REGISTER(SYS.AQ$_REG_INFO_LIST(SYS.AQ$_REG_INFO('SYS.ALERT_QUE:ALERTAGENT',
                                                           DBMS_AQ.NAMESPACE_AQ,
                                                           'plsql://'||LOWER('&&USERNAME')||'.aca_dequeue_alert_event',
                                                           HEXTORAW('FF'))), 1 );
END;
/

-- PROMPT  Configuring ASM

PROMPT If you want to manage Automatic Storage Management (ASM) enter the ASM host name and port number. If not, just press ENTER at the prompts.
ACCEPT ASMHOST CHAR DEFAULT 'NULL' PROMPT 'Enter the ASM host name >'
ACCEPT ASMPORT CHAR DEFAULT 'NULL' PROMPT 'Enter the ASM port number >'

BEGIN
   IF '&&ASMHOST' != 'NULL' AND '&&ASMPORT' != 'NULL' THEN
      DBMS_JAVA.GRANT_PERMISSION(UPPER('&&USERNAME'), 'SYS:java.net.SocketPermission', '&&ASMHOST', 'resolve');
      DBMS_JAVA.GRANT_PERMISSION(UPPER('&&USERNAME'), 'SYS:java.net.SocketPermission', '&&ASMHOST:&&ASMPORT', 'connect,resolve');
   END IF;
END;
/

COMMIT;

---------------------------------------------------------------------------------------------------------------------------------------------

PROMPT Loading SB-ODM user objects.
ACCEPT DBHOST CHAR PROMPT 'Enter the database SQL*Net hostname or ip address >'
ACCEPT DBPORT CHAR PROMPT 'Enter the database SQL*Net port number >'
ACCEPT DBSID CHAR PROMPT  'Enter the database SQL*Net service name >'

CONNECT &&USERNAME/&&PASSWORD@&&DBHOST:&&DBPORT/&&DBSID

SET DEFINE OFF

-- GL Added Java code manually

CREATE AND RESOLVE JAVA SOURCE NAMED ANY_DML_DDL
AS import java.sql.*;
class any_dml_ddl {
  public static void main (String[] args) throws Exception
  {
   Class.forName ("oracle.jdbc.OracleDriver");
   Connection conn = DriverManager.getConnection
     (args[2], args[0], args[1]);
     Statement stmt = conn.createStatement();
       stmt.executeUpdate(args[3]);
  }
}
/

CREATE AND RESOLVE JAVA SOURCE NAMED QUERYASM
AS
import java.sql.*;
class queryasm {
  public static void main (String[] args) throws Exception
  {
   Class.forName ("oracle.jdbc.OracleDriver");
   Connection conn = DriverManager.getConnection(args[2], args[0], args[1]);
   Connection lconn = DriverManager.getConnection("jdbc:default:connection:");
   String sql = "INSERT INTO aca_any_result(col1,col2,col3,col4,col5,col6,col7,col8,col9,col10,col11,col12,col13,col14,col15,col16,col17,col18,col19,col20,report_name, session_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   try {
     Statement stmt = conn.createStatement();
     try {
       ResultSet rset = stmt.executeQuery(args[3]);
       try {
         String col1  = "";String col2  = "";String col3  = "";String col4  = "";
         String col5  = "";String col6  = "";String col7  = "";String col8  = "";
         String col9  = "";String col10 = "";String col11 = "";String col12 = "";
         String col13 = "";String col14 = "";String col15 = "";String col16 = "";
         String col17 = "";String col18 = "";String col19 = "";String col20 = "";
         while (rset.next()) {
           col1 = rset.getString(1);col2 = rset.getString(2);col3 = rset.getString(3);col4 = rset.getString(4);
           col5 = rset.getString(5);col6 = rset.getString(6);col7 = rset.getString(7);col8 = rset.getString(8);
           col9 = rset.getString(9);col10 = rset.getString(10);col11 = rset.getString(11);col12 = rset.getString(12);
           col13 = rset.getString(13);col14 = rset.getString(14);col15 = rset.getString(15);col16 = rset.getString(16);
           col17 = rset.getString(17);col18 = rset.getString(18);col19 = rset.getString(19);col20 = rset.getString(20);
           // System.out.println (rset.getString(1) + "  " + rset.getString(2));
           String report_name = args[4];
           String session_id = args[5];
           PreparedStatement pstmt = lconn.prepareStatement(sql);
           pstmt.setString(1, col1);
           pstmt.setString(2, col2);
           pstmt.setString(3, col3);
           pstmt.setString(4, col4);
           pstmt.setString(5, col5);
           pstmt.setString(6, col6);
           pstmt.setString(7, col7);
           pstmt.setString(8, col8);
           pstmt.setString(9, col9);
           pstmt.setString(10, col10);
           pstmt.setString(11, col11);
           pstmt.setString(12, col12);
           pstmt.setString(13, col13);
           pstmt.setString(14, col14);
           pstmt.setString(15, col15);
           pstmt.setString(16, col16);
           pstmt.setString(17, col17);
           pstmt.setString(18, col18);
           pstmt.setString(19, col19);
           pstmt.setString(20, col20);
           pstmt.setString(21, report_name);
           pstmt.setString(22, session_id);
           pstmt.executeUpdate();
           pstmt.close();
         }
       }
       finally {
          try { rset.close(); } catch (Exception ignore) {}
       }
     }
     finally {
       try { stmt.close(); } catch (Exception ignore) {}
     }
   }
   finally {
     try { conn.close(); } catch (Exception ignore) {}
   }
  }
}
/

---

CREATE TYPE list_collection_type AS TABLE OF VARCHAR2(4000);
/

CREATE OR REPLACE PACKAGE ACA_ALERT_UTIL IS
--
--
-- Copyright 2015 2016 2017 SkillBuilders Inc.
--
--
-- MODIFICATION HISTORY
-- Person                Date        Comments
-- --------------------  ----------  ------------------------------------------
-- Garry Lawton          08/29/2013  Creation
--
   PROCEDURE set_threshold (p_metrics_id IN BINARY_INTEGER,
                            p_warning_operator IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OPERATOR_GE,
                            p_warning_value IN VARCHAR2,
                            p_critical_operator IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OPERATOR_GE,
                            p_critical_value IN VARCHAR2,
                            p_observation_period IN BINARY_INTEGER DEFAULT 1,
                            p_consecutive_occurrences IN BINARY_INTEGER  DEFAULT 1,
                            p_instance_name IN VARCHAR2 DEFAULT NULL,
                            p_object_type IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OBJECT_TYPE_SYSTEM,
                            p_object_name IN VARCHAR2 DEFAULT NULL);
   PROCEDURE clear_threshold (p_metrics_id IN BINARY_INTEGER,
                              p_instance_name IN VARCHAR2 DEFAULT NULL,
                              p_object_type IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OBJECT_TYPE_SYSTEM,
                              p_object_name IN VARCHAR2 DEFAULT NULL);
   PROCEDURE get_threshold(p_metrics_id IN BINARY_INTEGER,
                           p_instance_name IN VARCHAR2 DEFAULT NULL,
                           p_object_type IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OBJECT_TYPE_SYSTEM,
                           p_object_name IN VARCHAR2 DEFAULT NULL);
END aca_alert_util;
/


CREATE OR REPLACE PACKAGE ACA_APEX_UTIL IS
   PROCEDURE export(p_name IN VARCHAR2);
   PROCEDURE schedule_export(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'APEX_EXPORT_TEMPLATE');
   PROCEDURE schedule_export_exe(p_id IN NUMBER,
                                 p_template_name IN VARCHAR2 DEFAULT 'APEX_EXPORT_EXE_TEMPLATE');
END aca_apex_util;
/


CREATE OR REPLACE PACKAGE ACA_ASM_UTIL IS
   PROCEDURE any_dml_ddl(p_stm IN VARCHAR2);
   PROCEDURE execute_query(p_report_name IN VARCHAR2,
                           p_collection_name IN VARCHAR2 DEFAULT NULL,
                           p_a1 IN VARCHAR2 DEFAULT NULL,
                           p_a2 IN VARCHAR2 DEFAULT NULL,
                           p_a3 IN VARCHAR2 DEFAULT NULL,
                           p_a4 IN VARCHAR2 DEFAULT NULL);
   FUNCTION get_report_column_count(p_report_id IN NUMBER) RETURN NUMBER;
   FUNCTION get_report_header(p_report_name IN VARCHAR2) RETURN VARCHAR2;
   PROCEDURE create_disk_group(p_name IN VARCHAR2,
                               p_redundancy IN VARCHAR2,
                               p_failure_group_type IN VARCHAR2,
                               p_disks IN VARCHAR2,
                               p_disks_fg1 IN VARCHAR2,
                               p_disks_fg2 IN VARCHAR2,
                               p_disks_fg3 IN VARCHAR2);
   PROCEDURE add_disk_to_group(p_name IN VARCHAR2,
                               p_failure_group IN VARCHAR2,
                               p_disk IN VARCHAR2);
   FUNCTION test_asm_settings(p_asm_hostname IN VARCHAR2,
                              p_asm_port IN VARCHAR2,
                              p_asm_sid IN VARCHAR2,
                              p_sysasm_user IN VARCHAR2,
                              p_sysasm_password IN VARCHAR2) RETURN VARCHAR2;
END aca_asm_util;
/


CREATE OR REPLACE PACKAGE ACA_BACKUP_UTIL IS
   PROCEDURE schedule_backup(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'BACKUP_TEMPLATE');
   PROCEDURE refresh_aca_backup_sets;
   FUNCTION maxpiecesize_set RETURN BOOLEAN;
END aca_backup_util;
/


CREATE OR REPLACE PACKAGE ACA_CLONE_UTIL IS
   PROCEDURE schedule_clone(p_id IN NUMBER,
                            p_template_name IN VARCHAR2 DEFAULT 'CLONE_TEMPLATE');
   PROCEDURE rewrite_command_file(p_name IN VARCHAR2);
END aca_clone_util;
/


CREATE OR REPLACE PACKAGE ACA_DATABASE_UTIL IS
   PROCEDURE reorg_objects(p_object_type IN VARCHAR2, p_object_list IN APEX_APPLICATION_GLOBAL.VC_ARR2);
   FUNCTION directory_exists(p_directory_name IN VARCHAR2) RETURN BOOLEAN;
   FUNCTION test_directory(p_name IN VARCHAR2) RETURN BOOLEAN;
   PROCEDURE create_directory(p_name IN VARCHAR2, p_path IN VARCHAR2);
   PROCEDURE drop_directory(p_name IN VARCHAR2);
   PROCEDURE create_app_datapump_dir;
   FUNCTION user_exists(p_username IN VARCHAR2) RETURN BOOLEAN;
   PROCEDURE create_user(p_username IN VARCHAR2,
                         p_password IN VARCHAR2,
                         p_password_expired IN VARCHAR2,
                         p_account_locked IN VARCHAR2,
                         p_default_tablespace IN VARCHAR2,
                         p_temporary_tablespace IN VARCHAR2);
   PROCEDURE alter_user(p_username IN VARCHAR2,
                        p_password IN VARCHAR2,
                        p_password_expired IN VARCHAR2,
                        p_account_locked IN VARCHAR2,
                        p_default_tablespace IN VARCHAR2,
                        p_temporary_tablespace IN VARCHAR2);
   PROCEDURE set_roles_granted(p_username IN VARCHAR2,
                               p_roles_granted IN VARCHAR2);
   PROCEDURE set_sys_privs(p_username IN VARCHAR2,
                           p_sys_privs IN VARCHAR2);
   PROCEDURE set_tablespace_quotas(p_username IN VARCHAR2);
   PROCEDURE create_tablespace(p_tablespace_name IN VARCHAR2,
                               p_tablespace_type IN VARCHAR2,
                               p_use_omf IN VARCHAR2,
                               p_use_asm IN VARCHAR2,
                               p_asm_disk_group IN VARCHAR2,
                               p_init_size IN NUMBER,
                               p_autoextend IN VARCHAR2,
                               p_inc_by IN NUMBER,
                               p_max_size IN NUMBER,
                               p_filename IN VARCHAR2 DEFAULT NULL);
   PROCEDURE drop_tablespace(p_tablespace_name IN VARCHAR2,
                             p_tablespace_type IN VARCHAR2);
   PROCEDURE modify_datafile(p_file_id IN NUMBER,
                             p_type IN VARCHAR2,
                             p_autoextend IN VARCHAR2,
                             p_inc_by IN NUMBER DEFAULT NULL,
                             p_max_size IN NUMBER DEFAULT NULL,
                             p_resize IN NUMBER DEFAULT NULL);
   PROCEDURE add_datafile (p_tablespace_name IN VARCHAR2,
                           p_tablespace_type IN VARCHAR2,
                           p_use_omf IN VARCHAR2,
                           p_use_asm IN VARCHAR2,
                           p_asm_disk_group IN VARCHAR2,
                           p_init_size IN NUMBER,
                           p_autoextend IN VARCHAR2,
                           p_inc_by IN NUMBER,
                           p_max_size IN NUMBER,
                           p_filename IN VARCHAR2 DEFAULT NULL);
   FUNCTION highlight_omf_asm RETURN VARCHAR2;
   FUNCTION query_schema(p_owner IN VARCHAR2,
                         p_object_type IN VARCHAR2,
                         p_object_name IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2;
   PROCEDURE scan_alert_log;
   PROCEDURE set_alert_log_exclude_files(p_job_name IN VARCHAR2,
                                         p_db_name IN VARCHAR2,
                                         p_action IN VARCHAR2 DEFAULT 'BEGIN');
   FUNCTION raise_alarm RETURN VARCHAR2;
   PROCEDURE check_os_filesystem_usage(p_scan_sequence IN NUMBER);
   FUNCTION get_instance_property(p_name IN VARCHAR2) RETURN VARCHAR2;
   FUNCTION schema_ora_maintained(p_schema IN VARCHAR2) RETURN BOOLEAN;
   PROCEDURE scan_tablespace_usage;
   FUNCTION get_users_default_tablespace(p_username IN VARCHAR2) RETURN VARCHAR2;

END aca_database_util;
/


CREATE OR REPLACE PACKAGE ACA_DATAPUMP_UTIL IS
   PROCEDURE schedule_export(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'EXPORT_TEMPLATE_SCHEDULE');

   PROCEDURE run_export(p_template_name IN VARCHAR2 DEFAULT 'EXPORT_TEMPLATE',
                        p_name IN VARCHAR2,
                        p_description IN VARCHAR2,
                        p_datapump_type IN VARCHAR2,
                        p_datapump_directory IN VARCHAR2,
                        p_dump_file IN VARCHAR2,
                        p_log_file IN VARCHAR2,
                        p_compression IN VARCHAR2,
                        p_parallel_threads IN VARCHAR2,
                        p_max_filesize IN VARCHAR2,
                        p_estimate_only IN VARCHAR2,
                        p_content IN VARCHAR2 DEFAULT NULL,
                        p_encryption IN VARCHAR2,
                        p_encryption_pwd IN VARCHAR2,
                        p_datapump_mode IN VARCHAR2,
                        p_table_schema IN VARCHAR2,
                        p_schemas IN VARCHAR2,
                        p_tables IN VARCHAR2,
                        p_tablespaces IN VARCHAR2);

   PROCEDURE schedule_import(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'IMPORT_TEMPLATE_SCHEDULE');

   PROCEDURE run_import(p_template_name IN VARCHAR2 DEFAULT 'IMPORT_TEMPLATE',
                        p_name IN VARCHAR2,
                        p_description IN VARCHAR2,
                        p_datapump_type IN VARCHAR2,
                        p_datapump_directory IN VARCHAR2,
                        p_dump_file IN VARCHAR2,
                        p_log_file IN VARCHAR2,
                        p_parallel_threads IN VARCHAR2,
                        p_table_exists_action IN VARCHAR2,
                        p_content IN VARCHAR2 DEFAULT NULL,
                        p_encryption_pwd IN VARCHAR2,
                        p_datapump_mode IN VARCHAR2,
                        p_schema IN VARCHAR2,
                        p_tables IN VARCHAR2,
                        p_remap_schema_to IN VARCHAR2 DEFAULT NULL,
                        p_remap_tablespace_from IN VARCHAR2 DEFAULT NULL,
                        p_remap_tablespace_to IN VARCHAR2 DEFAULT NULL);
END aca_datapump_util;
/


CREATE OR REPLACE PACKAGE ACA_ERROR_UTIL IS
   PROCEDURE log_error(p_program_name IN VARCHAR2, p_error_text IN VARCHAR2);
   PROCEDURE acknowledge_errors;
   PROCEDURE test_error_logging;
END aca_error_util;
/


CREATE OR REPLACE PACKAGE ACA_INSTALL_UTIL IS
   -- DO NOT RUN PROCEDURE load_aca_jobs UNLESS YOU KNOW WHAT YOU ARE DOING.
   PROCEDURE load_aca_jobs(p_dummy IN VARCHAR2 DEFAULT NULL);
   -- DO NOT RUN PROCEDURE init UNLESS YOU KNOW WHAT YOU ARE DOING.
   PROCEDURE init;
END aca_install_util;
/

CREATE OR REPLACE PACKAGE ACA_RMAN_CONFIG IS
   FUNCTION get_config_value(p_name IN v$rman_configuration.name%TYPE,
                             p_value_like IN VARCHAR2 DEFAULT NULL) RETURN v$rman_configuration.value%TYPE;
   PROCEDURE configure_rman(p_backup_type VARCHAR2 DEFAULT NULL,
                            p_parallelism VARCHAR2 DEFAULT '1',
                            p_backup_location VARCHAR2 DEFAULT NULL,
                            p_comp_algorithm VARCHAR2 DEFAULT 'BASIC',
                            p_comp_release VARCHAR2 DEFAULT 'DEFAULT',
                            p_comp_opt VARCHAR2 DEFAULT 'YES',
                            p_maxpiecesize NUMBER DEFAULT NULL,
                            p_autobackup IN VARCHAR2,
                            p_autobackup_disk_loc IN VARCHAR2,
                            p_optimization IN VARCHAR2,
                            p_exclude_tablespaces IN VARCHAR2,
                            p_retention_policy IN VARCHAR2,
                            p_rp_days IN VARCHAR2,
                            p_rp_backups IN VARCHAR2,
                            p_archlog_del_policy IN VARCHAR2,
                            p_archlog_backups IN VARCHAR2,
                            p_tape_backup_type VARCHAR2 DEFAULT NULL,
                            p_tape_parallelism VARCHAR2 DEFAULT '1',
                            p_tape_parameters VARCHAR2 DEFAULT NULL);
END aca_rman_config;
/


CREATE OR REPLACE PACKAGE ACA_SCHEDULER_UTIL IS
   PROCEDURE schedule_job(p_name IN VARCHAR2);
END aca_scheduler_util;
/


CREATE OR REPLACE PACKAGE ACA_SQL_UTIL IS

   PROCEDURE run_sql(p_id IN NUMBER,
                     p_template_name IN VARCHAR2 DEFAULT 'SQL_TEMPLATE');

END aca_sql_util;
/


CREATE OR REPLACE PACKAGE ACA_UTIL IS

   TYPE SUB_REC IS RECORD (name VARCHAR2 (30),
                           value VARCHAR2 (4000));
   TYPE SUB_TAB IS TABLE OF SUB_REC INDEX BY BINARY_INTEGER;

   TYPE ARG_REC IS RECORD (name VARCHAR2 (30),
                           value VARCHAR2 (4000));
   TYPE ARG_TAB IS TABLE OF ARG_REC INDEX BY BINARY_INTEGER;

   empty_arg_tab ARG_TAB;
   empty_sub_tab SUB_TAB;

   FUNCTION db_is_cdb RETURN BOOLEAN;
   
   FUNCTION db_is_cdb2 RETURN VARCHAR2;

   PROCEDURE prepare_job(p_template_name IN VARCHAR2,
                         p_job_name IN VARCHAR2,
                         p_description IN VARCHAR2 DEFAULT NULL,
                         p_arguments IN ACA_UTIL.ARG_TAB DEFAULT aca_util.empty_arg_tab,
                         p_substitutions IN ACA_UTIL.SUB_TAB DEFAULT aca_util.empty_sub_tab,
                         p_executable_code IN CLOB DEFAULT NULL,
                         p_command_code IN CLOB DEFAULT NULL,
                         p_job_execution IN VARCHAR2 DEFAULT NULL,
                         p_repeat_interval IN VARCHAR2 DEFAULT NULL,
                         p_start_date IN TIMESTAMP WITH TIME ZONE DEFAULT NULL,
                         p_end_date IN TIMESTAMP WITH TIME ZONE DEFAULT NULL,
                         p_completion_recipients IN VARCHAR2 DEFAULT NULL,
                         p_success_recipients IN VARCHAR2 DEFAULT NULL,
                         p_failure_recipients IN VARCHAR2 DEFAULT NULL,
                         p_notifications IN VARCHAR2 DEFAULT 'NO',
                         p_log_run IN VARCHAR2 DEFAULT 'NO',
                         p_run_job IN VARCHAR2 DEFAULT 'YES');

   FUNCTION get_config_value(p_name IN VARCHAR2) RETURN VARCHAR2;
   PROCEDURE set_config_value(p_name IN VARCHAR2,
                              p_value IN VARCHAR2);
   FUNCTION get_directory_path(p_name IN VARCHAR2) RETURN VARCHAR2;
   FUNCTION job_exists(p_job_name IN VARCHAR2) RETURN BOOLEAN;
   FUNCTION job_running(p_job_name IN VARCHAR2) RETURN BOOLEAN;
   PROCEDURE drop_job(p_job_name IN VARCHAR2);
   PROCEDURE drop_program(p_program_name IN VARCHAR2);
   PROCEDURE drop_schedule(p_schedule_name IN VARCHAR2);
   PROCEDURE drop_credential(p_credential_name IN VARCHAR2);
   PROCEDURE create_credential(p_credential_name IN VARCHAR2,
                               p_username IN VARCHAR2,
                               p_password IN VARCHAR2);
   PROCEDURE create_app_credential;
   PROCEDURE schedule_job(p_job_id IN NUMBER);
   PROCEDURE copy_aca_job(p_source_job_name IN VARCHAR2,
                          p_target_job_name IN VARCHAR2,
                          p_new_id OUT NUMBER);
   PROCEDURE sleep(p_seconds IN NUMBER);
   PROCEDURE os_command(p_command IN VARCHAR2,
                        p_credential_name IN VARCHAR2,
                        p_timeout IN NUMBER DEFAULT 10,
                        p_status OUT VARCHAR2,
                        p_output OUT CLOB,
                        p_success_message OUT VARCHAR2,
                        p_failure_message OUT VARCHAR2);
   PROCEDURE run_os_command(p_command IN VARCHAR2,
                            p_credential_name IN VARCHAR2,
                            p_timeout IN NUMBER DEFAULT 10);
   PROCEDURE run_os_command_with_output(p_command IN VARCHAR2,
                                        p_credential_name IN VARCHAR2,
                                        p_timeout IN NUMBER DEFAULT 10,
                                        p_status OUT VARCHAR2,
                                        p_output OUT CLOB,
                                        p_success_message OUT VARCHAR2,
                                        p_failure_message OUT VARCHAR2);
   PROCEDURE run_os_command_from_apex(p_command IN VARCHAR2,
                                      p_credential_name IN VARCHAR2,
                                      p_timeout IN NUMBER DEFAULT 10);
   FUNCTION blob2clob (p_blob IN BLOB) RETURN CLOB;
   FUNCTION clob2blob (p_clob IN CLOB) RETURN BLOB;
   PROCEDURE put_file2(p_id IN NUMBER,
                       p_credential_name IN VARCHAR2,
                       p_os_filename IN VARCHAR2);
   PROCEDURE get_file(p_credential_name IN VARCHAR2,
                      p_os_filename IN VARCHAR2 DEFAULT NULL,
                      p_amount IN NUMBER DEFAULT NULL);
   PROCEDURE drop_scheduled_job(p_job_name IN VARCHAR2);
   PROCEDURE drop_aca_job(p_job_name IN VARCHAR2);
   PROCEDURE delete_job_log_entries(p_job_name IN VARCHAR2);
   PROCEDURE drop_job_all(p_job_name IN VARCHAR2);
   PROCEDURE set_apex_smtp_parameters;
   PROCEDURE update_log_filename(p_name IN VARCHAR2,
                                 p_log_filename IN VARCHAR2);
   FUNCTION get_log_filename(p_log_id IN NUMBER,
                             p_position IN NUMBER DEFAULT 1) RETURN VARCHAR2;
   FUNCTION get_distinct_list(p_list IN VARCHAR2,
                              p_delimiter IN VARCHAR2 DEFAULT ',') RETURN VARCHAR2;
   FUNCTION validate_ora_name(p_name IN VARCHAR2,
                              p_label IN VARCHAR2) RETURN VARCHAR2;
   FUNCTION test_os_directory_writable(p_directory IN VARCHAR2) RETURN BOOLEAN;
   FUNCTION aca_check_unique(p_name IN VARCHAR2,
                             p_table_name IN VARCHAR2,
                             p_id IN NUMBER DEFAULT NULL) RETURN VARCHAR2;
   FUNCTION get_metric_unit(p_metric_id IN NUMBER) RETURN VARCHAR2;
   PROCEDURE init_scheduler_event_queue;
   PROCEDURE init_system_alert_queue;
   FUNCTION test_os_settings(p_os_type IN VARCHAR2,
                             p_os_user IN VARCHAR2,
                             p_os_password IN VARCHAR2,
                             p_os_home_directory IN VARCHAR2,
                             p_os_scripts_directory IN VARCHAR2,
                             p_os_log_directory IN VARCHAR2,
                             p_os_apex_directory IN VARCHAR2,
                             p_data_pump_directory_path IN VARCHAR2) RETURN VARCHAR2;
   FUNCTION test_db_settings(p_db_host IN VARCHAR2,
                             p_db_port IN VARCHAR2,
                             p_db_service_name IN VARCHAR2,
                             p_db_user IN VARCHAR2,
                             p_db_password IN VARCHAR2) RETURN VARCHAR2;
   FUNCTION test_cdb_settings(p_db_host IN VARCHAR2,
                              p_db_port IN VARCHAR2,
                              p_db_service_name IN VARCHAR2,
                              p_db_user IN VARCHAR2,
                              p_db_password IN VARCHAR2) RETURN VARCHAR2;
   PROCEDURE restart_internal_jobs;

   PROCEDURE post_installation(p_apex_workspace IN VARCHAR2,
                               p_app_identifier IN VARCHAR2,
                               p_app_email_from IN VARCHAR2,
                               p_sysadmin_password IN VARCHAR2,
                               p_os_type IN VARCHAR2,
                               p_win_programs_path IN VARCHAR2,
                               p_os_user IN VARCHAR2,
                               p_os_password IN VARCHAR2,
                               p_os_home_directory IN VARCHAR2,
                               p_os_scripts_directory IN VARCHAR2,
                               p_os_log_directory IN VARCHAR2,
                               p_os_apex_directory IN VARCHAR2,
                               p_data_pump_directory_path IN VARCHAR2,
                               p_db_edition IN VARCHAR2,
                               p_oracle_home IN VARCHAR2,
                               p_db_host IN VARCHAR2,
                               p_db_port IN VARCHAR2,
                               p_db_service_name IN VARCHAR2,
                               p_db_user IN VARCHAR2,
                               p_db_password IN VARCHAR2,
                               p_media_manager IN VARCHAR2,
                               p_asm IN VARCHAR2,
                               p_asm_hostname IN VARCHAR2,
                               p_asm_port IN VARCHAR2,
                               p_asm_sid IN VARCHAR2,
                               p_sysasm_user IN VARCHAR2,
                               p_sysasm_password IN VARCHAR2);

   FUNCTION get_db_services RETURN list_collection_type PIPELINED;
   FUNCTION get_oracle_sid RETURN VARCHAR2;
   FUNCTION get_oracle_home RETURN VARCHAR2;
   PROCEDURE set_rman_configuration(p_dummy IN VARCHAR2 DEFAULT NULL);
   FUNCTION get_os_type RETURN VARCHAR2;
   PROCEDURE import_help;
   FUNCTION get_db_version RETURN NUMBER;
   FUNCTION get_db_edition RETURN VARCHAR2;
   FUNCTION get_db_product RETURN VARCHAR2;
   FUNCTION load_blob_from_file(p_filename IN VARCHAR2) RETURN BLOB;
   PROCEDURE put_file(destination_file IN VARCHAR2,
                      destination_host IN VARCHAR2 DEFAULT NULL,
                      credential_name IN VARCHAR2 DEFAULT NULL,
                      file_contents IN CLOB,
                      destination_permissions IN VARCHAR2 DEFAULT NULL);
   PROCEDURE put_file(destination_file IN VARCHAR2,
                      destination_host IN VARCHAR2 DEFAULT NULL,
                      credential_name IN VARCHAR2 DEFAULT NULL,
                      file_contents IN BLOB,
                      destination_permissions IN VARCHAR2 DEFAULT NULL);
   PROCEDURE write_clob_to_file(destination_file IN VARCHAR2,
                                file_contents IN CLOB);
   PROCEDURE send_notification(p_to IN VARCHAR2,
                               p_subject IN VARCHAR2,
                               p_message IN VARCHAR2);
END aca_util;
/


CREATE OR REPLACE PACKAGE SBH_HELP_UTIL IS
   PROCEDURE show_text(p_help_id IN NUMBER);
   PROCEDURE show_url(p_help_id IN NUMBER);
   FUNCTION get_help_id(p_page_id IN NUMBER) RETURN NUMBER;
   FUNCTION get_title(p_help_id IN NUMBER) RETURN VARCHAR2;
   FUNCTION get_object_type(p_help_id IN NUMBER) RETURN VARCHAR2;
END sbh_help_util;
/


CREATE OR REPLACE PACKAGE SB_UTIL IS
   PROCEDURE create_table(p_app_short_name IN VARCHAR2,
                          p_table_name IN VARCHAR2,
                          p_table_short_name IN VARCHAR2,
                          p_primary_key_name IN VARCHAR2 DEFAULT 'ID',
                          p_primary_key_length IN NUMBER,
                          p_natural_key_name IN VARCHAR2 DEFAULT 'NAME',
                          p_natural_key_length IN NUMBER DEFAULT 80);
   PROCEDURE create_intersect_table(p_app_short_name IN VARCHAR2,
                                    p_table_name IN VARCHAR2,
                                    p_table_short_name IN VARCHAR2,
                                    p_primary_key_name IN VARCHAR2,
                                    p_primary_key_length IN NUMBER,
                                    p_foreign_key1_name IN VARCHAR2,
                                    p_foreign_key1_length IN NUMBER,
                                    p_foreign_key2_name IN VARCHAR2,
                                    p_foreign_key2_length IN NUMBER);
   -- PROCEDURE drop_all_objects(p_app_short_name IN VARCHAR2);
   -- DO NOT RUN drop_all_objects UNLESS YOU KNOW WHAT YOU ARE DOING!
END SB_UTIL;
/


CREATE OR REPLACE PACKAGE SEC_UTIL IS
--
--
-- Purpose: To provide all the utilities for the APEX application module SEC
--
-- MODIFICATION HISTORY
-- Person             Date        Comments
-- ----------------   ----------  ------------------------------------------
-- GL Skillbuilders   03/23/2014  Creation
--
   FUNCTION custom_hash(p_username IN VARCHAR2, p_password IN VARCHAR2) RETURN VARCHAR2;
   PROCEDURE set_password(p_username IN VARCHAR2, p_password IN VARCHAR2);
   FUNCTION custom_auth(p_username IN VARCHAR2, p_password IN VARCHAR2) RETURN BOOLEAN;
   FUNCTION get_user_id(p_username IN VARCHAR2) RETURN NUMBER;
   FUNCTION get_roles_granted(p_user_id IN NUMBER) RETURN VARCHAR2;
   PROCEDURE set_roles_granted(p_user_id IN NUMBER, p_roles_granted IN VARCHAR2);
   FUNCTION user_in_role(p_username IN VARCHAR2, p_role IN VARCHAR2) RETURN BOOLEAN;
   FUNCTION user_in_role2(p_username IN VARCHAR2, p_role IN VARCHAR2) RETURN VARCHAR2;
   FUNCTION get_notification_users RETURN VARCHAR2;
   PROCEDURE send_users_password(p_username IN VARCHAR2);

   PROCEDURE init;

END sec_util;
/

CREATE SEQUENCE ACA_AER_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_AES_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_ALERT_LOG_SCAN_SEQ 
    INCREMENT BY 1 
    MAXVALUE 9999999999999999999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_ALF_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_ALG_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_BSL_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_BST_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999999999999 
    MINVALUE 1 
    CYCLE 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_CFN_PK_SEQ 
    START WITH 26 
    INCREMENT BY 1 
    MAXVALUE 999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_CFS_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_CLF_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_CSL_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_DIRECTORY_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999999 
    MINVALUE 1 
    CYCLE 
    NOCACHE 
;


CREATE SEQUENCE ACA_DJB_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_EXPDP_JOB_SEQ 
    INCREMENT BY 1 
    MAXVALUE 9 
    MINVALUE 1 
    CYCLE 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_FRY_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_JAT_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_JLG_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 9999999999999999999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_JOB_PK_SEQ 
    START WITH 100 
    INCREMENT BY 1 
    MAXVALUE 9999999999999999999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_JSN_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_RCL_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;

CREATE SEQUENCE ACA_RPT_PK_SEQ 
    START WITH 18 
    INCREMENT BY 1 
    MAXVALUE 999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_SAT_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    CYCLE 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_SJB_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 9999999999999999999999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE ACA_SRY_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE SBH_HLP_PK_SEQ 
    START WITH 2000 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE SEC_RGD_PK_SEQ 
    START WITH 1 
    INCREMENT BY 1 
    MAXVALUE 999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE SEC_RLE_PK_SEQ 
    START WITH 3 
    INCREMENT BY 1 
    MAXVALUE 999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;


CREATE SEQUENCE SEC_USR_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999 
    MINVALUE 1 
    NOCACHE 
    ORDER 
;



CREATE OR REPLACE FUNCTION NTH_STR(p_string VARCHAR2,
                 p_position NUMBER,
                 p_separator VARCHAR2 DEFAULT ' ') RETURN VARCHAR2 IS
   -- Confidential. Copyright 2015 SkillBuilders Inc.
   string_array APEX_APPLICATION_GLOBAL.VC_ARR2;
BEGIN
   string_array := APEX_UTIL.STRING_TO_TABLE(REGEXP_REPLACE(p_string,' +',' '), p_separator);
   FOR i IN 1 .. string_array.COUNT LOOP
      IF i = p_position  THEN
         RETURN string_array(i);
      END IF;
   END LOOP;
   RETURN NULL;
END;
/

CREATE TABLE ACA_SYSTEM_ALERTS 
    ( 
     ID            NUMBER (9)  NOT NULL , 
     MESSAGE_LEVEL VARCHAR2 (30 BYTE)  NOT NULL , 
     OBJECT_TYPE   VARCHAR2 (30 BYTE)  NOT NULL , 
     OBJECT_NAME   VARCHAR2 (30 BYTE)  NOT NULL , 
     REASON_ID     NUMBER  NOT NULL , 
     REASON        VARCHAR2 (4000 BYTE) , 
     CREATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_SAT_PK_IDX ON ACA_SYSTEM_ALERTS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_SYSTEM_ALERTS 
    ADD CONSTRAINT ACA_SAT_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_SAT_PK_IDX ;




CREATE TABLE ACA_SYSTEM_ALERTS_LOG 
    ( 
     ALERT_TIME   DATE , 
     MESSAGE      VARCHAR2 (4000 BYTE) , 
     MESSAGE_TYPE VARCHAR2 (100 BYTE) 
    ) 
    LOGGING 
;

CREATE OR REPLACE PROCEDURE ACA_DEQUEUE_ALERT_EVENT(context RAW,
                                  reginfo SYS.AQ$_REG_INFO,
                                  descr SYS.AQ$_DESCRIPTOR,
                                  payload RAW,
                                  payloadl NUMBER) IS

      --
      -- Copyright 2015 2016 2017 SkillBuilders Inc.
      --
      -- Purpose: To dequeue threshold alert events
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   06/08/2015  Added workspace configuration, email from
      --                                and application identifier.
      -- GL Skillbuilders   01/04/2016  Added check for sec_util.get_notification_users
      -- GL Skillbuilders   01/30/2017  Added call to aca_util.send_notification.
      --

      dequeue_options DBMS_AQ.DEQUEUE_OPTIONS_T;
      message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
      message ALERT_TYPE;
      message_handle RAW(16);
      no_messages EXCEPTION;
      PRAGMA EXCEPTION_INIT(no_messages, -25228);
      lv_reason VARCHAR2(4000);
      lv_message VARCHAR2(32000);
      lv_mail_to VARCHAR2(32000);
      lv_message_level VARCHAR2(30);
      crlf VARCHAR2(2) := '
';
   BEGIN
      dequeue_options.msgid := descr.msg_id;
      dequeue_options.consumer_name := descr.consumer_name;
      DBMS_AQ.DEQUEUE(queue_name => 'SYS.ALERT_QUE',
                      dequeue_options => dequeue_options,
                      message_properties => message_properties,
                      payload => message,
                      msgid => message_handle);

      CASE
         WHEN message.message_level = 1  THEN lv_message_level := 'CRITICAL';
         WHEN message.message_level = 5  THEN lv_message_level := 'WARNING';
         WHEN message.message_level = 32 THEN lv_message_level := 'CLEAR';
      ELSE
         lv_message_level := 'UNKNOWN';
      END CASE;

      lv_reason := DBMS_SERVER_ALERT.EXPAND_MESSAGE(USERENV('LANGUAGE'), message.message_id,
                                                                         message.reason_argument_1,
                                                                         message.reason_argument_2,
                                                                         message.reason_argument_3,
                                                                         message.reason_argument_4,
                                                                         message.reason_argument_5);

      lv_message :=
      'Timestamp: '|| message.timestamp_originating||crlf||
      'Message Type: '||message.message_type||crlf||
      'Message Level: '||lv_message_level||crlf||
      'Reason ID: '||message.reason_id||crlf||
      'Reason: '||lv_reason||crlf||
      'Object Type: '||message.object_type||crlf||
      'Object Name: '||message.object_name;

      IF lv_message_level IN ('CRITICAL', 'WARNING') THEN
         INSERT INTO aca_system_alerts (message_level, object_type, object_name, reason_id, reason)
         VALUES (lv_message_level, message.object_type, message.object_name, message.reason_id, SUBSTR(lv_reason, 1, 4000));
      ELSIF lv_message_level = 'CLEAR' THEN
         DELETE FROM aca_system_alerts
          WHERE reason_id = message.reason_id
            AND object_type = message.object_type
            AND message.object_name = message.object_name;
      END IF;

      INSERT INTO aca_system_alerts_log (alert_time, message_type, message)
      VALUES (SYSDATE,
              message.message_type,
              lv_message);

      IF sec_util.get_notification_users IS NOT NULL THEN
         aca_util.send_notification(p_to => sec_util.get_notification_users,
                                    p_subject => 'ALERT - '||lv_message_level||' - '||SUBSTR(lv_reason, 1, 80),
                                    p_message => lv_message);
      END IF;

      COMMIT;

   EXCEPTION
      WHEN no_messages THEN
         INSERT INTO aca_system_alerts_log
         VALUES (SYSDATE, 'Notification', 'ALERT QUEUE EMPTY');
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DEQUEUE_ALERT_EVENT', p_error_text => SQLERRM);
      RAISE;
   END aca_dequeue_alert_event;
/

CREATE TABLE ACA_JOB_LOG 
    ( 
     ID                      NUMBER (38)  NOT NULL , 
     NAME                    VARCHAR2 (28 BYTE)  NOT NULL , 
     JOB_EXECUTION           VARCHAR2 (30 BYTE)  NOT NULL , 
     STATUS                  VARCHAR2 (30 BYTE) DEFAULT 'JOB_SCHEDULED'  NOT NULL , 
     SCHEDULER_LOG_DATE      DATE , 
     SCHEDULER_LOG_ID        NUMBER (38) , 
     SCHEDULER_ERROR_MESSAGE VARCHAR2 (4000 BYTE) , 
     DESCRIPTION             VARCHAR2 (4000 BYTE) , 
     PROGRAM_TYPE            VARCHAR2 (30 BYTE)  NOT NULL , 
     PROCEDURE_NAME          VARCHAR2 (30 BYTE) , 
     PLSQL_CODE              VARCHAR2 (4000 BYTE) , 
     CREDENTIAL_NAME         VARCHAR2 (30 BYTE) , 
     EXECUTABLE_NAME         VARCHAR2 (80 BYTE) , 
     EXECUTABLE_ARGS         VARCHAR2 (4000 BYTE) , 
     EXECUTABLE_FILENAME     VARCHAR2 (1000 BYTE) , 
     EXECUTABLE_CODE         CLOB , 
     COMMAND_FILENAME        VARCHAR2 (1000 BYTE) , 
     COMMAND_CODE            CLOB , 
     REPEAT_INTERVAL         VARCHAR2 (4000 BYTE) , 
     START_DATE              TIMESTAMP WITH TIME ZONE , 
     END_DATE                TIMESTAMP WITH TIME ZONE , 
     NOTES                   VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE          NUMBER (38) , 
     COMPLETION_RECIPIENTS   VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS      VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS      VARCHAR2 (4000 BYTE) , 
     CREATED_BY              VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE           DATE  NOT NULL , 
     MODIFIED_BY             VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE       DATE  NOT NULL , 
     LOG_FILENAME            VARCHAR2 (1000 BYTE) , 
     LOG_CATEGORY            VARCHAR2 (30 BYTE) , 
     NOTIFICATIONS           VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     LOG_RUN                 VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL 
    ) 
    LOGGING 
    LOB ( EXECUTABLE_CODE ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
    LOB ( COMMAND_CODE ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
;



ALTER TABLE ACA_JOB_LOG 
    ADD CONSTRAINT ACA_JLG_JOB_EXECUTION_CHK 
    CHECK ( JOB_EXECUTION IN ('IMMEDIATE', 'ONCE', 'SCHEDULE')) 
;


ALTER TABLE ACA_JOB_LOG 
    ADD CONSTRAINT ACA_JLG_STATUS_CHK 
    CHECK ( STATUS IN ('JOB_FAILED', 'JOB_RE_SCHEDULED', 'JOB_SCHEDULED', 'JOB_SUCCEEDED')) 
;


ALTER TABLE ACA_JOB_LOG 
    ADD CONSTRAINT ACA_JLG_PROGRAM_TYPE_CHK 
    CHECK ( PROGRAM_TYPE IN ('EXECUTABLE', 'PLSQL_BLOCK', 'STORED_PROCEDURE')) 
;


ALTER TABLE ACA_JOB_LOG 
    ADD CONSTRAINT ACA_JLG_NOTIFICATIONS_CHK 
    CHECK ( NOTIFICATIONS IN ('NO', 'YES')) 
;


ALTER TABLE ACA_JOB_LOG 
    ADD CONSTRAINT ACA_JLG_LOG_RUN_CHK 
    CHECK ( LOG_RUN IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_JLG_PK_IDX ON ACA_JOB_LOG 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_JOB_LOG 
    ADD CONSTRAINT ACA_JLG_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_JLG_PK_IDX ;





CREATE OR REPLACE PROCEDURE ACA_DEQUEUE_SCHEDULER_EVENT(context RAW,
                                      reginfo SYS.AQ$_REG_INFO,
                                      descr SYS.AQ$_DESCRIPTOR,
                                      payload RAW,
                                      payloadl NUMBER) IS

   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: To dequeue scheduler events
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders               Creation
   -- GL Skillbuilders   06/08/2015  Added workspace configuration, email from
   --                                and application identifier.
   -- GL Skillbuilders   08/11/2016  Added drop Oracle directory object after
   --                                APEX data pump export.
   -- GL Skillbuilders  01/30/2017  Added call to aca_util.send_notification.
   --

   -- NOTES:
   -- JOB_STARTED CONSTANT PLS_INTEGER := 1
   -- JOB_SUCCEEDED CONSTANT PLS_INTEGER := 2
   -- JOB_FAILED CONSTANT PLS_INTEGER :=4
   -- JOB_BROKEN CONSTANT PLS_INTEGER :=8
   -- JOB_COMPLETED CONSTANT PLS_INTEGER :=16
   -- JOB_STOPPED CONSTANT PLS_INTEGER :=32
   -- JOB_SCH_LIM_REACHED CONSTANT PLS_INTEGER :=64
   -- JOB_DISABLED CONSTANT PLS_INTEGER :=128
   -- JOB_CHAIN_STALLED CONSTANT PLS_INTEGER :=256
   -- JOB_ALL_EVENTS CONSTANT PLS_INTEGER := 511
   -- JOB_RUN_COMPLETED CONSTANT PLS_INTEGER := JOB_SUCCEEDED + JOB_FAILED + JOB_STOPPED
   --

   dequeue_options DBMS_AQ.DEQUEUE_OPTIONS_T;
   message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
   message SYS.SCHEDULER$_EVENT_INFO;
   message_handle RAW(16);
   lv_message VARCHAR2(32000);
   lv_mail_to VARCHAR2(32000);
   lv_command VARCHAR2(30) := 'del';
   crlf VARCHAR2(2) := '
';

   CURSOR c1 IS
   SELECT *
     FROM aca_job_log
    WHERE name = message.object_name
      AND status = message.event_type
    ORDER BY id DESC;
   r1 c1%ROWTYPE;

BEGIN

   -- Dequeue scheduler event

   dequeue_options.msgid := descr.msg_id;
   dequeue_options.consumer_name := descr.consumer_name;
   DBMS_AQ.DEQUEUE(queue_name => descr.queue_name,
                   dequeue_options => dequeue_options,
                   message_properties => message_properties,
                   payload => message,
                   msgid => message_handle);

   lv_message := 'JOB: '||message.object_name||crlf;
   lv_message := lv_message||'EVENT TYPE: '||message.event_type||crlf;
   lv_message := lv_message||'LOG ID: '||message.log_id||crlf;
   IF message.error_code <> 0 THEN
      lv_message := lv_message||'ERROR MESSAGE: '||message.error_msg||crlf;
   END IF;

   -- Log job completion

   UPDATE aca_job_log
      SET status = message.event_type,
          scheduler_log_date = SYSDATE,
          scheduler_log_id = message.log_id,
          scheduler_error_message = CASE WHEN message.error_code <> 0 THEN message.error_msg ELSE NULL END
    WHERE name = message.object_name
      AND status = 'JOB_SCHEDULED';

   -- Get record of last job completion

   OPEN c1;
      FETCH c1 INTO r1;
   CLOSE c1;

   -- Add new log entry for scheduled job (job execution SCHEDULE)

   IF r1.id IS NOT NULL AND r1.job_execution = 'SCHEDULE' AND r1.log_run = 'YES' THEN
      INSERT INTO aca_job_log
            (name, status, description, program_type,
             procedure_name, plsql_code, credential_name,
             executable_name, executable_args, executable_filename,
             executable_code, command_filename, command_code,
             job_execution, repeat_interval, start_date, end_date,
             notes, order_sequence, completion_recipients,
             success_recipients, failure_recipients,
             log_category, log_filename, notifications, log_run)
      SELECT name, 'JOB_SCHEDULED', description, program_type,
             procedure_name, plsql_code, credential_name,
             executable_name, executable_args, executable_filename,
             executable_code, command_filename, command_code,
             job_execution, repeat_interval, start_date, end_date,
             notes, order_sequence, completion_recipients,
             success_recipients, failure_recipients,
             log_category, log_filename, notifications, log_run
        FROM aca_job_log
       WHERE id = r1.id;
   END IF;

   -- Remove executable and command files
   IF r1.program_type = 'EXECUTABLE' AND r1.job_execution IN ('ONCE', 'IMMEDIATE') AND r1.status = 'JOB_SUCCEEDED' THEN
      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'UNIX' THEN
         lv_command := 'rm';
      END IF;
      aca_util.run_os_command(p_command => lv_command||' '||r1.executable_filename,
                              p_credential_name => aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME'));
      IF r1.command_filename IS NOT NULL THEN
         aca_util.run_os_command(p_command => lv_command||' '||r1.command_filename,
                                 p_credential_name => aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME'));
      END IF;
   END IF;

   -- Drop Job if once or immediate

   IF r1.job_execution IN ('ONCE', 'IMMEDIATE') THEN
      aca_util.drop_scheduled_job(r1.name);
   END IF;

   -- Drop job from job library if not permanent (i.e. Template or application internal)
   aca_util.drop_aca_job(p_job_name => r1.name);

   IF r1.notifications = 'YES' THEN -- Send notifications

      IF r1.status = 'JOB_SUCCEEDED' THEN
         lv_mail_to := r1.completion_recipients||','||r1.success_recipients;
         IF r1.completion_recipients IS NULL THEN
            lv_mail_to := aca_util.get_distinct_list(SUBSTR(lv_mail_to, 2), ',');
         END IF;
      ELSE
         lv_mail_to := r1.completion_recipients||','||r1.failure_recipients;
         IF r1.completion_recipients IS NULL THEN
            lv_mail_to := aca_util.get_distinct_list(SUBSTR(lv_mail_to, 2), ',');
         END IF;
      END IF;

      IF lv_mail_to IS NOT NULL THEN
         aca_util.send_notification(p_to => lv_mail_to,
                                    p_subject => message.object_name||' '||message.event_type,
                                    p_message => lv_message);
      END IF;

   END IF;

   IF r1.log_run = 'NO' THEN -- Remove log entry
      DELETE FROM aca_job_log WHERE id = r1.id;
   END IF;

   -- Drop Oracle directory object after APEX data pump export
   IF message.object_name LIKE 'SBA_ADE%' THEN
      aca_database_util.drop_directory(message.object_name);
   END IF;

   COMMIT;

EXCEPTION
   WHEN OTHERS THEN
   aca_error_util.log_error(p_program_name => 'ACA_DEQUEUE_SCHEDULER_EVENT', p_error_text => SQLERRM);
   RAISE;
END aca_dequeue_scheduler_event;
/

CREATE TABLE ACA_TEST 
    ( 
     COL1          VARCHAR2 (4000 BYTE) , 
     COL2          VARCHAR2 (4000 BYTE) , 
     CREATION_DATE DATE 
    ) 
    LOGGING 
;

CREATE TABLE ACA_TEST_THRESHOLD 
    ( 
     COL1          NUMBER
    ) 
    LOGGING 
;

CREATE OR REPLACE PROCEDURE ACA_TEST_SCHEDULER_PROC(p_param1 IN VARCHAR2,
                                  p_param2 IN VARCHAR2) IS
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
BEGIN
    INSERT INTO aca_test VALUES(p_param1, p_param2, SYSDATE);
END aca_test_scheduler_proc;
/

CREATE TABLE ACA_ALERT_LOG 
    ( 
     ID                    NUMBER (9)  NOT NULL , 
     ORIGINATING_TIMESTAMP TIMESTAMP  NOT NULL , 
     COMPONENT_ID          VARCHAR2 (30 BYTE)  NOT NULL , 
     MESSAGE_TEXT          VARCHAR2 (4000 BYTE)  NOT NULL , 
     ACKNOWLEDGED          VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     ACKNOWLEDGED_DATE     DATE , 
     SCAN_SEQUENCE         NUMBER , 
     FILENAME              VARCHAR2 (1000 BYTE) 
    ) 
    LOGGING 
;



ALTER TABLE ACA_ALERT_LOG 
    ADD CONSTRAINT ACA_ALG_ACKNOWLEDGED_CHK 
    CHECK ( ACKNOWLEDGED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_ALG_PK_IDX ON ACA_ALERT_LOG 
    ( 
     ID ASC 
    ) 
    NOLOGGING 
;

ALTER TABLE ACA_ALERT_LOG 
    ADD CONSTRAINT ACA_ALG_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_ALG_PK_IDX ;




CREATE TABLE ACA_ALERT_LOG_EXCLUDE_FILES 
    ( 
     JOB_NAME      VARCHAR2 (30 BYTE)  NOT NULL , 
     EXCLUDE_FILE  VARCHAR2 (4000 BYTE)  NOT NULL , 
     EXCLUDE_UNTIL TIMESTAMP 
    ) 
    LOGGING 
;





CREATE TABLE ACA_ALERT_LOG_FILTERS 
    ( 
     ID                NUMBER (3)  NOT NULL , 
     FILTER            VARCHAR2 (80 BYTE)  NOT NULL , 
     FILTER_TYPE       VARCHAR2 (30 BYTE) DEFAULT 'LIKE'  NOT NULL , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (3) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_ALERT_LOG_FILTERS 
    ADD CONSTRAINT ACA_ALF_FILTER_TYPE_CHK 
    CHECK ( FILTER_TYPE IN ('LIKE', 'NOT LIKE')) 
;


ALTER TABLE ACA_ALERT_LOG_FILTERS 
    ADD CONSTRAINT ACA_ALF_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_ALF_PK_IDX ON ACA_ALERT_LOG_FILTERS 
    ( 
     ID ASC 
    ) 
    NOLOGGING 
;

ALTER TABLE ACA_ALERT_LOG_FILTERS 
    ADD CONSTRAINT ACA_ALF_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_ALF_PK_IDX ;




CREATE TABLE ACA_ALERT_LOG_HISTORY 
    ( 
     ID                    NUMBER (9)  NOT NULL , 
     ORIGINATING_TIMESTAMP TIMESTAMP  NOT NULL , 
     COMPONENT_ID          VARCHAR2 (30 BYTE)  NOT NULL , 
     MESSAGE_TEXT          VARCHAR2 (4000 BYTE)  NOT NULL , 
     ACKNOWLEDGED          VARCHAR2 (3 BYTE)  NOT NULL , 
     ACKNOWLEDGED_DATE     DATE , 
     SCAN_SEQUENCE         NUMBER , 
     FILENAME              VARCHAR2 (1000 BYTE) 
    ) 
    LOGGING 
;





CREATE TABLE ACA_ANY_RESULT 
    ( 
     COL1        VARCHAR2 (4000 BYTE) , 
     COL2        VARCHAR2 (4000 BYTE) , 
     COL3        VARCHAR2 (4000 BYTE) , 
     COL4        VARCHAR2 (4000 BYTE) , 
     COL5        VARCHAR2 (4000 BYTE) , 
     COL6        VARCHAR2 (4000 BYTE) , 
     COL7        VARCHAR2 (4000 BYTE) , 
     COL8        VARCHAR2 (4000 BYTE) , 
     COL9        VARCHAR2 (4000 BYTE) , 
     COL10       VARCHAR2 (4000 BYTE) , 
     COL11       VARCHAR2 (4000 BYTE) , 
     COL12       VARCHAR2 (4000 BYTE) , 
     COL13       VARCHAR2 (4000 BYTE) , 
     COL14       VARCHAR2 (4000 BYTE) , 
     COL15       VARCHAR2 (4000 BYTE) , 
     COL16       VARCHAR2 (4000 BYTE) , 
     COL17       VARCHAR2 (4000 BYTE) , 
     COL18       VARCHAR2 (4000 BYTE) , 
     COL19       VARCHAR2 (4000 BYTE) , 
     COL20       VARCHAR2 (4000 BYTE) , 
     REPORT_NAME VARCHAR2 (80 BYTE) , 
     SESSION_ID  VARCHAR2 (80 BYTE) 
    ) 
    LOGGING 
;





CREATE TABLE ACA_APEX_EXPORT_SCHEDULES 
    ( 
     ID                    NUMBER (18)  NOT NULL , 
     NAME                  VARCHAR2 (30 BYTE)  NOT NULL , 
     DESCRIPTION           VARCHAR2 (4000 BYTE) , 
     WORKSPACE_ID          VARCHAR2 (80 BYTE) , 
     APPLICATION_IDS       VARCHAR2 (4000 BYTE) , 
     JOB_EXECUTION         VARCHAR2 (30 BYTE) DEFAULT 'IMMEDIATE'  NOT NULL , 
     REPEAT_INTERVAL       VARCHAR2 (4000 BYTE) , 
     START_DATE            TIMESTAMP WITH TIME ZONE , 
     END_DATE              TIMESTAMP WITH TIME ZONE , 
     COMPLETION_RECIPIENTS VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     RETENSION_DAYS        NUMBER (3) , 
     ENABLED               VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES                 VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE        NUMBER (18) , 
     CREATED_BY            VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE         DATE  NOT NULL , 
     MODIFIED_BY           VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE     DATE  NOT NULL , 
     SCHEMA_EXPORT         VARCHAR2 (3 BYTE) DEFAULT NULL , 
     SCHEMA_EXPORT_CONTENT VARCHAR2 (30 BYTE) DEFAULT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_APEX_EXPORT_SCHEDULES 
    ADD CONSTRAINT ACA_AES_JOB_EXECUTION_CHK 
    CHECK ( JOB_EXECUTION IN ('IMMEDIATE', 'ONCE', 'SCHEDULE')) 
;


ALTER TABLE ACA_APEX_EXPORT_SCHEDULES 
    ADD CONSTRAINT ACA_AES_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;


ALTER TABLE ACA_APEX_EXPORT_SCHEDULES 
    ADD CONSTRAINT ACA_AES_SCHEMA_EXPORT_CHK 
    CHECK ( SCHEMA_EXPORT IN ('NO', 'YES')) 
;


ALTER TABLE ACA_APEX_EXPORT_SCHEDULES 
    ADD CONSTRAINT ACA_AES_SCHEMA_EXP_CONTENT_CHK 
    CHECK ( SCHEMA_EXPORT_CONTENT IN ('ALL', 'DATA_ONLY', 'METADATA_ONLY')) 
;

CREATE UNIQUE INDEX ACA_AES_PK_IDX ON ACA_APEX_EXPORT_SCHEDULES 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_AES_NAME_UK_IDX ON ACA_APEX_EXPORT_SCHEDULES 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_APEX_EXPORT_SCHEDULES 
    ADD CONSTRAINT ACA_AES_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_AES_PK_IDX ;


ALTER TABLE ACA_APEX_EXPORT_SCHEDULES 
    ADD CONSTRAINT ACA_AES_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_AES_NAME_UK_IDX ;




CREATE TABLE ACA_APPLICATION_ERRORS 
    ( 
     ID                NUMBER (12)  NOT NULL , 
     ERROR_DATE        DATE  NOT NULL , 
     ERROR_USER        VARCHAR2 (80 BYTE)  NOT NULL , 
     PROGRAM_NAME      VARCHAR2 (80 BYTE)  NOT NULL , 
     ERROR_TEXT        VARCHAR2 (4000 BYTE)  NOT NULL , 
     ACKNOWLEDGED      VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     ACKNOWLEDGED_DATE DATE , 
     ACKNOWLEDGED_USER VARCHAR2 (80 BYTE) 
    ) 
    LOGGING 
;



ALTER TABLE ACA_APPLICATION_ERRORS 
    ADD CONSTRAINT ACA_AER_ACKNOWLEDGED_CHK 
    CHECK ( ACKNOWLEDGED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_AER_PK_IDX ON ACA_APPLICATION_ERRORS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_APPLICATION_ERRORS 
    ADD CONSTRAINT ACA_AER_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_AER_PK_IDX ;




CREATE TABLE ACA_BACKUP_SCHEDULES 
    ( 
     ID                     NUMBER (6)  NOT NULL , 
     NAME                   VARCHAR2 (30 BYTE)  NOT NULL , 
     DESCRIPTION            VARCHAR2 (4000 BYTE) , 
     BACKUP_TAG             VARCHAR2 (30 BYTE) , 
     BACKUP_MEDIA           VARCHAR2 (8 BYTE) DEFAULT 'DISK'  NOT NULL , 
     BACKUP_LOCATION_SPEC   VARCHAR2 (4 BYTE) DEFAULT 'RMAN'  NOT NULL , 
     BACKUP_LOCATION        VARCHAR2 (4000 BYTE) , 
     BACKUP_TYPE            VARCHAR2 (30 BYTE) DEFAULT 'COMPRESSED BACKUPSET'  NOT NULL , 
     BACKUP_METHOD          VARCHAR2 (30 BYTE) DEFAULT 'FULL'  NOT NULL , 
     BACKUP_DATABASE        VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     BACKUP_ARCHIVE_LOG     VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     DELETE_ARCHIVE_LOG     VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     BACKUP_CONTROLFILE     VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     CROSSCHECK             VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     DELETE_EXPIRED_BACKUP  VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     DELETE_OBSOLETE_BACKUP VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     JOB_EXECUTION          VARCHAR2 (30 BYTE) DEFAULT NULL , 
     REPEAT_INTERVAL        VARCHAR2 (4000 BYTE) , 
     START_DATE             TIMESTAMP WITH TIME ZONE , 
     END_DATE               TIMESTAMP WITH TIME ZONE , 
     JOB_ID                 NUMBER , 
     SECTION_SIZE           NUMBER , 
     COMPLETION_RECIPIENTS  VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS     VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS     VARCHAR2 (4000 BYTE) , 
     ENABLED                VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES                  VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE         NUMBER (6) , 
     CREATED_BY             VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE          DATE  NOT NULL , 
     MODIFIED_BY            VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE      DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BACKUP_MEDIA_CHK 
    CHECK ( BACKUP_MEDIA IN ('DISK', 'SBT_TAPE')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BACKUP_LOC_SPEC_CHK 
    CHECK ( BACKUP_LOCATION_SPEC IN ('DIR', 'FRA', 'RMAN')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BACKUP_TYPE_CHK 
    CHECK ( BACKUP_TYPE IN ('BACKUPSET', 'COMPRESSED BACKUPSET', 'COPY')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BACKUP_METHOD_CHK 
    CHECK ( BACKUP_METHOD IN ('FULL', 'INCREMENTAL LEVEL 0', 'INCREMENTAL LEVEL 1')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BDS_CHK 
    CHECK ( BACKUP_DATABASE IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BAL_CHK 
    CHECK ( BACKUP_ARCHIVE_LOG IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_DAL_CHK 
    CHECK ( DELETE_ARCHIVE_LOG IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_BCF_CHK 
    CHECK ( BACKUP_CONTROLFILE IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_CROSSCHECK_CHK 
    CHECK ( CROSSCHECK IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_DEB_CHK 
    CHECK ( DELETE_EXPIRED_BACKUP IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_DOB_CHK 
    CHECK ( DELETE_OBSOLETE_BACKUP IN ('NO', 'YES')) 
;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_BSL_PK_IDX ON ACA_BACKUP_SCHEDULES 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_BSL_NAME_UK_IDX ON ACA_BACKUP_SCHEDULES 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_BSL_PK_IDX ;


ALTER TABLE ACA_BACKUP_SCHEDULES 
    ADD CONSTRAINT ACA_BSL_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_BSL_NAME_UK_IDX ;




CREATE TABLE ACA_BACKUP_SETS 
    ( 
     ID                NUMBER (18)  NOT NULL , 
     RECID             NUMBER , 
     TAG               VARCHAR2 (80 BYTE) , 
     COMPLETION_TIME   DATE , 
     FILE_TYPE         VARCHAR2 (80 BYTE) , 
     DEVICE_TYPE       VARCHAR2 (80 BYTE) , 
     STATUS            VARCHAR2 (80 BYTE) , 
     KEEP              VARCHAR2 (80 BYTE) , 
     PIECES            NUMBER , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_BST_PK_IDX ON ACA_BACKUP_SETS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_BACKUP_SETS 
    ADD CONSTRAINT ACA_BST_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_BST_PK_IDX ;




CREATE TABLE ACA_CLONE_FILENAME_SUBS 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     CLONE_SCHEDULE_ID NUMBER (6)  NOT NULL , 
     SUBSTITUTE_FROM   VARCHAR2 (200 BYTE)  NOT NULL , 
     SUBSTITUTE_TO     VARCHAR2 (200 BYTE)  NOT NULL , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_CFS_PK_IDX ON ACA_CLONE_FILENAME_SUBS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_CFS_SUB_FROM_UK_IDX ON ACA_CLONE_FILENAME_SUBS 
    ( 
     CLONE_SCHEDULE_ID ASC , 
     SUBSTITUTE_FROM ASC 
    ) 
    LOGGING 
;
CREATE INDEX ACA_CFS_ACA_CSL_FK_IDX ON ACA_CLONE_FILENAME_SUBS 
    ( 
     CLONE_SCHEDULE_ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_CLONE_FILENAME_SUBS 
    ADD CONSTRAINT ACA_CFS_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_CFS_PK_IDX ;


ALTER TABLE ACA_CLONE_FILENAME_SUBS 
    ADD CONSTRAINT ACA_CFS_SUB_FROM_UK UNIQUE ( CLONE_SCHEDULE_ID , SUBSTITUTE_FROM ) 
    USING INDEX ACA_CFS_SUB_FROM_UK_IDX ;




CREATE TABLE ACA_CLONE_LOGFILES 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     CLONE_SCHEDULE_ID NUMBER (6)  NOT NULL , 
     GROUP_NUMBER      NUMBER (1)  NOT NULL , 
     FILENAME          VARCHAR2 (200 BYTE)  NOT NULL , 
     ORDER_SEQUENCE    NUMBER (9) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_CLF_PK_IDX ON ACA_CLONE_LOGFILES 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_CLF_FILENAME_UK_IDX ON ACA_CLONE_LOGFILES 
    ( 
     CLONE_SCHEDULE_ID ASC , 
     FILENAME ASC 
    ) 
    LOGGING 
;
CREATE INDEX ACA_CLF_ACA_CSL_FK_IDX ON ACA_CLONE_LOGFILES 
    ( 
     CLONE_SCHEDULE_ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_CLONE_LOGFILES 
    ADD CONSTRAINT ACA_CLF_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_CLF_PK_IDX ;


ALTER TABLE ACA_CLONE_LOGFILES 
    ADD CONSTRAINT ACA_CLF_FILENAME_UK UNIQUE ( CLONE_SCHEDULE_ID , FILENAME ) 
    USING INDEX ACA_CLF_FILENAME_UK_IDX ;




CREATE TABLE ACA_CLONE_SCHEDULES 
    ( 
     ID                       NUMBER (6)  NOT NULL , 
     NAME                     VARCHAR2 (30 BYTE)  NOT NULL , 
     SYS_PASSWORD             VARCHAR2 (30 BYTE)  NOT NULL , 
     SOURCE_TNS_NAME          VARCHAR2 (30 BYTE)  NOT NULL , 
     DESTINATION_TNS_NAME     VARCHAR2 (30 BYTE)  NOT NULL , 
     DESTINATION_DB_NAME      VARCHAR2 (30 BYTE)  NOT NULL , 
     DESTINATION_LOGFILE_SIZE NUMBER (4)  NOT NULL , 
     FILENAME_CHECK           VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     EXCLUDE_TABLESPACES      VARCHAR2 (4000 BYTE) , 
     DESCRIPTION              VARCHAR2 (4000 BYTE) , 
     JOB_EXECUTION            VARCHAR2 (30 BYTE)  NOT NULL , 
     REPEAT_INTERVAL          VARCHAR2 (4000 BYTE) , 
     START_DATE               TIMESTAMP WITH TIME ZONE , 
     END_DATE                 TIMESTAMP WITH TIME ZONE , 
     COMPLETION_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS       VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS       VARCHAR2 (4000 BYTE) , 
     ENABLED                  VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES                    VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE           NUMBER (6) , 
     CREATED_BY               VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE            DATE  NOT NULL , 
     MODIFIED_BY              VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE        DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_CLONE_SCHEDULES 
    ADD CONSTRAINT ACA_CSL_FILENAME_CHECK_CHK 
    CHECK ( FILENAME_CHECK IN ('NO', 'YES')) 
;


ALTER TABLE ACA_CLONE_SCHEDULES 
    ADD CONSTRAINT ACA_CSL_JOB_EXECUTION_CHK 
    CHECK ( JOB_EXECUTION IN ('IMMEDIATE', 'ONCE', 'SCHEDULE')) 
;


ALTER TABLE ACA_CLONE_SCHEDULES 
    ADD CONSTRAINT ACA_CSL_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_CSL_PK_IDX ON ACA_CLONE_SCHEDULES 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_CSL_NAME_UK_IDX ON ACA_CLONE_SCHEDULES 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_CLONE_SCHEDULES 
    ADD CONSTRAINT ACA_CSL_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_CSL_PK_IDX ;


ALTER TABLE ACA_CLONE_SCHEDULES 
    ADD CONSTRAINT ACA_CSL_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_CSL_NAME_UK_IDX ;




CREATE TABLE ACA_CONFIGURATION 
    ( 
     ID                NUMBER (3)  NOT NULL , 
     NAME              VARCHAR2 (30 BYTE)  NOT NULL , 
     VALUE             VARCHAR2 (4000 BYTE) , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (3) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_CONFIGURATION 
    ADD CONSTRAINT ACA_CFN_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_CFN_PK_IDX ON ACA_CONFIGURATION 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_CFN_NAME_UK_IDX ON ACA_CONFIGURATION 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_CONFIGURATION 
    ADD CONSTRAINT ACA_CFN_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_CFN_PK_IDX ;


ALTER TABLE ACA_CONFIGURATION 
    ADD CONSTRAINT ACA_CFN_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_CFN_NAME_UK_IDX ;




CREATE TABLE ACA_DATAPUMP_JOBS 
    ( 
     ID                    NUMBER (18)  NOT NULL , 
     NAME                  VARCHAR2 (30 BYTE)  NOT NULL , 
     DATAPUMP_TYPE         VARCHAR2 (10 BYTE) DEFAULT 'EXPORT'  NOT NULL , 
     DATAPUMP_MODE         VARCHAR2 (30 BYTE) DEFAULT 'SCHEMA'  NOT NULL , 
     DATAPUMP_DIRECTORY    VARCHAR2 (255 BYTE) , 
     DUMP_FILE             VARCHAR2 (255 BYTE) , 
     LOG_FILE              VARCHAR2 (255 BYTE) , 
     PARALLEL_THREADS      NUMBER , 
     MAX_FILESIZE          NUMBER , 
     ENCRYPTION            VARCHAR2 (50 BYTE) DEFAULT 'NONE'  NOT NULL , 
     ENCRYPTION_PWD        VARCHAR2 (50 BYTE) , 
     ESTIMATE_ONLY         VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     SCHEMAS               VARCHAR2 (4000 BYTE) , 
     TABLES                VARCHAR2 (4000 BYTE) , 
     TABLESPACES           VARCHAR2 (4000 BYTE) , 
     TABLE_EXISTS_ACTION   VARCHAR2 (10 BYTE) , 
     JOB_EXECUTION         VARCHAR2 (30 BYTE) DEFAULT 'IMMEDIATE'  NOT NULL , 
     REPEAT_INTERVAL       VARCHAR2 (4000 BYTE) , 
     START_DATE            TIMESTAMP WITH TIME ZONE , 
     END_DATE              TIMESTAMP WITH TIME ZONE , 
     DESCRIPTION           VARCHAR2 (4000 BYTE) , 
     ENABLED               VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     COMPRESSION           VARCHAR2 (30 BYTE) DEFAULT 'NONE'  NOT NULL , 
     TABLE_SCHEMA          VARCHAR2 (30 BYTE) , 
     COMPLETION_RECIPIENTS VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     REMAP_SCHEMA_TO       VARCHAR2 (30 BYTE) , 
     REMAP_TABLESPACE_FROM VARCHAR2 (30 BYTE) , 
     REMAP_TABLESPACE_TO   VARCHAR2 (30 BYTE) , 
     NOTES                 VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE        NUMBER (18) , 
     CREATED_BY            VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE         DATE  NOT NULL , 
     MODIFIED_BY           VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE     DATE  NOT NULL , 
     CONTENT               VARCHAR2 (30 BYTE) 
    ) 
    LOGGING 
;



ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_DATAPUMP_TYPE_CHK 
    CHECK ( DATAPUMP_TYPE IN ('EXPORT', 'IMPORT')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_DATAPUMP_MODE_CHK 
    CHECK ( DATAPUMP_MODE IN ('FULL', 'SCHEMA', 'TABLE', 'TABLESPACE')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_ENCRYPTION_CHK 
    CHECK ( ENCRYPTION IN ('ALL', 'DATA_ONLY', 'ENCRYPTED_COLUMNS_ONLY', 'METADATA_ONLY', 'NO', 'NONE', 'YES')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_ESTIMATE_ONLY_CHK 
    CHECK ( ESTIMATE_ONLY IN ('NO', 'YES')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_TEA_CHK 
    CHECK ( TABLE_EXISTS_ACTION IN ('APPEND', 'REPLACE', 'SKIP', 'TRUNCATE')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_JOB_EXECUTION_CHK 
    CHECK ( JOB_EXECUTION IN ('IMMEDIATE', 'ONCE', 'SCHEDULE')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_COMPRESSION_CHK 
    CHECK ( COMPRESSION IN ('ALL', 'DATA_ONLY', 'METADATA_ONLY', 'NONE')) 
;

CREATE UNIQUE INDEX ACA_DJB_PK_IDX ON ACA_DATAPUMP_JOBS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_DJB_NAME_UK_IDX ON ACA_DATAPUMP_JOBS 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_DJB_PK_IDX ;


ALTER TABLE ACA_DATAPUMP_JOBS 
    ADD CONSTRAINT ACA_DJB_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_DJB_NAME_UK_IDX ;




CREATE TABLE ACA_FILE_REPOSITORY 
    ( 
     ID                NUMBER (6)  NOT NULL , 
     FILENAME          VARCHAR2 (1000 BYTE) , 
     MIMETYPE          VARCHAR2 (1000 BYTE) , 
     BLOB_CONTENT      BLOB , 
     BLOB_LENGTH       NUMBER , 
     CLOB_CONTENT      CLOB , 
     CLOB_LENGTH       NUMBER , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (6) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
    LOB ( BLOB_CONTENT ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
    LOB ( CLOB_CONTENT ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
;


CREATE UNIQUE INDEX ACA_FRY_PK_IDX ON ACA_FILE_REPOSITORY 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_FILE_REPOSITORY 
    ADD CONSTRAINT ACA_FRY_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_FRY_PK_IDX ;




CREATE TABLE ACA_JOBS 
    ( 
     ID                    NUMBER (38)  NOT NULL , 
     JOB_ID                NUMBER (38) , 
     NAME                  VARCHAR2 (28 BYTE)  NOT NULL , 
     DESCRIPTION           VARCHAR2 (4000 BYTE) , 
     PROGRAM_TYPE          VARCHAR2 (30 BYTE)  NOT NULL , 
     PROCEDURE_NAME        VARCHAR2 (30 BYTE) , 
     PLSQL_CODE            VARCHAR2 (4000 BYTE) , 
     CREDENTIAL_NAME       VARCHAR2 (30 BYTE) , 
     EXECUTABLE_NAME       VARCHAR2 (80 BYTE) , 
     EXECUTABLE_FILENAME   VARCHAR2 (1000 BYTE) , 
     EXECUTABLE_CODE       CLOB , 
     COMMAND_FILENAME      VARCHAR2 (1000 BYTE) , 
     COMMAND_CODE          CLOB , 
     JOB_EXECUTION         VARCHAR2 (30 BYTE) DEFAULT 'IMMEDIATE'  NOT NULL , 
     REPEAT_INTERVAL       VARCHAR2 (4000 BYTE) , 
     START_DATE            TIMESTAMP WITH TIME ZONE , 
     END_DATE              TIMESTAMP WITH TIME ZONE , 
     ENABLED               VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES                 VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE        NUMBER (38) , 
     CREATED_BY            VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE         DATE  NOT NULL , 
     MODIFIED_BY           VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE     DATE  NOT NULL , 
     PERMANENT             VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     COMPLETION_RECIPIENTS VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     LOG_FILENAME          VARCHAR2 (1000 BYTE) , 
     LOG_CATEGORY          VARCHAR2 (30 BYTE) , 
     LOG_RUN               VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     NOTIFICATIONS         VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL , 
     LOCKED                VARCHAR2 (3 BYTE) DEFAULT 'NO'  NOT NULL 
    ) 
    LOGGING 
    LOB ( EXECUTABLE_CODE ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
    LOB ( COMMAND_CODE ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
;



ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_PROGRAM_TYPE_CHK 
    CHECK ( PROGRAM_TYPE IN ('EXECUTABLE', 'PLSQL_BLOCK', 'STORED_PROCEDURE')) 
;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_JOB_EXECUTION_CHK 
    CHECK ( JOB_EXECUTION IN ('IMMEDIATE', 'ONCE', 'SCHEDULE')) 
;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_PERMANENT_CHK 
    CHECK ( PERMANENT IN ('NO', 'YES')) 
;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_LOG_RUN_CHK 
    CHECK ( LOG_RUN IN ('NO', 'YES')) 
;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_NOTIFICATIONS_CHK 
    CHECK ( NOTIFICATIONS IN ('NO', 'YES')) 
;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_LOCKED_CHK 
    CHECK ( LOCKED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_JOB_PK_IDX ON ACA_JOBS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_JOB_NAME_UK_IDX ON ACA_JOBS 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_JOB_PK_IDX ;


ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_JOB_NAME_UK_IDX ;




CREATE TABLE ACA_JOB_ARGUMENTS 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     JOB_ID            NUMBER (38)  NOT NULL , 
     NAME              VARCHAR2 (80 BYTE)  NOT NULL , 
     VALUE             VARCHAR2 (4000 BYTE) , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (9) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_JOB_ARGUMENTS 
    ADD CONSTRAINT ACA_JAT_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_JAT_PK_IDX ON ACA_JOB_ARGUMENTS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE INDEX ACA_JAT_ACA_JOB_FK_IDX ON ACA_JOB_ARGUMENTS 
    ( 
     JOB_ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_JAT_NAME_UK_IDX ON ACA_JOB_ARGUMENTS 
    ( 
     JOB_ID ASC , 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_JOB_ARGUMENTS 
    ADD CONSTRAINT ACA_JAT_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_JAT_PK_IDX ;


ALTER TABLE ACA_JOB_ARGUMENTS 
    ADD CONSTRAINT ACA_JAT_NAME_UK UNIQUE ( JOB_ID , NAME ) 
    USING INDEX ACA_JAT_NAME_UK_IDX ;




CREATE TABLE ACA_JOB_SUBSTITUTIONS 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     JOB_ID            NUMBER (38)  NOT NULL , 
     NAME              VARCHAR2 (80 BYTE)  NOT NULL , 
     VALUE             VARCHAR2 (4000 BYTE) , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (9) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE ACA_JOB_SUBSTITUTIONS 
    ADD CONSTRAINT ACA_JSN_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_JSN_PK_IDX ON ACA_JOB_SUBSTITUTIONS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE INDEX ACA_JSN_ACA_JOB_FK_IDX ON ACA_JOB_SUBSTITUTIONS 
    ( 
     JOB_ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_JSN_NAME_UK_IDX ON ACA_JOB_SUBSTITUTIONS 
    ( 
     JOB_ID ASC , 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_JOB_SUBSTITUTIONS 
    ADD CONSTRAINT ACA_JSN_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_JSN_PK_IDX ;


ALTER TABLE ACA_JOB_SUBSTITUTIONS 
    ADD CONSTRAINT ACA_JSN_NAME_UK UNIQUE ( JOB_ID , NAME ) 
    USING INDEX ACA_JSN_NAME_UK_IDX ;




CREATE TABLE ACA_LAST_RUN_DATES 
    ( 
     NAME          VARCHAR2 (30 BYTE)  NOT NULL , 
     LAST_RUN_DATE TIMESTAMP WITH TIME ZONE 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_LRD_PK_IDX ON ACA_LAST_RUN_DATES 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_LAST_RUN_DATES 
    ADD CONSTRAINT ACA_LRD_PK PRIMARY KEY ( NAME ) 
    USING INDEX ACA_LRD_PK_IDX ;




CREATE TABLE ACA_METRICS 
    ( 
     METRIC_ID          NUMBER  NOT NULL , 
     METRIC_NAME        VARCHAR2 (30 BYTE) , 
     METRIC_DESCRIPTION VARCHAR2 (200 BYTE) , 
     METRIC_UNIT        VARCHAR2 (200 BYTE) , 
     OBJECT_TYPE        VARCHAR2 (30 BYTE) 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_MTC_PK ON ACA_METRICS 
    ( 
     METRIC_ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_METRICS 
    ADD CONSTRAINT ACA_MTC_PK PRIMARY KEY ( METRIC_ID ) 
    USING INDEX ACA_MTC_PK ;




CREATE TABLE ACA_REPORTS 
    ( 
     ID                NUMBER (3)  NOT NULL , 
     NAME              VARCHAR2 (80 BYTE)  NOT NULL , 
     QUERY             VARCHAR2 (4000 BYTE)  NOT NULL , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (3) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_RPT_NAME_UK ON ACA_REPORTS 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_RPT_PK ON ACA_REPORTS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_REPORTS 
    ADD CONSTRAINT ACA_RPT_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_RPT_PK ;


ALTER TABLE ACA_REPORTS 
    ADD CONSTRAINT ACA_RPT_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_RPT_NAME_UK ;




CREATE TABLE ACA_REPORT_COLUMN_LABELS 
    ( 
     ID                NUMBER (6)  NOT NULL , 
     REPORT_ID         NUMBER (3)  NOT NULL , 
     ORDER_SEQUENCE    NUMBER (6)  NOT NULL , 
     LABEL             VARCHAR2 (80 BYTE)  NOT NULL , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE INDEX ACA_RCL_IFM_RPT_FK_IDX ON ACA_REPORT_COLUMN_LABELS 
    ( 
     REPORT_ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_RCL_PK ON ACA_REPORT_COLUMN_LABELS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_RCL_LABEL_UK ON ACA_REPORT_COLUMN_LABELS 
    ( 
     REPORT_ID ASC , 
     LABEL ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_REPORT_COLUMN_LABELS 
    ADD CONSTRAINT ACA_RCL_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_RCL_PK ;


ALTER TABLE ACA_REPORT_COLUMN_LABELS 
    ADD CONSTRAINT ACA_RCL_LABEL_UK UNIQUE ( REPORT_ID , LABEL ) 
    USING INDEX ACA_RCL_LABEL_UK ;




CREATE TABLE ACA_SCHEDULER_JOBS 
    ( 
     ID                    NUMBER (38)  NOT NULL , 
     NAME                  VARCHAR2 (28 BYTE)  NOT NULL , 
     DESCRIPTION           VARCHAR2 (4000 BYTE) , 
     PROGRAM_TYPE          VARCHAR2 (30 BYTE)  NOT NULL , 
     PROCEDURE_NAME        VARCHAR2 (100 BYTE) , 
     PROCEDURE_PARAMETERS  VARCHAR2 (4000 BYTE) , 
     PLSQL_CODE            VARCHAR2 (4000 BYTE) , 
     EXECUTABLE_CODE       CLOB , 
     JOB_EXECUTION         VARCHAR2 (30 BYTE) DEFAULT NULL  NOT NULL , 
     REPEAT_INTERVAL       VARCHAR2 (4000 BYTE) , 
     START_DATE            TIMESTAMP WITH TIME ZONE , 
     END_DATE              TIMESTAMP WITH TIME ZONE , 
     ENABLED               VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES                 VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE        NUMBER (38) , 
     CREATED_BY            VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE         DATE  NOT NULL , 
     MODIFIED_BY           VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE     DATE  NOT NULL , 
     COMPLETION_RECIPIENTS VARCHAR2 (4000 BYTE) , 
     SUCCESS_RECIPIENTS    VARCHAR2 (4000 BYTE) , 
     FAILURE_RECIPIENTS    VARCHAR2 (4000 BYTE) 
    ) 
    LOGGING 
    LOB ( EXECUTABLE_CODE ) STORE AS
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
;



ALTER TABLE ACA_SCHEDULER_JOBS 
    ADD CONSTRAINT ACA_SJB_PROGRAM_TYPE_CHK 
    CHECK ( PROGRAM_TYPE IN ('EXECUTABLE', 'PLSQL_BLOCK', 'STORED_PROCEDURE')) 
;


ALTER TABLE ACA_SCHEDULER_JOBS 
    ADD CONSTRAINT ACA_SJB_JOB_EXECUTION_CHK 
    CHECK ( JOB_EXECUTION IN ('IMMEDIATE', 'ONCE', 'SCHEDULE')) 
;


ALTER TABLE ACA_SCHEDULER_JOBS 
    ADD CONSTRAINT ACA_SJB_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX ACA_SJB_NAME_UK_IDX ON ACA_SCHEDULER_JOBS 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_SJB_PK_IDX ON ACA_SCHEDULER_JOBS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_SCHEDULER_JOBS 
    ADD CONSTRAINT ACA_SJB_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_SJB_PK_IDX ;


ALTER TABLE ACA_SCHEDULER_JOBS 
    ADD CONSTRAINT ACA_SJB_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_SJB_NAME_UK_IDX ;




CREATE TABLE ACA_SQL_REPOSITORY 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     NAME              VARCHAR2 (28 BYTE)  NOT NULL , 
     FILENAME          VARCHAR2 (1000 BYTE) , 
     MIMETYPE          VARCHAR2 (1000 BYTE) , 
     BLOB_CONTENT      BLOB , 
     BLOB_LENGTH       NUMBER , 
     CLOB_CONTENT      CLOB , 
     CLOB_LENGTH       NUMBER , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (6) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
    LOB ( BLOB_CONTENT ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
    LOB ( CLOB_CONTENT ) STORE AS 
        ( 
        CHUNK 8192 
        RETENTION 
        ENABLE STORAGE IN ROW 
        NOCACHE LOGGING 
    ) 
;


CREATE UNIQUE INDEX ACA_SRY_PK_IDX ON ACA_SQL_REPOSITORY 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX ACA_SRY_NAME_UK_IDX ON ACA_SQL_REPOSITORY 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_SQL_REPOSITORY 
    ADD CONSTRAINT ACA_SRY_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_SRY_PK_IDX ;


ALTER TABLE ACA_SQL_REPOSITORY 
    ADD CONSTRAINT ACA_SRY_NAME_UK UNIQUE ( NAME ) 
    USING INDEX ACA_SRY_NAME_UK_IDX ;




CREATE TABLE ACA_TABLESPACE_USAGE 
    ( 
     CDATE           DATE  NOT NULL , 
     TABLESPACE_NAME VARCHAR2 (30 BYTE)  NOT NULL , 
     SIZE_MB         NUMBER  NOT NULL , 
     FREE_MB         NUMBER , 
     USED_MB         NUMBER 
    ) 
    LOGGING 
;


CREATE INDEX ACA_TUG_CDATE_IDX ON ACA_TABLESPACE_USAGE 
    ( 
     CDATE ASC 
    ) 
    LOGGING 
;
CREATE INDEX ACA_TUG_TABLESPACE_NAME_IDX ON ACA_TABLESPACE_USAGE 
    ( 
     TABLESPACE_NAME ASC 
    ) 
    LOGGING 
;



CREATE TABLE SBH_HELP 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     HELP_ID           NUMBER (9) , 
     OBJECT_TYPE       VARCHAR2 (30 BYTE) DEFAULT 'TEXT'  NOT NULL , 
     TITLE             VARCHAR2 (1000 BYTE)  NOT NULL , 
     SHORT_TITLE       VARCHAR2 (80 BYTE)  NOT NULL , 
     TEXT              CLOB , 
     BIN               BLOB , 
     FILENAME          VARCHAR2 (1000 BYTE) , 
     MIMETYPE          VARCHAR2 (1000 BYTE) , 
     EXTERNAL_URL      VARCHAR2 (1000 BYTE) , 
     AUTH_SCHEME       VARCHAR2 (30 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (9) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE SBH_HELP 
    ADD CONSTRAINT SBH_HLP_OBJECT_TYPE_CHK 
    CHECK ( OBJECT_TYPE IN ('FILE', 'TEXT', 'URL')) 
;


ALTER TABLE SBH_HELP 
    ADD CONSTRAINT SBH_HLP_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX SBH_HLP_PK_IDX ON SBH_HELP 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE SBH_HELP 
    ADD CONSTRAINT SBH_HLP_PK PRIMARY KEY ( ID ) 
    USING INDEX SBH_HLP_PK_IDX ;




CREATE TABLE SBH_PAGE_LINKS 
    ( 
     ID                NUMBER (6)  NOT NULL , 
     HELP_ID           NUMBER (9) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE SBH_PAGE_LINKS 
    ADD CONSTRAINT SBH_PLK_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE INDEX SBH_PLK_SBH_HLP_FK_IDX ON SBH_PAGE_LINKS 
    ( 
     HELP_ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX SBH_PLK_PK_IDX ON SBH_PAGE_LINKS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE SBH_PAGE_LINKS 
    ADD CONSTRAINT SBH_PLK_PK PRIMARY KEY ( ID ) 
    USING INDEX SBH_PLK_PK_IDX ;




CREATE TABLE SEC_ROLES 
    ( 
     ID                NUMBER (3)  NOT NULL , 
     NAME              VARCHAR2 (80 BYTE)  NOT NULL , 
     DESCRIPTION       VARCHAR2 (4000 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (3) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE SEC_ROLES 
    ADD CONSTRAINT SEC_RLE_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX SEC_RLE_PK_IDX ON SEC_ROLES 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX SEC_RLE_NAME_UK_IDX ON SEC_ROLES 
    ( 
     NAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE SEC_ROLES 
    ADD CONSTRAINT SEC_RLE_PK PRIMARY KEY ( ID ) 
    USING INDEX SEC_RLE_PK_IDX ;


ALTER TABLE SEC_ROLES 
    ADD CONSTRAINT SEC_RLE_NAME_UK UNIQUE ( NAME ) 
    USING INDEX SEC_RLE_NAME_UK_IDX ;




CREATE TABLE SEC_ROLES_GRANTED 
    ( 
     ID                NUMBER (9)  NOT NULL , 
     USER_ID           NUMBER (6)  NOT NULL , 
     ROLE_ID           NUMBER (3)  NOT NULL , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (9) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;



ALTER TABLE SEC_ROLES_GRANTED 
    ADD CONSTRAINT SEC_RGD_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX SEC_RGD_PK_IDX ON SEC_ROLES_GRANTED 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX SEC_RGD_UK_IDX ON SEC_ROLES_GRANTED 
    ( 
     USER_ID ASC , 
     ROLE_ID ASC 
    ) 
    LOGGING 
;
CREATE INDEX SEC_RGD_SEC_RLE_FK_IDX ON SEC_ROLES_GRANTED 
    ( 
     ROLE_ID ASC 
    ) 
    LOGGING 
;
CREATE INDEX SEC_RGD_SEC_USR_FK_IDX ON SEC_ROLES_GRANTED 
    ( 
     USER_ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE SEC_ROLES_GRANTED 
    ADD CONSTRAINT SEC_RGD_PK PRIMARY KEY ( ID ) 
    USING INDEX SEC_RGD_PK_IDX ;


ALTER TABLE SEC_ROLES_GRANTED 
    ADD CONSTRAINT SEC_RGD_UK UNIQUE ( USER_ID , ROLE_ID ) 
    USING INDEX SEC_RGD_UK_IDX ;




CREATE TABLE SEC_USERS 
    ( 
     ID                NUMBER (6)  NOT NULL , 
     USERNAME          VARCHAR2 (80 BYTE)  NOT NULL , 
     PASSWORD_HASH     VARCHAR2 (32 BYTE) , 
     ENABLED           VARCHAR2 (3 BYTE) DEFAULT 'YES'  NOT NULL , 
     EMAIL             VARCHAR2 (80 BYTE) , 
     NOTES             VARCHAR2 (4000 BYTE) , 
     ORDER_SEQUENCE    NUMBER (6) , 
     CREATED_BY        VARCHAR2 (80 BYTE)  NOT NULL , 
     CREATION_DATE     DATE  NOT NULL , 
     MODIFIED_BY       VARCHAR2 (80 BYTE)  NOT NULL , 
     MODIFICATION_DATE DATE  NOT NULL , 
     NOTIFICATIONS     VARCHAR2 (3 BYTE) 
    ) 
    LOGGING 
;



ALTER TABLE SEC_USERS 
    ADD CONSTRAINT SEC_USR_ENABLED_CHK 
    CHECK ( ENABLED IN ('NO', 'YES')) 
;


ALTER TABLE SEC_USERS 
    ADD CONSTRAINT SEC_USR_NOTIFICATIONS_CHK 
    CHECK ( NOTIFICATIONS IN ('NO', 'YES')) 
;

CREATE UNIQUE INDEX SEC_USR_PK_IDX ON SEC_USERS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;
CREATE UNIQUE INDEX SEC_USR_USERNAME_UK_IDX ON SEC_USERS 
    ( 
     USERNAME ASC 
    ) 
    LOGGING 
;

ALTER TABLE SEC_USERS 
    ADD CONSTRAINT SEC_USR_PK PRIMARY KEY ( ID ) 
    USING INDEX SEC_USR_PK_IDX ;


ALTER TABLE SEC_USERS 
    ADD CONSTRAINT SEC_USR_USERNAME_UK UNIQUE ( USERNAME ) 
    USING INDEX SEC_USR_USERNAME_UK_IDX ;





ALTER TABLE ACA_CLONE_FILENAME_SUBS 
    ADD CONSTRAINT ACA_CFS_ACA_CSL_FK FOREIGN KEY 
    ( 
     CLONE_SCHEDULE_ID
    ) 
    REFERENCES ACA_CLONE_SCHEDULES 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE ACA_CLONE_LOGFILES 
    ADD CONSTRAINT ACA_CLF_ACA_CSL_FK FOREIGN KEY 
    ( 
     CLONE_SCHEDULE_ID
    ) 
    REFERENCES ACA_CLONE_SCHEDULES 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE ACA_JOB_ARGUMENTS 
    ADD CONSTRAINT ACA_JAT_ACA_JOB_FK FOREIGN KEY 
    ( 
     JOB_ID
    ) 
    REFERENCES ACA_JOBS 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE ACA_JOBS 
    ADD CONSTRAINT ACA_JOB_ACA_JOB_FK FOREIGN KEY 
    ( 
     JOB_ID
    ) 
    REFERENCES ACA_JOBS 
    ( 
     ID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE ACA_JOB_SUBSTITUTIONS 
    ADD CONSTRAINT ACA_JSN_ACA_JOB_FK FOREIGN KEY 
    ( 
     JOB_ID
    ) 
    REFERENCES ACA_JOBS 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE ACA_REPORT_COLUMN_LABELS 
    ADD CONSTRAINT ACA_RCL_ACA_RPT_FK FOREIGN KEY 
    ( 
     REPORT_ID
    ) 
    REFERENCES ACA_REPORTS 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE SBH_PAGE_LINKS 
    ADD CONSTRAINT SBH_PLK_SBH_HLP_FK FOREIGN KEY 
    ( 
     HELP_ID
    ) 
    REFERENCES SBH_HELP 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE SEC_ROLES_GRANTED 
    ADD CONSTRAINT SEC_RGD_SEC_RLE_FK FOREIGN KEY 
    ( 
     ROLE_ID
    ) 
    REFERENCES SEC_ROLES 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE SEC_ROLES_GRANTED 
    ADD CONSTRAINT SEC_RGD_SEC_USR_FK FOREIGN KEY 
    ( 
     USER_ID
    ) 
    REFERENCES SEC_USERS 
    ( 
     ID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;


CREATE OR REPLACE VIEW ACA_ALERT_LOG_HISTORY_VIEW ( ID, ORIGINATING_TIMESTAMP, COMPONENT_ID, MESSAGE_TEXT, ACKNOWLEDGED, ACKNOWLEDGED_DATE, SCAN_SEQUENCE, FILENAME ) AS
SELECT "ID","ORIGINATING_TIMESTAMP","COMPONENT_ID","MESSAGE_TEXT","ACKNOWLEDGED","ACKNOWLEDGED_DATE","SCAN_SEQUENCE","FILENAME" FROM aca_alert_log_history
UNION
SELECT "ID","ORIGINATING_TIMESTAMP","COMPONENT_ID","MESSAGE_TEXT","ACKNOWLEDGED","ACKNOWLEDGED_DATE","SCAN_SEQUENCE","FILENAME" FROM aca_alert_log ;





CREATE OR REPLACE VIEW ACA_RMAN_CONFIG_VIEW ( TAPE_BACKUP_TYPE, TAPE_PARALLELISM, TAPE_PARAMETERS, PARALLELISM, BACKUP_TYPE, DISK_FORMAT, BACKUP_LOCATION, MAXPIECESIZE, COMP_ALGORITHM, COMP_RELEASE, COMP_OPT, OPTIMIZATION, AUTOBACKUP, AUTOBACKUP_DISK_LOC, RETENTION_POLICY, RP_BACKUPS, RP_DAYS, ARCHLOG_DEL_POLICY, ARCHLOG_BACKUPS ) AS
WITH conf
        AS (SELECT aca_rman_config.get_config_value(p_name => 'DEVICE TYPE', p_value_like => '%SBT_TAPE%') tape
                 , aca_rman_config.get_config_value(p_name => 'DEVICE TYPE', p_value_like => 'DISK %') config
                 , aca_rman_config.get_config_value(p_name => 'DEVICE TYPE', p_value_like => 'DISK BACKUP TYPE%') paral
                 , aca_rman_config.get_config_value(p_name => 'COMPRESSION ALGORITHM') compression
                 , aca_rman_config.get_config_value(p_name => 'RETENTION POLICY') ret_policy
                 , aca_rman_config.get_config_value(p_name => 'ARCHIVELOG DELETION POLICY') arch_log
                 , REGEXP_REPLACE(aca_rman_config.get_config_value('CHANNEL', 'DEVICE TYPE DISK FORMAT%'), '( ){2,}', ' ') disk_format
            FROM   DUAL)
   SELECT
          CASE
             WHEN INSTR(tape, 'BACKUP TYPE TO COMPRESSED BACKUPSET') > 0 THEN 'COMPRESSED BACKUPSET'
             WHEN INSTR(tape, 'BACKUP TYPE TO BACKUPSET') > 0 THEN 'BACKUPSET'
             ELSE NULL
          END AS tape_backup_type
        , CASE
             WHEN INSTR(tape, 'BACKUP TYPE TO COMPRESSED BACKUPSET') > 0 THEN nth_str(tape, 8)
             WHEN INSTR(tape, 'BACKUP TYPE TO BACKUPSET') > 0 THEN nth_str(tape, 7)
             ELSE NULL
          END AS tape_parallelism
        , TRIM(SUBSTR(aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%SBT_TAPE%PARMS%'),
               INSTR(aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%SBT_TAPE%PARMS%'), 'PARMS') + 5)) AS tape_parameters

        , CASE
             WHEN INSTR(config, 'BACKUP TYPE TO COMPRESSED BACKUPSET') > 0 THEN nth_str(paral, 8)
             WHEN INSTR(config, 'BACKUP TYPE TO BACKUPSET') > 0 THEN nth_str(paral, 7)
             WHEN INSTR(config, 'BACKUP TYPE TO COPY') > 0 THEN nth_str(paral, 7)
             ELSE NULL
          END AS parallelism
        , CASE
             WHEN INSTR(config, 'BACKUP TYPE TO COMPRESSED BACKUPSET') > 0 THEN 'COMPRESSED BACKUPSET'
             WHEN INSTR(config, 'BACKUP TYPE TO BACKUPSET') > 0 THEN 'BACKUPSET'
             WHEN INSTR(config, 'BACKUP TYPE TO COPY') > 0 THEN 'COPY'
             ELSE NULL
          END AS backup_type
        , disk_format
        , DECODE(TRIM(BOTH '''' FROM nth_str(disk_format, 5)), 'CLEAR', '', REPLACE(TRIM(BOTH '''' FROM nth_str(disk_format, 5)), '%U')) backup_location

        , CASE WHEN aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%FORMAT%') IS NULL THEN
             nth_str(aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%MAXPIECESIZE%'), 5)
          ELSE
             nth_str(aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%MAXPIECESIZE%'), 7)
          END maxpiecesize

        , TRIM(BOTH '''' FROM nth_str(compression, 1)) comp_algorithm
        , TRIM(BOTH '''' FROM nth_str(compression, 5)) comp_release
        , CASE WHEN nth_str(compression, 9) = 'TRUE' THEN 'YES' ELSE 'NO' END comp_opt
        , CASE WHEN aca_rman_config.get_config_value(p_name => 'BACKUP OPTIMIZATION') = 'ON' THEN 'YES' ELSE 'NO' END optimization
        , CASE WHEN aca_rman_config.get_config_value(p_name => 'CONTROLFILE AUTOBACKUP') = 'ON' THEN 'YES' ELSE 'NO' END autobackup
        , REPLACE(TRIM(BOTH '''' FROM SUBSTR(aca_rman_config.get_config_value(p_name => 'CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE'), 9)), '%F') autobackup_disk_loc
        , CASE WHEN (ret_policy IS NULL or ret_policy like 'TO NONE%') THEN 'N' WHEN ret_policy LIKE 'TO REDUNDANCY%' THEN 'R' WHEN ret_policy LIKE 'TO RECOVERY WINDOW%' THEN 'W' END retention_policy
        , CASE WHEN ret_policy LIKE 'TO REDUNDANCY%' THEN nth_str(ret_policy, 3) ELSE NULL END rp_backups
        , CASE WHEN ret_policy LIKE 'TO RECOVERY WINDOW%' THEN nth_str(ret_policy, 5) ELSE NULL END rp_days
        , CASE WHEN arch_log = 'TO NONE' THEN 'N' ELSE 'D' END archlog_del_policy
        , CASE WHEN arch_log = 'TO NONE' THEN NULL ELSE nth_str(arch_log, 4) END archlog_backups
   FROM conf ;





CREATE OR REPLACE TRIGGER ACA_AER_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_APPLICATION_ERRORS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_aer_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.acknowledged IS NULL THEN
         :NEW.acknowledged := 'NO';
      END IF;
      :NEW.error_user := NVL(V('APP_USER'), USER);
      :NEW.error_date := SYSDATE;
   END IF;
END; 
/



CREATE OR REPLACE TRIGGER ACA_AES_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_APEX_EXPORT_SCHEDULES 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_aes_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      IF :NEW.schema_export IS NULL THEN
         :NEW.schema_export := 'NO';
      END IF;
      IF :NEW.schema_export_content IS NULL AND :NEW.schema_export = 'YES' THEN
         :NEW.schema_export_content := 'METADATA_ONLY';
      END IF;
      IF :NEW.job_execution IS NULL THEN
         :NEW.job_execution := 'IMMEDIATE';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
   IF :NEW.schema_export = 'NO' THEN
      :NEW.schema_export_content := NULL;
   END IF;
END; 
/



CREATE OR REPLACE TRIGGER ACA_ALF_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_ALERT_LOG_FILTERS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_alf_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      IF :NEW.filter_type IS NULL THEN
         :NEW.filter_type := 'LIKE';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_ALG_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_ALERT_LOG 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_alg_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
   ELSIF UPDATING THEN
      IF :NEW.acknowledged = 'YES' AND :OLD.acknowledged = 'NO' THEN
         :NEW.acknowledged_date := SYSDATE;
      END IF;
   END IF;
END; 
/



CREATE OR REPLACE TRIGGER ACA_BSL_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_BACKUP_SCHEDULES 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_bsl_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_BST_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_BACKUP_SETS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_bst_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_CFN_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_CONFIGURATION 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_cfn_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_CFS_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_CLONE_FILENAME_SUBS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_cfs_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
    END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_CLF_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_CLONE_LOGFILES 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_clf_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_CSL_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_CLONE_SCHEDULES 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_csl_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      IF :NEW.filename_check IS NULL THEN
         :NEW.filename_check := 'NO';
      END IF;
      IF :NEW.job_execution IS NULL THEN
         :NEW.job_execution := 'IMMEDIATE';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_DJB_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_DATAPUMP_JOBS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_djb_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      IF :NEW.estimate_only IS NULL THEN
         :NEW.estimate_only := 'NO';
      END IF;
      IF :NEW.datapump_type IS NULL THEN
         :NEW.datapump_type := 'EXPORT';
      END IF;
      IF :NEW.datapump_mode IS NULL THEN
         :NEW.datapump_mode := 'SCHEMA';
      END IF;
      IF :NEW.job_execution IS NULL THEN
         :NEW.job_execution := 'IMMEDIATE';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_FRY_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_FILE_REPOSITORY 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_fry_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_JAT_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_JOB_ARGUMENTS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_jat_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_JLG_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_JOB_LOG 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_jlg_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
      IF :NEW.notifications IS NULL THEN
         :NEW.notifications := 'NO';
      END IF;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_JOB_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_JOBS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_job_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      IF :NEW.permanent IS NULL THEN
         :NEW.permanent := 'YES';
      END IF;
      IF :NEW.locked IS NULL THEN
         :NEW.locked := 'NO';
      END IF;
      IF :NEW.log_run IS NULL THEN
         :NEW.log_run := 'NO';
      END IF;
      IF :NEW.notifications IS NULL THEN
         :NEW.notifications := 'NO';
      END IF;
      IF :NEW.job_execution IS NULL THEN
         :NEW.job_execution := 'IMMEDIATE';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_JSN_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_JOB_SUBSTITUTIONS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_jsn_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_RCL_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_REPORT_COLUMN_LABELS 
    FOR EACH ROW 
BEGIN 
   IF INSERTING THEN 
      IF :NEW.ID IS NULL THEN 
         SELECT aca_rcl_pk_seq.NEXTVAL INTO :NEW.ID FROM DUAL; 
      END IF; 
      :NEW.created_by := NVL(V('APP_USER'), USER); 
      :NEW.creation_date := SYSDATE; 
   END IF; 
   :NEW.modified_by := NVL(V('APP_USER'), USER); 
   :NEW.modification_date := SYSDATE; 
END; 
/



CREATE OR REPLACE TRIGGER ACA_RPT_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_REPORTS 
    FOR EACH ROW 
BEGIN 
   IF INSERTING THEN 
      IF :NEW.ID IS NULL THEN 
         SELECT aca_rpt_pk_seq.NEXTVAL INTO :NEW.ID FROM DUAL; 
      END IF; 
      :NEW.created_by := NVL(V('APP_USER'), USER); 
      :NEW.creation_date := SYSDATE; 
   END IF; 
   :NEW.modified_by := NVL(V('APP_USER'), USER); 
   :NEW.modification_date := SYSDATE; 
END; 
/



CREATE OR REPLACE TRIGGER ACA_SAT_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_SYSTEM_ALERTS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_sat_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.creation_date := SYSDATE;
   END IF;
END; 
/



CREATE OR REPLACE TRIGGER ACA_SJB_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_SCHEDULER_JOBS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_sjb_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER ACA_SRY_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_SQL_REPOSITORY 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_sry_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := REPLACE(UPPER(:NEW.name), ' ', '_');
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER SBH_HLP_BIU_TRG 
    BEFORE INSERT OR UPDATE ON SBH_HELP 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT sbh_hlp_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   IF :NEW.enabled IS NULL THEN
      :NEW.enabled := 'YES';
   END IF;
   IF :NEW.object_type IS NULL THEN
      :NEW.object_type := 'TEXT';
   END IF;
   IF :NEW.short_title IS NULL THEN
      :NEW.short_title := SUBSTR(:NEW.title, 1, 30);
   END IF;
   IF :NEW.object_type = 'TEXT' THEN
      :NEW.bin := NULL;
      :NEW.filename := NULL;
      :NEW.mimetype := NULL;
      :NEW.external_url := NULL;
   ELSIF :NEW.object_type = 'FILE' THEN
      :NEW.text := NULL;
      :NEW.external_url := NULL;
   ELSIF :NEW.object_type = 'URL' THEN
      :NEW.text := NULL;
      :NEW.bin := NULL;
      :NEW.filename := NULL;
      :NEW.mimetype := NULL;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER SBH_PLK_BIU_TRG 
    BEFORE INSERT OR UPDATE ON SBH_PAGE_LINKS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER SEC_RGD_BIU_TRG 
    BEFORE INSERT OR UPDATE ON SEC_ROLES_GRANTED 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT sec_rgd_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER SEC_RLE_BIU_TRG 
    BEFORE INSERT OR UPDATE ON SEC_ROLES 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT sec_rle_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.name := UPPER(:NEW.name);
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/



CREATE OR REPLACE TRIGGER SEC_USR_BIU_TRG 
    BEFORE INSERT OR UPDATE ON SEC_USERS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT sec_usr_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := 'YES';
      END IF;
      IF :NEW.notifications IS NULL THEN
         :NEW.notifications := 'NO';
      END IF;
      :NEW.created_by := NVL(V('APP_USER'), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.username := UPPER(:NEW.username);
   :NEW.modified_by := NVL(V('APP_USER'), USER);
   :NEW.modification_date := SYSDATE;
END; 
/




CREATE OR REPLACE PACKAGE BODY ACA_ALERT_UTIL IS
--
-- Confidential. Copyright 2015 SkillBuilders Inc.
--
-- Purpose: To provide utilities for system alerts
--
--   Notes: Needs GRANT EXECUTE ON DBMS_SERVER_ALERT TO <user> as SYS
--
-- MODIFICATION HISTORY
-- Person                Date        Comments
-- --------------------  ----------  ------------------------------------------
-- Garry Lawton          08/29/2013  Creation
--
   PROCEDURE set_threshold (p_metrics_id IN BINARY_INTEGER,
                            p_warning_operator IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OPERATOR_GE,
                            p_warning_value IN VARCHAR2,
                            p_critical_operator IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OPERATOR_GE,
                            p_critical_value IN VARCHAR2,
                            p_observation_period IN BINARY_INTEGER DEFAULT 1,
                            p_consecutive_occurrences IN BINARY_INTEGER  DEFAULT 1,
                            p_instance_name IN VARCHAR2 DEFAULT NULL,
                            p_object_type IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OBJECT_TYPE_SYSTEM,
                            p_object_name IN VARCHAR2 DEFAULT NULL) IS
   BEGIN
      DBMS_SERVER_ALERT.SET_THRESHOLD(metrics_id => p_metrics_id,
                                      warning_operator => p_warning_operator,
                                      warning_value => p_warning_value,
                                      critical_operator => p_critical_operator,
                                      critical_value => p_critical_value,
                                      observation_period => p_observation_period,
                                      consecutive_occurrences => p_consecutive_occurrences,
                                      instance_name => p_instance_name,
                                      object_type => p_object_type,
                                      object_name => p_object_name);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ALERT_UTIL.SET_THRESHOLD', p_error_text => SQLERRM);
      RAISE;
   END set_threshold;

   PROCEDURE clear_threshold(p_metrics_id IN BINARY_INTEGER,
                             p_instance_name IN VARCHAR2 DEFAULT NULL,
                             p_object_type IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OBJECT_TYPE_SYSTEM,
                             p_object_name IN VARCHAR2 DEFAULT NULL) IS
   BEGIN
      DBMS_SERVER_ALERT.SET_THRESHOLD(metrics_id => p_metrics_id,
                                      warning_operator => NULL,
                                      warning_value => NULL,
                                      critical_operator => NULL,
                                      critical_value => NULL,
                                      observation_period => NULL,
                                      consecutive_occurrences => NULL,
                                      instance_name => p_instance_name,
                                      object_type => p_object_type,
                                      object_name => p_object_name);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ALERT_UTIL.CLEAR_THRESHOLD', p_error_text => SQLERRM);
      RAISE;
   END clear_threshold;

   PROCEDURE get_threshold(p_metrics_id IN BINARY_INTEGER,
                           p_instance_name IN VARCHAR2 DEFAULT NULL,
                           p_object_type IN BINARY_INTEGER DEFAULT DBMS_SERVER_ALERT.OBJECT_TYPE_SYSTEM,
                           p_object_name IN VARCHAR2 DEFAULT NULL) IS
      warning_operator         BINARY_INTEGER;
      warning_value            VARCHAR2(60);
      critical_operator        BINARY_INTEGER;
      critical_value           VARCHAR2(60);
      observation_period       BINARY_INTEGER;
      consecutive_occurrences  BINARY_INTEGER;
   BEGIN
      DBMS_SERVER_ALERT.GET_THRESHOLD(metrics_id => p_metrics_id,
                                      warning_operator => warning_operator,
                                      warning_value => warning_value,
                                      critical_operator => critical_operator,
                                      critical_value => critical_value,
                                      observation_period => observation_period,
                                      consecutive_occurrences => consecutive_occurrences,
                                      instance_name => p_instance_name,
                                      object_type => p_object_type,
                                      object_name => p_object_name);
      DBMS_OUTPUT.PUT_LINE('Warning operator:        ' || warning_operator);
      DBMS_OUTPUT.PUT_LINE('Warning value:           ' || warning_value);
      DBMS_OUTPUT.PUT_LINE('Critical operator:       ' || critical_operator);
      DBMS_OUTPUT.PUT_LINE('Critical value:          ' || critical_value);
      DBMS_OUTPUT.PUT_LINE('Observation_period:      ' || observation_period);
      DBMS_OUTPUT.PUT_LINE('Consecutive occurrences: ' || consecutive_occurrences);
   EXCEPTION
      WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      aca_error_util.log_error(p_program_name => 'ACA_ALERT_UTIL.GET_THRESHOLD', p_error_text => SQLERRM);
      RAISE;
   END get_threshold;

END aca_alert_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_APEX_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: To provide APEX utilities.
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   10/09/2015  Creation

   FUNCTION inc(p_num IN OUT NUMBER) RETURN NUMBER IS
   BEGIN
      p_num   := p_num + 1;
      RETURN p_num;
   END inc;

   FUNCTION get_workspace_admin(p_workspace_id IN NUMBER) RETURN VARCHAR2 IS
      --
      -- Purpose: To get the username of a workspace administrator.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Creation
      CURSOR c1 IS
      SELECT user_name
        FROM apex_workspace_apex_users
       WHERE workspace_id = p_workspace_id
         AND UPPER(is_admin) = 'YES'
         AND UPPER(account_locked) = 'NO';
      lv_workspace_admin VARCHAR2(100);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_workspace_admin;
      CLOSE c1;
      RETURN lv_workspace_admin;
   END get_workspace_admin;

   FUNCTION workspace_exists(p_workspace_id IN NUMBER) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a workspace exists.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Creation
      CURSOR c1 IS
      SELECT 1
        FROM apex_workspaces
       WHERE workspace_id = p_workspace_id;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   END workspace_exists;

   FUNCTION application_exists(p_application_id IN NUMBER) RETURN BOOLEAN IS
      --
      -- Purpose: To test if an application exists.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Creation
      CURSOR c1 IS
      SELECT 1
        FROM apex_applications
       WHERE application_id = p_application_id;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   END application_exists;

   FUNCTION get_workspace(p_workspace_id IN NUMBER) RETURN VARCHAR2 IS
      --
      -- Purpose: To get a workspace name given it's ID.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Creation
      CURSOR c1 IS
      SELECT workspace
        FROM apex_workspaces
       WHERE workspace_id = p_workspace_id;
      lv_workspace VARCHAR2(100);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_workspace;
      CLOSE c1;
      RETURN lv_workspace;
   END get_workspace;

   FUNCTION get_application_name(p_application_id IN NUMBER) RETURN VARCHAR2 IS
      --
      -- Purpose: To get an application name given it's ID.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Creation
      CURSOR c1 IS
      SELECT application_name
        FROM apex_applications
       WHERE application_id = p_application_id;
      lv_application_name VARCHAR2(100);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_application_name;
      CLOSE c1;
      RETURN lv_application_name;
   END get_application_name;

   FUNCTION get_parsing_schema(p_application_id IN NUMBER) RETURN VARCHAR2 IS
      --
      -- Purpose: To get an application's parsing schema given it's ID.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   08/10/2016  Creation
      CURSOR c1 IS
      SELECT owner
        FROM apex_applications
       WHERE application_id = p_application_id;
      lv_parsing_schema VARCHAR2(30);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_parsing_schema;
      CLOSE c1;
      RETURN lv_parsing_schema;
   END get_parsing_schema;

   FUNCTION job_running(p_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a job is running.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Creation
      CURSOR c1 IS
      SELECT 1
        FROM user_scheduler_jobs
       WHERE job_name = p_name
         AND state = 'RUNNING';
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   END job_running;

   PROCEDURE export(p_name IN VARCHAR2) IS
      --
      -- Purpose: To export one or more APEX applications.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/13/2015  Creation
      -- GL Skillbuilders   01/18/2016  Changes for Windows implementation
      -- GL Skillbuilders   02/11/2016  Replaced call to DBMS_SCHEDULER.PUT_FILE
      --                                with ACA_UTIL.PUT_FILE
      -- GL Skillbuilders   08/11/2016  Added export of parsing schemas
      --
      CURSOR c1 IS
      SELECT * FROM aca_apex_export_schedules
       WHERE NAME = p_name;
      r1 c1%ROWTYPE;
      CURSOR c2 IS
      SELECT workspace, workspace_id
        FROM apex_workspaces
       WHERE workspace != 'INTERNAL' AND workspace NOT LIKE 'COM.ORACLE%'
       ORDER BY 1;
      r2 c2%ROWTYPE;
      CURSOR c3 IS
      SELECT application_name, application_id
        FROM apex_applications
       WHERE workspace = r2.workspace
       ORDER BY 1;
      r3 c3%ROWTYPE;
      lv_clob CLOB;
      lv_log CLOB;
      lv_application_id NUMBER;
      lv_parsing_schema VARCHAR2(30);
      lv_parsing_schemas_exported VARCHAR2(32000) := ':';
      lv_schemas VARCHAR2(32000);
      lv_directory VARCHAR2(30);
      lv_directory_seq NUMBER;
      lv_sql_statement VARCHAR2(1000);
      lv_workspace VARCHAR2(100);
      lv_os_slash VARCHAR2(1);
      lv_os_type VARCHAR2(30) := aca_util.get_config_value(p_name => 'OS_TYPE');
      lv_os_home_directory aca_configuration.value%TYPE := aca_util.get_config_value(p_name => 'OS_HOME_DIRECTORY');
      lv_os_scripts_directory aca_configuration.value%TYPE := aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY');
      lv_os_apex_directory aca_configuration.value%TYPE := aca_util.get_config_value(p_name => 'OS_APEX_DIRECTORY');
      lv_win_programs_path aca_configuration.value%TYPE := aca_util.get_config_value(p_name => 'WIN_PROGRAMS_PATH');
      lv_date VARCHAR2(30) := TO_CHAR(SYSDATE, 'YYYY-MM-DD-HH24-MI-SS');
      lv_export_directory VARCHAR2(1000);
      lv_os_credential_name VARCHAR2(30) := aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME');
      apps_array APEX_APPLICATION_GLOBAL.VC_ARR2;
      crlf VARCHAR2(2);
   BEGIN

      IF lv_os_type = 'WINDOWS' THEN
         lv_os_slash := '\';
         crlf := CHR(13)||CHR(10);
      ELSE
         lv_os_slash := '/';
         crlf := CHR(10);
      END IF;

      lv_export_directory := lv_os_apex_directory||lv_os_slash||p_name||'-'||lv_date;

      lv_log := crlf||'APEX Export '||p_name||'-'||lv_date||crlf||crlf;

      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         aca_util.run_os_command(p_command => 'mkdir '||lv_export_directory,
                                 p_credential_name => lv_os_credential_name);
      ELSIF aca_util.get_config_value(p_name => 'OS_TYPE') = 'UNIX' THEN
         aca_util.run_os_command(p_command => 'mkdir '||lv_export_directory,
                                 p_credential_name => lv_os_credential_name);
         aca_util.run_os_command(p_command => 'chmod 770 '||lv_export_directory,
                                 p_credential_name => lv_os_credential_name);
         aca_util.run_os_command(p_command => 'chgrp dba '||lv_export_directory,
                                 p_credential_name => lv_os_credential_name);
      END IF;

      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;
      IF r1.workspace_id IS NOT NULL THEN
         IF workspace_exists(p_workspace_id => r1.workspace_id) THEN
            APEX_UTIL.SET_SECURITY_GROUP_ID(r1.workspace_id);
            APEX_CUSTOM_AUTH.SET_USER(get_workspace_admin(p_workspace_id => r1.workspace_id));
            lv_workspace := get_workspace(p_workspace_id => r1.workspace_id);
            lv_clob := wwv_flow_utilities.export_workspace_to_clob(p_workspace_id => r1.workspace_id,
                                                                   p_include_team_development => TRUE,
                                                                   p_minimal => FALSE);
            -- Add CTRL-M for WINDOWS
            IF lv_os_type = 'WINDOWS' THEN
               lv_clob := REPLACE(lv_clob, CHR(10), CHR(13)||CHR(10));
            END IF;
            aca_util.put_file(destination_file => lv_export_directory||lv_os_slash||lv_workspace||'.sql',
                              destination_host => NULL,
                              credential_name => lv_os_credential_name,
                              file_contents => lv_clob,
                              destination_permissions => NULL);
            lv_log := lv_log||'Exported Workspace: '||lv_workspace||'.sql'||crlf||crlf;
         END IF;
         apps_array := APEX_UTIL.STRING_TO_TABLE(r1.application_ids);
         FOR i IN 1..apps_array.COUNT LOOP
            IF application_exists(p_application_id => apps_array(i)) THEN
               lv_clob := wwv_flow_utilities.export_application_to_clob(p_application_id => apps_array(i),
                                                                        p_export_ir_public_reports => 'Y',
                                                                        p_export_ir_private_reports => 'Y',
                                                                        p_export_ir_notifications => 'Y',
                                                                        p_export_translations => 'Y');
               -- Add CTRL-M for WINDOWS
               IF lv_os_type = 'WINDOWS' THEN
                  lv_clob := REPLACE(lv_clob, CHR(10), CHR(13)||CHR(10));
               END IF;
               aca_util.put_file(destination_file => lv_export_directory||lv_os_slash||'F'||apps_array(i)||'.sql',
                                 destination_host => NULL,
                                 credential_name => lv_os_credential_name,
                                 file_contents => lv_clob,
                                 destination_permissions => NULL);
               lv_log := lv_log||'Exported App: '||get_application_name(apps_array(i))||' (F'||apps_array(i)||'.sql)'||crlf;

               -- Get parsing schema
               lv_parsing_schema := get_parsing_schema(apps_array(i));
               IF INSTR(lv_parsing_schemas_exported, ':'||lv_parsing_schema||':') = 0 THEN
                  lv_parsing_schemas_exported := lv_parsing_schemas_exported||lv_parsing_schema||':';
                  lv_schemas := lv_schemas||','||lv_parsing_schema;
               END IF;

            END IF;
         END LOOP;
      ELSE
         OPEN c2;
         LOOP
            FETCH c2 INTO r2;
            EXIT WHEN c2%NOTFOUND;
            IF workspace_exists(p_workspace_id => r2.workspace_id) THEN
                APEX_UTIL.SET_SECURITY_GROUP_ID(r2.workspace_id);
               APEX_CUSTOM_AUTH.SET_USER(get_workspace_admin(p_workspace_id => r2.workspace_id));
               lv_clob := wwv_flow_utilities.export_workspace_to_clob(p_workspace_id => r2.workspace_id,
                                                                      p_include_team_development => TRUE,
                                                                      p_minimal => FALSE);
               -- Add CTRL-M for WINDOWS
               IF lv_os_type = 'WINDOWS' THEN
                  lv_clob := REPLACE(lv_clob, CHR(10), CHR(13)||CHR(10));
               END IF;
               aca_util.put_file(destination_file => lv_export_directory||lv_os_slash||r2.workspace||'.sql',
                                 destination_host => NULL,
                                 credential_name => lv_os_credential_name,
                                 file_contents => lv_clob,
                                 destination_permissions => NULL);
               lv_log := lv_log||'Exported Workspace: '||r2.workspace||'.sql'||crlf||crlf;
            END IF;

            OPEN c3;
            LOOP
               FETCH c3 INTO r3;
               EXIT WHEN c3%NOTFOUND;
               IF application_exists(p_application_id => r3.application_id) THEN
                  lv_clob := wwv_flow_utilities.export_application_to_clob(p_application_id => r3.application_id,
                                                                           p_export_ir_public_reports => 'Y',
                                                                           p_export_ir_private_reports => 'Y',
                                                                           p_export_ir_notifications => 'Y',
                                                                           p_export_translations => 'Y');
                  -- Add CTRL-M for WINDOWS
                  IF lv_os_type = 'WINDOWS' THEN
                     lv_clob := REPLACE(lv_clob, CHR(10), CHR(13)||CHR(10));
                  END IF;
                  aca_util.put_file(destination_file => lv_export_directory||lv_os_slash||'F'||r3.application_id||'.sql',
                                    destination_host => NULL,
                                    credential_name => lv_os_credential_name,
                                    file_contents => lv_clob,
                                    destination_permissions => NULL);
                  lv_log := lv_log||'Exported App: '||r3.application_name||' (F'||r3.application_id||'.sql)'||crlf;

                  -- Get parsing schema
                  lv_parsing_schema := get_parsing_schema(r3.application_id);
                  IF INSTR(lv_parsing_schemas_exported, ':'||lv_parsing_schema||':') = 0 THEN
                     lv_parsing_schemas_exported := lv_parsing_schemas_exported||lv_parsing_schema||':';
                     lv_schemas := lv_schemas||','||lv_parsing_schema;
                  END IF;

               END IF;
            END LOOP;
            CLOSE c3;
            lv_log := lv_log||crlf;
         END LOOP;
         CLOSE c2;
      END IF;

      -- Export parsing schema(s)
      IF r1.schema_export = 'YES' THEN
            SELECT aca_directory_seq.NEXTVAL INTO lv_directory_seq FROM DUAL;
            lv_directory := 'SBA_ADE_'||TO_CHAR(lv_directory_seq);
            lv_sql_statement := 'CREATE DIRECTORY '||lv_directory||' AS '''||lv_export_directory||'''';
            EXECUTE IMMEDIATE lv_sql_statement;
            BEGIN
               aca_datapump_util.run_export(p_template_name => 'EXPORT_TEMPLATE',
                                            p_name => lv_directory,
                                            p_description => lv_parsing_schema||' Data Pump Export',
                                            p_datapump_type => 'EXPORT',
                                            p_datapump_directory => lv_directory,
                                            p_dump_file => 'SCHEMAS_EXPORT_%U.dmp',
                                            p_log_file => 'SCHEMAS_EXPORT.log',
                                            p_compression => NULL,
                                            p_parallel_threads => NULL,
                                            p_max_filesize => NULL,
                                            p_estimate_only => 'NO',
                                            p_content => r1.schema_export_content,
                                            p_encryption => NULL,
                                            p_encryption_pwd => NULL,
                                            p_datapump_mode => 'SCHEMA',
                                            p_table_schema => NULL,
                                            p_schemas => SUBSTR(lv_schemas, 2),
                                            p_tables => NULL,
                                            p_tablespaces => NULL);
               lv_log := lv_log||'Started data pump export of parsing schema(s): '||SUBSTR(lv_schemas, 2);
               lv_log := lv_log||' Content: '||r1.schema_export_content||crlf;
            EXCEPTION
               WHEN OTHERS THEN
               aca_error_util.log_error(p_program_name => 'ACA_APEX_UTIL.EXPORT', p_error_text => SQLERRM);
               RAISE;
            END;
      END IF;

      aca_util.put_file(destination_file => lv_export_directory||lv_os_slash||'export.log',
                        destination_host => NULL,
                        credential_name => lv_os_credential_name,
                        file_contents => lv_log,
                        destination_permissions => NULL);

      aca_util.update_log_filename(p_name => p_name,
                                   p_log_filename => lv_export_directory||lv_os_slash||'export.log');

      IF  r1.retension_days IS NOT NULL THEN
         IF lv_os_type = 'WINDOWS' THEN
            aca_util.run_os_command(p_command => lv_os_scripts_directory||'\deleteAPEXexports.bat '||
                                                 lv_win_programs_path||' '||
                                                 lv_os_apex_directory||' '||
                                                 p_name||' '||TO_CHAR(r1.retension_days),
                                    p_credential_name => lv_os_credential_name);
         ELSE
            aca_util.run_os_command(p_command => lv_os_scripts_directory||'/deleteAPEXexports.sh '||
                                                 lv_os_home_directory||' '||
                                                 lv_os_apex_directory||' '||
                                                 p_name||' '||TO_CHAR(r1.retension_days),
                                    p_credential_name => lv_os_credential_name);
         END IF;
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_APEX_UTIL.EXPORT', p_error_text => SQLERRM);
      RAISE;
   END export;

   PROCEDURE schedule_export(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'APEX_EXPORT_TEMPLATE') IS
      --
      -- Purpose: To schedule an APEX export using a stored procedure template
      --    Note: Fails on APEX 5 - NOT USED
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/14/2015  Created
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_apex_export_schedules
       WHERE id = p_id;
      r1 c1%ROWTYPE;

      lv_raise_events PLS_INTEGER := DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED;

      subs ACA_UTIL.SUB_TAB;

      args ACA_UTIL.ARG_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      -- Fetch export schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      IF job_running(p_name => r1.name) THEN
         RETURN;
      END IF;

      args(inc(idx)).NAME    := 'NAME'; args(idx).value := r1.name;

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_arguments => args,
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => NULL,
                           p_job_execution => r1.job_execution,
                           p_repeat_interval => r1.repeat_interval,
                           p_start_date => r1.start_date,
                           p_end_date => r1.end_date,
                           p_completion_recipients => r1.completion_recipients,
                           p_success_recipients => r1.success_recipients,
                           p_failure_recipients => r1.failure_recipients,
                           p_notifications => 'YES',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_APEX_UTIL.SCHEDULE_EXPORT', p_error_text => SQLERRM);
      RAISE;
   END schedule_export;

   PROCEDURE schedule_export_exe(p_id IN NUMBER,
                                 p_template_name IN VARCHAR2 DEFAULT 'APEX_EXPORT_EXE_TEMPLATE') IS
      --
      -- Purpose: To schedule an APEX export using an executable template
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/15/2015  Created
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_apex_export_schedules
       WHERE id = p_id;
      r1 c1%ROWTYPE;

      lv_raise_events PLS_INTEGER := DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED;
      lv_username_password VARCHAR2(200);

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      -- Fetch export schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      IF job_running(p_name => r1.name) THEN
         RETURN;
      END IF;

      -- Get DB user and password
      lv_username_password := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                              aca_util.get_config_value(p_name => 'DB_PASSWORD');

      -- Add substitution strings
      subs(inc(idx)).name := 'NAME';              subs(idx).value := r1.name;
      subs(inc(idx)).name := 'USERNAME_PASSWORD'; subs(idx).value := lv_username_password;

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => NULL,
                           p_job_execution => r1.job_execution,
                           p_repeat_interval => r1.repeat_interval,
                           p_start_date => r1.start_date,
                           p_end_date => r1.end_date,
                           p_completion_recipients => r1.completion_recipients,
                           p_success_recipients => r1.success_recipients,
                           p_failure_recipients => r1.failure_recipients,
                           p_notifications => 'YES',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_APEX_UTIL.SCHEDULE_EXPORT_EXE', p_error_text => SQLERRM);
      RAISE;
   END schedule_export_exe;

END aca_apex_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_ASM_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: To provide utilities for ASM
   --
   -- MODIFICATION HISTORY
   -- Person                Date        Comments
   -- --------------------  ----------  ------------------------------------------
   -- Garry Lawton          01/01/2015  Re-Created
   --

   g_asm_user VARCHAR2 (100);
   g_asm_password VARCHAR2 (100);
   g_asm_jdbc_connect VARCHAR2 (100);

   PROCEDURE queryasm(p_username IN VARCHAR2,
                      p_password IN VARCHAR2,
                      p_database IN VARCHAR2,
                      p_query IN VARCHAR2,
                      p_report_name IN VARCHAR2,
                      p_session_id IN VARCHAR2) AS LANGUAGE JAVA
        NAME 'queryasm.main(java.lang.String[])';

   PROCEDURE l_any_dml_ddl(s1 IN VARCHAR2,
                           s2 IN VARCHAR2,
                           s3 IN VARCHAR2,
                           s4 IN VARCHAR2) AS LANGUAGE JAVA
      NAME 'any_dml_ddl.main(java.lang.String[])';

   PROCEDURE any_dml_ddl(p_stm IN VARCHAR2) IS
   BEGIN
      l_any_dml_ddl(g_asm_user,
                    g_asm_password,
                    g_asm_jdbc_connect,
                    p_stm);
   END any_dml_ddl;

   FUNCTION get_report_column_count (p_report_id IN NUMBER) RETURN NUMBER IS
      lv_count NUMBER := 0;
   BEGIN
      SELECT COUNT (1)
        INTO lv_count
        FROM aca_report_column_labels
       WHERE report_id = p_report_id;
      RETURN lv_count;
   END get_report_column_count;

   PROCEDURE execute_query(p_report_name IN VARCHAR2,
                           p_collection_name IN VARCHAR2 DEFAULT NULL,
                           p_a1 IN VARCHAR2 DEFAULT NULL,
                           p_a2 IN VARCHAR2 DEFAULT NULL,
                           p_a3 IN VARCHAR2 DEFAULT NULL,
                           p_a4 IN VARCHAR2 DEFAULT NULL) IS

      CURSOR report_cur IS
      SELECT *
        FROM aca_reports
       WHERE name = p_report_name;

      report_rec report_cur%ROWTYPE;

      lv_column_count NUMBER;
      lv_query VARCHAR2(32000) := 'SELECT A.* ';

   BEGIN
      OPEN report_cur;
         FETCH report_cur INTO report_rec;
      CLOSE report_cur;

      lv_column_count := get_report_column_count(report_rec.id);

      FOR i IN (lv_column_count + 1) .. 20 LOOP
         lv_query := lv_query||', NULL col'||i;
      END LOOP;

      lv_query := lv_query||' FROM (';
      lv_query := lv_query||report_rec.query||') A';

      lv_query := REPLACE(lv_query, '#A1#', p_a1); lv_query := REPLACE(lv_query, '#a1#', p_a1);
      lv_query := REPLACE(lv_query, '#A2#', p_a2); lv_query := REPLACE(lv_query, '#a2#', p_a2);
      lv_query := REPLACE(lv_query, '#A3#', p_a3); lv_query := REPLACE(lv_query, '#a3#', p_a3);
      lv_query := REPLACE(lv_query, '#A4#', p_a4); lv_query := REPLACE(lv_query, '#a4#', p_a4);

      DELETE FROM aca_any_result
       WHERE report_name = p_report_name
         AND session_id = V('APP_SESSION');

      queryasm(g_asm_user,
               g_asm_password,
               g_asm_jdbc_connect,
               lv_query,
               p_report_name,
               V('APP_SESSION'));

       IF p_collection_name IS NOT NULL THEN
         IF APEX_COLLECTION.COLLECTION_EXISTS(p_collection_name) THEN
            APEX_COLLECTION.DELETE_COLLECTION(p_collection_name);
         END IF;
         APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY_B(p_collection_name,
                                                        p_query   => 'SELECT col1,col2,col3,col4,col5,col6,col7,col8,col9,col10,col11,col12,col13,col14,col15,col16,col17,col18,col19,col20 FROM aca_any_result WHERE report_name='''
                        ||p_report_name
                        ||''' AND session_id = V(''APP_SESSION'')');
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ASM_UTIL.EXECUTE_QUERY', p_error_text => SQLERRM);
      RAISE;
   END execute_query;

   FUNCTION get_report_header(p_report_name IN VARCHAR2) RETURN VARCHAR2 IS
      CURSOR c1 IS
      SELECT B.label
        FROM aca_reports A, aca_report_column_labels B
       WHERE A.id = B.report_id AND A.name = p_report_name
       ORDER BY B.order_sequence;
      lv_report_heading   VARCHAR2 (32000);
   BEGIN
      FOR r1 IN c1 LOOP
         lv_report_heading := lv_report_heading || ':' || r1.label;
      END LOOP;
      RETURN SUBSTR (lv_report_heading, 2);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ASM_UTIL.GET_REPORT_HEADER', p_error_text => SQLERRM);
      RAISE;
   END get_report_header;

   PROCEDURE create_disk_group(p_name IN VARCHAR2,
                               p_redundancy IN VARCHAR2,
                               p_failure_group_type IN VARCHAR2,
                               p_disks IN VARCHAR2,
                               p_disks_fg1 IN VARCHAR2,
                               p_disks_fg2 IN VARCHAR2,
                               p_disks_fg3 IN VARCHAR2) IS
      disk_array APEX_APPLICATION_GLOBAL.VC_ARR2;
      lv_statement VARCHAR2(32000) := 'CREATE DISKGROUP '||p_name||' '||p_redundancy||' REDUNDANCY';
   BEGIN
      IF p_failure_group_type = 'AUTOMATIC' THEN
         lv_statement := lv_statement||' DISK ';
         disk_array := APEX_UTIL.STRING_TO_TABLE(p_disks);
         FOR i IN 1..disk_array.COUNT LOOP
            lv_statement := lv_statement||''''||disk_array(i)||''',';
         END LOOP;
         lv_statement := SUBSTR(lv_statement, 1, LENGTH(lv_statement) - 1);
      ELSE
         lv_statement := lv_statement||' FAILGROUP '||p_name||'_FG1 DISK ';
         disk_array := APEX_UTIL.STRING_TO_TABLE(p_disks_fg1);
         FOR i IN 1..disk_array.COUNT LOOP
            lv_statement := lv_statement||''''||disk_array(i)||''',';
         END LOOP;
         lv_statement := SUBSTR(lv_statement, 1, LENGTH(lv_statement) - 1);
         lv_statement := lv_statement||' FAILGROUP '||p_name||'_FG2 DISK ';
         disk_array := APEX_UTIL.STRING_TO_TABLE(p_disks_fg2);
         FOR i IN 1..disk_array.COUNT LOOP
            lv_statement := lv_statement||''''||disk_array(i)||''',';
         END LOOP;
         lv_statement := SUBSTR(lv_statement, 1, LENGTH(lv_statement) - 1);
         IF p_redundancy = 'HIGH' THEN
            lv_statement := lv_statement||' FAILGROUP '||p_name||'_FG3 DISK ';
            disk_array := APEX_UTIL.STRING_TO_TABLE(p_disks_fg3);
            FOR i IN 1..disk_array.COUNT LOOP
               lv_statement := lv_statement||''''||disk_array(i)||''',';
            END LOOP;
            lv_statement := SUBSTR(lv_statement, 1, LENGTH(lv_statement) - 1);
         END IF;
      END IF;
      -- DBMS_OUTPUT.PUT_LINE(lv_statement);
      any_dml_ddl(lv_statement);

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ASM_UTIL.CREATE_DISK_GROUP', p_error_text => SQLERRM);
      RAISE;
   END create_disk_group;

   PROCEDURE add_disk_to_group(p_name IN VARCHAR2,
                               p_failure_group IN VARCHAR2,
                               p_disk IN VARCHAR2) IS
      lv_statement VARCHAR2(32000) := 'ALTER DISKGROUP '||p_name||' ADD';
   BEGIN
      IF p_failure_group IS NULL THEN
         lv_statement := lv_statement||' DISK '||''''||p_disk||'''';
      ELSE
         lv_statement := lv_statement||' FAILGROUP '||p_failure_group||' DISK '||''''||p_disk||'''';
      END IF;
      -- DBMS_OUTPUT.PUT_LINE(lv_statement);
      any_dml_ddl(lv_statement);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ASM_UTIL.ADD_DISK_TO_GROUP', p_error_text => SQLERRM);
      RAISE;
   END add_disk_to_group;

   FUNCTION test_asm_settings(p_asm_hostname IN VARCHAR2,
                              p_asm_port IN VARCHAR2,
                              p_asm_sid IN VARCHAR2,
                              p_sysasm_user IN VARCHAR2,
                              p_sysasm_password IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To test the ASM connection and credentials.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   06/26/2015  Creation
      --
      lv_asm_jdbc_connect VARCHAR2(1000) := 'jdbc:oracle:thin:@//'||p_asm_hostname||':'||p_asm_port||'/'||p_asm_sid;
      lv_session_id VARCHAR2(20) := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
      lv_column_count NUMBER := 1;
      lv_query VARCHAR2(32000) := 'SELECT A.* ';
   BEGIN

      FOR i IN (lv_column_count + 1) .. 20 LOOP
         lv_query := lv_query||', NULL col'||i;
      END LOOP;

      lv_query := lv_query||' FROM (';
      lv_query := lv_query||'SELECT 1 FROM DUAL) A';

      queryasm(p_sysasm_user||' AS SYSASM',
               p_sysasm_password,
               lv_asm_jdbc_connect,
               lv_query,
               'TEST_ASM',
               lv_session_id);

      DELETE FROM aca_any_result
       WHERE report_name = 'TEST_ASM'
         AND session_id = lv_session_id;

      RETURN NULL;

   EXCEPTION
      WHEN OTHERS THEN
      DELETE FROM aca_any_result
       WHERE report_name = 'TEST_ASM'
         AND session_id = lv_session_id;
      RETURN 'Could not query the ASM instance with the credentials given. '||SQLERRM;
   END test_asm_settings;

BEGIN
   g_asm_user := aca_util.get_config_value('ASM_SYSASM_USER')||' AS SYSASM';
   g_asm_password := aca_util.get_config_value('ASM_SYSASM_PASSWORD');
   g_asm_jdbc_connect := 'jdbc:oracle:thin:@//'
                       ||aca_util.get_config_value('ASM_HOSTNAME')
                       ||':'
                       ||aca_util.get_config_value('ASM_PORT')
                       ||'/'
                       ||aca_util.get_config_value('ASM_SID');
END aca_asm_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_BACKUP_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   FUNCTION maxpiecesize_set RETURN BOOLEAN IS
      --
      -- Purpose: To check if MAXPIECESIZE is set in the RMAN configuration
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   03/25/2015  Creation
      --
      lv_maxpiecesize VARCHAR2(30);
   BEGIN
      SELECT CASE WHEN aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%FORMAT%') IS NULL THEN
                nth_str(aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%MAXPIECESIZE%'), 5)
             ELSE
                nth_str(aca_rman_config.get_config_value(p_name => 'CHANNEL', p_value_like => '%MAXPIECESIZE%'), 7)
             END maxpiecesize INTO lv_maxpiecesize FROM DUAL;
      IF lv_maxpiecesize IS NOT NULL THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_BACKUP_UTIL.MAXPIECESIZE_SET', p_error_text => SQLERRM);
      RAISE;
   END maxpiecesize_set;

   PROCEDURE schedule_backup(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'BACKUP_TEMPLATE') IS
      --
      -- Purpose: To schedule a regular backup
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   03/25/2015  Re-created
      -- GL Skillbuilders   05/05/2015  Added Tape (Media Manager) backup
      -- GL Skillbuilders   03/08/2016  Added delete_archive_log
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_backup_schedules
       WHERE id = p_id;
      r1 c1%ROWTYPE;

      CURSOR c2 IS
      SELECT *
        FROM aca_rman_config_view;
      r2 c2%ROWTYPE;


      lv_command_code VARCHAR2(32000);
      lv_backup_tag VARCHAR2(40);
      lv_section_size VARCHAR2(40);
      lv_raise_events PLS_INTEGER := DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED;
      lv_username_password VARCHAR2(4000) := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                                             aca_util.get_config_value(p_name => 'DB_PASSWORD');

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 1;
      crlf VARCHAR2(2) := '
';

   BEGIN

      -- Fetch backup schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      -- Build RMAN command code

      -- Add Tag for backup sets
      IF TRIM(r1.backup_tag) IS NOT NULL AND r1.backup_type != 'COPY' THEN
         lv_backup_tag   := ' TAG '''||r1.backup_tag||'''';
      END IF;

      -- Section Size
      IF TRIM(r1.section_size) IS NOT NULL AND NOT maxpiecesize_set THEN
         lv_section_size := ' SECTION SIZE '||TRIM(TO_CHAR(r1.section_size))||'M';
      END IF;

      lv_command_code := lv_command_code||'RUN{'||crlf;

      IF r1.backup_media = 'DISK' THEN
         -- Disk Location
         IF r1.backup_location_spec = 'FRA' THEN
            lv_command_code := lv_command_code||'ALLOCATE CHANNEL D1 TYPE DISK;'||crlf;
         ELSIF r1.backup_location_spec = 'DIR' THEN
            lv_command_code := lv_command_code||'ALLOCATE CHANNEL D1 TYPE DISK FORMAT '''||r1.backup_location||'%U'';'||crlf;
         ELSIF r1.backup_location_spec = 'RMAN' THEN
            NULL; -- Use RMAN configuration
         END IF;
      ELSIF r1.backup_media = 'SBT_TAPE' THEN
         OPEN c2;
            FETCH c2 INTO r2;
         CLOSE C2;
         lv_command_code := lv_command_code||'ALLOCATE CHANNEL T1 TYPE SBT_TAPE PARMS '||r2.tape_parameters||';'||crlf;
      END IF;

      lv_command_code := lv_command_code||'REPORT SCHEMA;'||crlf;

      -- Datafiles
      IF r1.backup_database = 'YES' THEN
         IF r1.backup_method = 'FULL' THEN
            lv_command_code := lv_command_code||'BACKUP AS '||r1.backup_type||' DATABASE'||lv_backup_tag||lv_section_size||';'||crlf;
         ELSE
            lv_command_code := lv_command_code||'BACKUP AS '||r1.backup_type||' '||r1.backup_method||' DATABASE'||lv_backup_tag||lv_section_size||';'||crlf;
         END IF;
      END IF;

      -- Archive Logs
      IF r1.backup_archive_log = 'YES' THEN
         IF r1.delete_archive_log = 'YES' THEN
            lv_command_code := lv_command_code||'BACKUP AS '||r1.backup_type||' ARCHIVELOG ALL DELETE ALL INPUT'||lv_backup_tag||';'||crlf;
         ELSE
            lv_command_code := lv_command_code||'BACKUP AS '||r1.backup_type||' ARCHIVELOG ALL '||lv_backup_tag||';'||crlf;
         END IF;
      END IF;

      -- Control Files
      IF r1.backup_controlfile = 'YES' THEN
         lv_command_code := lv_command_code||'BACKUP AS '||r1.backup_type||' CURRENT CONTROLFILE '||lv_backup_tag||';'||crlf;
      END IF;

      IF r1.crosscheck = 'YES' THEN
         lv_command_code := lv_command_code||'CROSSCHECK BACKUPSET;'||crlf;
      END IF;

      IF r1.delete_expired_backup = 'YES' THEN
         lv_command_code := lv_command_code||'DELETE NOPROMPT EXPIRED BACKUPSET;'||crlf;
      END IF;

      IF r1.delete_obsolete_backup = 'YES' THEN
         lv_command_code := lv_command_code||'DELETE NOPROMPT OBSOLETE;'||crlf;
      END IF;

      lv_command_code := lv_command_code||'RESTORE DATABASE VALIDATE;'||crlf;
      lv_command_code := lv_command_code||'}'||crlf;

      -- Make string substitutions

      subs(idx).name := 'NAME'; subs(idx).value := r1.name; idx := idx + 1;
      subs(idx).name := 'USERNAME_PASSWORD'; subs(idx).value := lv_username_password; idx := idx + 1;

      -- Schedule Backup

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => lv_command_code,
                           p_job_execution => r1.job_execution,
                           p_repeat_interval => r1.repeat_interval,
                           p_start_date => r1.start_date,
                           p_end_date => r1.end_date,
                           p_completion_recipients => r1.completion_recipients,
                           p_success_recipients => r1.success_recipients,
                           p_failure_recipients => r1.failure_recipients,
                           p_notifications => 'YES',
                           p_log_run => 'YES');

      COMMIT;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_BACKUP_UTIL.SCHEDULE_BACKUP', p_error_text => SQLERRM);
      RAISE;
   END schedule_backup;

   PROCEDURE refresh_aca_backup_sets IS
      --
      -- Purpose: To refresh the data in table aca_backup_sets. This table is used
      --          for the backup sets report.
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/13/2015  Creation
      --
   BEGIN
      EXECUTE IMMEDIATE 'TRUNCATE TABLE aca_backup_sets';
      INSERT INTO aca_backup_sets (recid, tag, completion_time, file_type,
                                   device_type, status, keep, pieces)
      SELECT A.recid,
             B.bs_tag tag,
             MAX(C.completion_time) completion_time,
             B.file_type,
             C.device_type,
             C.status,
             A.keep,
             A.pieces
        FROM v$backup_set A,
             v$backup_files B,
             v$backup_piece_details C
       WHERE A.recid = B.bs_key
         AND A.recid = C.bs_key
         AND B.file_type <> 'PIECE'
       GROUP BY A.recid,
                B.bs_tag,
                B.file_type,
                C.device_type,
                C.status,
                A.keep,
                A.pieces
       ORDER BY 1;
       COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_BACKUP_UTIL.REFRESH_ACA_BACKUP_SETS', p_error_text => SQLERRM);
      RAISE;
   END refresh_aca_backup_sets;

END aca_backup_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_CLONE_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   FUNCTION build_command_code(p_name IN VARCHAR2,
                               p_new_filenames IN VARCHAR2 DEFAULT 'YES') RETURN VARCHAR2 IS
      --
      -- Purpose: To build the RMAN command code for the database clone
      --    Note: Direct GRANT SELECT ON v_$datafile and v_$tempfile by SYS
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   04/07/2015  Created
      --

      CURSOR c1 IS
      SELECT file#, name
        FROM v$DATAFILE
       ORDER BY file#;
      r1 c1%ROWTYPE;

      CURSOR c2 IS
      SELECT file#, name
        FROM v$tempfile
       ORDER BY file#;
      r2 c2%ROWTYPE;

      CURSOR c3 IS
      SELECT *
        FROM aca_clone_schedules
       WHERE name = p_name;
      r3 c3%ROWTYPE;

      CURSOR c4 IS
      SELECT *
        FROM aca_clone_filename_subs
       WHERE clone_schedule_id = r3.id
       ORDER BY substitute_from;
      r4 c4%ROWTYPE;

      lv_group_number NUMBER(1,0);

      CURSOR c5 IS
      SELECT *
        FROM aca_clone_logfiles
       WHERE clone_schedule_id = r3.id
         AND group_number = lv_group_number
       ORDER BY filename;
      r5 c5%ROWTYPE;

      CURSOR c6 IS
      SELECT DISTINCT group_number
        FROM aca_clone_logfiles
       WHERE clone_schedule_id = r3.id
       ORDER BY 1;
      r6 c6%ROWTYPE;

      lv_slash VARCHAR2(1) := '/';
      lv_command_code VARCHAR2(32000);
      lv_tempfile_name VARCHAR2(200) := '_'||DBMS_RANDOM.STRING('L', 12)||'.tmp';
      lv_logfile_group_count NUMBER(1,0) := 0;
      lv_logfiles_group1 VARCHAR2(4000);
      lv_logfiles_group2 VARCHAR2(4000);
      lv_logfiles_group3 VARCHAR2(4000);
      lv_logfiles_group4 VARCHAR2(4000);
      lv_asm_name VARCHAR2(30);
      lv_substitution_found NUMBER(1) := 0;
      crlf VARCHAR2(2) := CHR(10);

   BEGIN

      -- Get clone schedule
      OPEN c3;
         FETCH c3 INTO r3;
      CLOSE c3;

      -- Set backslash
      IF aca_util.get_config_value('OS_TYPE') = 'WINDOWS' THEN
         lv_slash := '\';
         crlf := CHR(13)||CHR(10);
      END IF;

      lv_command_code := lv_command_code||'RUN{'||crlf;

      -- Datafiles
      FOR r1 IN c1 LOOP

         lv_substitution_found := 0;

         FOR r4 IN c4 LOOP
            IF r1.name LIKE '+%' THEN -- ASM - Remove path if there is a substitution
               lv_asm_name := SUBSTR(r1.name, 1, INSTR(r1.name, lv_slash) - 1);
               IF r4.substitute_from = lv_asm_name THEN
                  r1.name := lv_asm_name;
                  lv_substitution_found := 1;
               END IF;
            ELSE
               IF r1.NAME LIKE '%'||r4.substitute_from||'%' THEN
                  lv_substitution_found := 1;
               END IF;
            END IF;
         END LOOP;

          IF p_new_filenames = 'YES' OR lv_substitution_found = 1 THEN
            lv_command_code := lv_command_code||'SET NEWNAME FOR DATAFILE '||TO_CHAR(r1.file#)||
                                             ' TO '''||r1.name||''';'||crlf;
          END IF;

      END LOOP;

     -- Tempfiles

      FOR r2 IN c2 LOOP

         lv_substitution_found := 0;

         FOR r4 IN c4 LOOP
            IF r2.name LIKE '+%' THEN -- ASM - Remove path if there is a substitution
               lv_asm_name := SUBSTR(r2.name, 1, INSTR(r2.name, lv_slash) - 1);
               IF r4.substitute_from = lv_asm_name THEN
                  r2.name := lv_asm_name;
                  lv_substitution_found := 1;
               END IF;
            ELSE
               IF r2.NAME LIKE '%'||r4.substitute_from||'%' THEN
                  lv_substitution_found := 1;
               END IF;
            END IF;
         END LOOP;

         IF p_new_filenames = 'YES' OR lv_substitution_found = 1 THEN
            lv_command_code := lv_command_code||'SET NEWNAME FOR TEMPFILE '||TO_CHAR(r2.file#)||
                                                ' TO '''||SUBSTR(r2.name, 1, INSTR(r2.name, lv_slash, - 1))||
                                                'temp'||TO_CHAR(r2.file#)||lv_tempfile_name||''';'||crlf;
         END IF;

      END LOOP;

      -- Make filename substitutions

      FOR r4 IN c4 LOOP
         lv_command_code := REPLACE(lv_command_code, r4.substitute_from, r4.substitute_to);
      END LOOP;

      -- Duplicate to Destination DB
      lv_command_code := lv_command_code||'DUPLICATE TARGET DATABASE TO '||r3.destination_db_name||' FROM ACTIVE DATABASE'||crlf;

      -- Filename check
      IF r3.filename_check = 'NO' THEN
         lv_command_code := lv_command_code||'NOFILENAMECHECK'||crlf;
      END IF;


      -- Logfiles
      lv_command_code := lv_command_code||'LOGFILE'||crlf;

      FOR i IN 1..4 LOOP
         lv_group_number := i;
         FOR r5 IN c5 LOOP
            CASE
               WHEN i = 1 THEN lv_logfiles_group1 := lv_logfiles_group1||','''||r5.filename||'''';
               WHEN i = 2 THEN lv_logfiles_group2 := lv_logfiles_group2||','''||r5.filename||'''';
               WHEN i = 3 THEN lv_logfiles_group3 := lv_logfiles_group3||','''||r5.filename||'''';
               WHEN i = 4 THEN lv_logfiles_group4 := lv_logfiles_group4||','''||r5.filename||'''';
            END CASE;
         END LOOP;
      END LOOP;

      FOR r6 IN c6 LOOP
         lv_logfile_group_count := lv_logfile_group_count + 1;
         IF lv_logfile_group_count > 1 THEN
            lv_command_code := lv_command_code||','||crlf;
         END IF;
         CASE
            WHEN r6.group_number = 1 THEN lv_command_code := lv_command_code||
                 'GROUP 1 ('||SUBSTR(lv_logfiles_group1, 2)||') SIZE '||TO_CHAR(r3.destination_logfile_size)||'M';
            WHEN r6.group_number = 2 THEN lv_command_code := lv_command_code||
                 'GROUP 2 ('||SUBSTR(lv_logfiles_group2, 2)||') SIZE '||TO_CHAR(r3.destination_logfile_size)||'M';
            WHEN r6.group_number = 3 THEN lv_command_code := lv_command_code||
                 'GROUP 3 ('||SUBSTR(lv_logfiles_group3, 2)||') SIZE '||TO_CHAR(r3.destination_logfile_size)||'M';
            WHEN r6.group_number = 4 THEN lv_command_code := lv_command_code||
                 'GROUP 4 ('||SUBSTR(lv_logfiles_group4, 2)||') SIZE '||TO_CHAR(r3.destination_logfile_size)||'M';
         END CASE;
      END LOOP;

      lv_command_code := lv_command_code||';'||crlf;
      lv_command_code := lv_command_code||'}'||crlf;

      RETURN lv_command_code;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_CLONE_UTIL.BUILD_COMMAND_CODE', p_error_text => SQLERRM);
      RAISE;
   END build_command_code;

   PROCEDURE schedule_clone(p_id IN NUMBER,
                            p_template_name IN VARCHAR2 DEFAULT 'CLONE_TEMPLATE') IS
      --
      -- Purpose: To schedule a database clone
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   04/07/2015  Created
      -- GL Skillbuilders   12/02/2015  Added DESTINATION_DB_NAME
      CURSOR c1 IS
      SELECT *
        FROM aca_clone_schedules
       WHERE id = p_id;
      r1 c1%ROWTYPE;

      lv_command_code VARCHAR2(32000);
      lv_raise_events PLS_INTEGER := DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED;

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 1;
      crlf VARCHAR2(2) := '
';

   BEGIN

      -- Fetch clone schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      -- Build RMAN command code

      lv_command_code := build_command_code(p_name => r1.NAME,
                                            p_new_filenames => 'YES');

      -- Make string substitutions

      subs(idx).name := 'NAME'; subs(idx).value := r1.name; idx := idx + 1;
      subs(idx).name := 'SYS_PASSWORD'; subs(idx).value := r1.sys_password; idx := idx + 1;
      subs(idx).name := 'SOURCE_TNS_NAME'; subs(idx).value := r1.source_tns_name; idx := idx + 1;
      subs(idx).name := 'DESTINATION_TNS_NAME'; subs(idx).value := r1.destination_tns_name; idx := idx + 1;
      subs(idx).name := 'DESTINATION_DB_NAME'; subs(idx).value := r1.destination_db_name; idx := idx + 1;

     -- Schedule Clone

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => lv_command_code,
                           p_job_execution => r1.job_execution,
                           p_repeat_interval => r1.repeat_interval,
                           p_start_date => r1.start_date,
                           p_end_date => r1.end_date,
                           p_completion_recipients => r1.completion_recipients,
                           p_success_recipients => r1.success_recipients,
                           p_failure_recipients => r1.failure_recipients,
                           p_notifications => 'YES',
                           p_log_run => 'YES');

      COMMIT;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_CLONE_UTIL.SCHEDULE_CLONE', p_error_text => SQLERRM);
      RAISE;
   END schedule_clone;

   PROCEDURE rewrite_command_file(p_name IN VARCHAR2) IS
      --
      -- Purpose: To rewrite the RMAN command file for a database clone
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   04/08/2015  Created
      -- GL Skillbuilders   02/11/2016  Replaced call to DBMS_SCHEDULER.PUT_FILE
      --                                with ACA_UTIL.PUT_FILE
      --
      CURSOR c1 IS
      SELECT job_execution
        FROM aca_clone_schedules
       WHERE name = p_name;
      r1 c1%ROWTYPE;

      lv_command_code VARCHAR2(32000);
      lv_slash VARCHAR2(1) := '/';

   BEGIN
      -- Fetch clone schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      -- Set backslash
      IF aca_util.get_config_value('OS_TYPE') = 'WINDOWS' THEN
         lv_slash := '\';
      END IF;

      IF r1.job_execution = 'SCHEDULE' THEN
         -- Build RMAN command code
         lv_command_code := build_command_code(p_name => p_name);
         -- Rewrite command file
         aca_util.put_file(destination_file => aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY')||lv_slash||p_name||'.rman',
                           destination_host => NULL,
                           credential_name => aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME'),
                           file_contents => lv_command_code,
                           destination_permissions => NULL);
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_CLONE_UTIL.REWRITE_COMMAND_FILE', p_error_text => SQLERRM);
      RAISE;
   END rewrite_command_file;

END aca_clone_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_DATABASE_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   FUNCTION valid_object_name(p_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To check if a name is a valid Oracle object name.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/09/2015  Created
      --
      lv_name VARCHAR2(30);
   BEGIN
      SELECT DBMS_ASSERT.SIMPLE_SQL_NAME(p_name) INTO lv_name FROM DUAL;
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN RETURN FALSE;
   END valid_object_name;

   PROCEDURE reorg_objects(p_object_type IN VARCHAR2,
                           p_object_list IN APEX_APPLICATION_GLOBAL.VC_ARR2) IS
      --
      -- Purpose: To reorganize or compile an object.
      --    Note: Does not work with temporary tables. ToDo.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/09/2015  Created
      -- G. Lawton  - Skillbuilders    08/31/2015  Removed logging
      --

      lv_statement VARCHAR2(4000);
      lv_statement2 VARCHAR2(4000);

   BEGIN
      CASE p_object_type
         WHEN 'TABLE' THEN
            lv_statement := 'ALTER TABLE # ENABLE ROW MOVEMENT';
            lv_statement2 := 'ALTER TABLE # SHRINK SPACE CASCADE';
         WHEN 'INDEX' THEN
            IF aca_util.get_config_value('DB_EDITION') = 'ENTERPRISE' THEN
               lv_statement := 'ALTER INDEX # REBUILD ONLINE NOLOGGING';
            ELSE
               lv_statement := 'ALTER INDEX # REBUILD NOLOGGING';
            END IF;
         WHEN 'PACKAGE' THEN
            lv_statement := 'ALTER PACKAGE # COMPILE';
         WHEN 'PACKAGE BODY' THEN
            lv_statement := 'ALTER PACKAGE # COMPILE BODY';
         WHEN 'PROCEDURE' THEN
            lv_statement := 'ALTER PROCEDURE # COMPILE';
         WHEN 'FUNCTION' THEN
            lv_statement := 'ALTER FUNCTION # COMPILE';
         WHEN 'TRIGGER' THEN
            lv_statement := 'ALTER TRIGGER # COMPILE';
         WHEN 'VIEW' THEN
            lv_statement := 'ALTER VIEW # COMPILE';
      END CASE;

      FOR i IN 1 .. p_object_list.COUNT LOOP
         IF lv_statement IS NOT NULL AND NOT p_object_list (i) LIKE '%.ACA_DATABASE_UTIL' THEN
            EXECUTE IMMEDIATE REPLACE (lv_statement, '#', p_object_list (i));
            IF lv_statement2 IS NOT NULL THEN
               EXECUTE IMMEDIATE REPLACE (lv_statement2, '#', p_object_list (i));
            END IF;
         END IF;
      END LOOP;

   EXCEPTION
      WHEN OTHERS THEN
      -- Removed to prevent logging when compilation fails.
      -- aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.REORG_OBJECTS', p_error_text => SQLERRM);
      RAISE;
   END reorg_objects;

   FUNCTION directory_exists(p_directory_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a directory exists
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/22/2015  Creation
      --
      CURSOR c1 IS
      SELECT 1
        FROM dba_directories
       WHERE directory_name = p_directory_name;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.DIRECTORY_EXISTS', p_error_text => SQLERRM);
      RAISE;
   END directory_exists;

   FUNCTION test_directory(p_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if it is possible to access an Oracle directory.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/09/2015  Created
      --
      lv_file_handle UTL_FILE.FILE_TYPE;
      lv_name VARCHAR2(30) := UPPER(p_name);
   BEGIN
      lv_file_handle := UTL_FILE.fopen (lv_name, 'dummy.txt', 'w');
      UTL_FILE.put_line (lv_file_handle,
                         'test ' || TO_CHAR (SYSDATE, 'dd-mon-yyyy hh24:mi:ss'));
      UTL_FILE.fclose (lv_file_handle);
      UTL_FILE.fremove (lv_name, 'dummy.txt');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN FALSE;
   END test_directory;

   PROCEDURE create_directory(p_name IN VARCHAR2, p_path IN VARCHAR2) IS
      --
      -- Purpose: To create an Oracle directory.
      --   Usage: Application: ACA
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/09/2015  Created
      -- G. Lawton  - Skillbuilders    05/12/2015  Added aca_directories
      -- G. Lawton  - Skillbuilders    11/10/2015  Removed aca_directories
      -- G. Lawton  - Skillbuilders    11/17/2015  Changed -20001 error message
      --
      lv_sql_statement VARCHAR2(200);
      lv_name VARCHAR2(30) := UPPER(p_name);
      directory_error EXCEPTION;
      PRAGMA EXCEPTION_INIT(directory_error, -20001);
   BEGIN
      IF valid_object_name(lv_name) THEN
         lv_sql_statement := 'CREATE DIRECTORY '||lv_name||' AS '''||p_path||'''';
         EXECUTE IMMEDIATE lv_sql_statement;
         IF NOT test_directory(lv_name) THEN
            EXECUTE IMMEDIATE 'DROP DIRECTORY ' || lv_name;
            raise_application_error (-20001, 'Could not write to directory '||lv_name||' using '||p_path||'. Please check OS path and/or priviledges.');
         END IF;
      END IF;
   EXCEPTION
      WHEN directory_error THEN
      RAISE;
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CREATE_DIRECTORY', p_error_text => SQLERRM);
      RAISE;
   END create_directory;

   PROCEDURE drop_directory(p_name IN VARCHAR2) IS
      --
      -- Purpose: To drop an Oracle directory.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/09/2015  Created
      --
      lv_name VARCHAR2(30) := UPPER(p_name);
   BEGIN
      IF valid_object_name(lv_name) AND directory_exists(p_directory_name => p_name) THEN
         EXECUTE IMMEDIATE 'DROP DIRECTORY '||lv_name;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.DROP_DIRECTORY', p_error_text => SQLERRM);
      RAISE;
   END drop_directory;

   PROCEDURE create_app_datapump_dir IS
      --
      -- Purpose: To create the configured datapump directory
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/22/2015  Creation
      -- GL Skillbuilders   11/10/2015  Removed aca_directories
      --
      lv_data_pump_directory VARCHAR2(30) := aca_util.get_config_value(p_name => 'DATA_PUMP_DIRECTORY');
      lv_data_pump_directory_path VARCHAR2(1000) := aca_util.get_config_value(p_name => 'DATA_PUMP_DIRECTORY_PATH');
   BEGIN
      IF directory_exists(p_directory_name => lv_data_pump_directory) THEN
         drop_directory(p_name => lv_data_pump_directory);
      END IF;
      create_directory(p_name => lv_data_pump_directory,
                       p_path => lv_data_pump_directory_path);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CREATE_APP_DATAPUMP_DIR', p_error_text => SQLERRM);
      RAISE;
   END create_app_datapump_dir;

   FUNCTION user_exists(p_username IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if an Oracle User exists.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    01/22/2015  Creation
      --
      CURSOR c1 IS
      SELECT 1
        FROM all_users
       WHERE username = UPPER(p_username);
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.USER_EXISTS', p_error_text => SQLERRM);
      RAISE;
   END user_exists;

   PROCEDURE create_user(p_username IN VARCHAR2,
                         p_password IN VARCHAR2,
                         p_password_expired IN VARCHAR2,
                         p_account_locked IN VARCHAR2,
                         p_default_tablespace IN VARCHAR2,
                         p_temporary_tablespace IN VARCHAR2) IS
      --
      -- Purpose: To create an Oracle User account.
      --   Usage: Application: SBA Page: 82  Process: CREATE_USER
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    01/22/2015  Creation
      --
   BEGIN
      EXECUTE IMMEDIATE  'CREATE USER '||p_username||' IDENTIFIED BY '||p_password;
      IF p_password_expired = 'YES' THEN
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' PASSWORD EXPIRE';
      END IF;
      IF p_account_locked = 'YES' THEN
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' ACCOUNT LOCK';
      ELSE
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' ACCOUNT UNLOCK';
      END IF;
      EXECUTE IMMEDIATE  'ALTER USER '||p_username||' DEFAULT TABLESPACE '||p_default_tablespace;
      EXECUTE IMMEDIATE  'ALTER USER '||p_username||' TEMPORARY TABLESPACE '||p_temporary_tablespace;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CREATE_USER', p_error_text => SQLERRM);
      RAISE;
   END create_user;

   PROCEDURE alter_user(p_username IN VARCHAR2,
                        p_password IN VARCHAR2,
                        p_password_expired IN VARCHAR2,
                        p_account_locked IN VARCHAR2,
                        p_default_tablespace IN VARCHAR2,
                        p_temporary_tablespace IN VARCHAR2) IS
      --
      -- Purpose: To alter an Oracle User.
      --   Usage: Application: SBA Page: 82  Process: ALTER_USER
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    01/21/2015  Creation
      --
   BEGIN
      IF p_password IS NOT NULL THEN
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' IDENTIFIED BY '||p_password;
      END IF;
      IF p_password_expired = 'YES' THEN
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' PASSWORD EXPIRE';
      END IF;
      IF p_account_locked = 'YES' THEN
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' ACCOUNT LOCK';
      ELSE
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' ACCOUNT UNLOCK';
      END IF;
      EXECUTE IMMEDIATE  'ALTER USER '||p_username||' DEFAULT TABLESPACE '||p_default_tablespace;
      EXECUTE IMMEDIATE  'ALTER USER '||p_username||' TEMPORARY TABLESPACE '||p_temporary_tablespace;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.ALTER_USER', p_error_text => SQLERRM);
      RAISE;
   END alter_user;

   PROCEDURE set_roles_granted(p_username IN VARCHAR2,
                               p_roles_granted IN VARCHAR2) IS
      --
      -- Purpose: To set roles granted to a user.
      --   Usage: Application: SBA Page: 82  Process: SET_ROLES_GRANTED
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    01/22/2015  Creation
      -- G. Lawton  - Skillbuilders    10/29/2015  Removed Role DBA exclusion
      --
      roles_granted_array APEX_APPLICATION_GLOBAL.VC_ARR2 := APEX_UTIL.STRING_TO_TABLE(UPPER(p_roles_granted));
   BEGIN
      FOR r1 IN (SELECT granted_role
                   FROM dba_role_privs
                  WHERE grantee = UPPER(p_username)
                    AND INSTR(':'||UPPER(p_roles_granted)||':', ':'||granted_role||':') = 0) LOOP
         EXECUTE IMMEDIATE  'REVOKE '||r1.granted_role||' FROM '||p_username;
      END LOOP;
      FOR i IN 1 .. roles_granted_array.COUNT LOOP
         EXECUTE IMMEDIATE  'GRANT '||roles_granted_array(i)||' TO '||p_username;
      END LOOP;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SET_ROLES_GRANTED', p_error_text => SQLERRM);
      RAISE;
   END set_roles_granted;

   PROCEDURE set_sys_privs(p_username IN VARCHAR2,
                           p_sys_privs IN VARCHAR2) IS
      --
      -- Purpose: To set system privileges granted to a user.
      --   Usage: Application: SBA Page: 82  Process: SET_SYS_PRIVS
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    01/22/2015  Creation
      --
      sys_privs_array APEX_APPLICATION_GLOBAL.VC_ARR2 := APEX_UTIL.STRING_TO_TABLE(UPPER(p_sys_privs));
   BEGIN
      FOR r1 IN (SELECT privilege
                   FROM dba_sys_privs
                  WHERE grantee = UPPER(p_username)
                    AND INSTR(':'||UPPER(p_sys_privs)||':', ':'||privilege||':') = 0) LOOP
         IF r1.privilege NOT LIKE 'SYS%' THEN
            EXECUTE IMMEDIATE  'REVOKE '||r1.privilege||' FROM '||p_username;
         END IF;
      END LOOP;
      FOR i IN 1 .. sys_privs_array.COUNT LOOP
         IF sys_privs_array(i) NOT LIKE 'SYS%' THEN
            EXECUTE IMMEDIATE  'GRANT '||sys_privs_array(i)||' TO '||p_username;
         END IF;
      END LOOP;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SET_SYS_PRIVS', p_error_text => SQLERRM);
      RAISE;
   END set_sys_privs;

   PROCEDURE set_tablespace_quotas(p_username IN VARCHAR2) IS
      --
      -- Purpose: To set tablespace quota for a user.
      --   Usage: Application: SBA Page: 82  Process: SET_TABLESPACE_QUOTAS
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    01/26/2015  Creation
      --
   BEGIN
      FOR i in 1..APEX_APPLICATION.G_F01.COUNT LOOP
          EXECUTE IMMEDIATE  'ALTER USER '||p_username||' QUOTA '||NVL(APEX_APPLICATION.G_F03(i), 0)||'M ON '||APEX_APPLICATION.G_F01(i);
      END LOOP;
      FOR i in 1..APEX_APPLICATION.G_F02.COUNT LOOP
         EXECUTE IMMEDIATE  'ALTER USER '||p_username||' QUOTA UNLIMITED ON '||APEX_APPLICATION.G_F02(i);
      END LOOP;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SET_TABLESPACE_QUOTAS', p_error_text => SQLERRM);
      RAISE;
   END set_tablespace_quotas;

   PROCEDURE create_tablespace(p_tablespace_name IN VARCHAR2,
                               p_tablespace_type IN VARCHAR2,
                               p_use_omf IN VARCHAR2,
                               p_use_asm IN VARCHAR2,
                               p_asm_disk_group IN VARCHAR2,
                               p_init_size IN NUMBER,
                               p_autoextend IN VARCHAR2,
                               p_inc_by IN NUMBER,
                               p_max_size IN NUMBER,
                               p_filename IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To create a tablespace.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    02/28/2015  Creation
      --
      lv_statement VARCHAR2(4000);
      lv_filename VARCHAR2(200) := p_filename;
      lv_filesize_spec VARCHAR2 (2000);
   BEGIN

      IF p_autoextend = 'YES' THEN
         lv_filesize_spec :=  p_init_size||' M AUTOEXTEND ON NEXT '||p_inc_by||
                              ' M MAXSIZE '|| p_max_size||' M';
      ELSE
         lv_filesize_spec := p_init_size || ' M';
      END IF;

      IF p_use_asm = 'YES' THEN
         lv_filename := p_asm_disk_group;
      END IF;

      IF p_tablespace_type = 'PERMANENT' THEN
         lv_statement := 'CREATE TABLESPACE '||p_tablespace_name;
      ELSE
         lv_statement := 'CREATE '||p_tablespace_type||' TABLESPACE '||p_tablespace_name;
      END IF;

      IF p_use_omf = 'YES' THEN
         IF p_tablespace_type IN ('PERMANENT', 'UNDO') THEN
            lv_statement :=  lv_statement||' DATAFILE SIZE '||lv_filesize_spec;
         ELSIF p_tablespace_type = 'TEMPORARY' THEN
            lv_statement :=  lv_statement||' TEMPFILE SIZE '||lv_filesize_spec;
         END IF;
      ELSE
         IF p_tablespace_type IN ('PERMANENT', 'UNDO') THEN
            lv_statement :=  lv_statement||' DATAFILE '''||lv_filename||''' SIZE '||lv_filesize_spec;
         ELSIF p_tablespace_type = 'TEMPORARY' THEN
            lv_statement :=  lv_statement||' TEMPFILE '''||lv_filename||''' SIZE '||lv_filesize_spec;
         END IF;
      END IF;

      IF lv_statement IS NOT NULL THEN
         EXECUTE IMMEDIATE lv_statement;
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CREATE_TABLESPACE', p_error_text => SQLERRM);
      RAISE;
   END create_tablespace;

   PROCEDURE drop_tablespace(p_tablespace_name IN VARCHAR2,
                             p_tablespace_type IN VARCHAR2) IS
      --
      -- Purpose: To drop a tablespace.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    02/28/2015  Creation
      --
      CURSOR c1 IS
      SELECT COUNT(1)
        FROM dba_segments
       WHERE tablespace_name = p_tablespace_name;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 0 AND p_tablespace_name NOT IN ('SYSTEM', 'SYSAUX', 'TEMP') THEN
         IF p_tablespace_type != 'TEMPORARY' THEN
            EXECUTE IMMEDIATE 'ALTER TABLESPACE '||p_tablespace_name||' OFFLINE';
         END IF;
         EXECUTE IMMEDIATE 'DROP TABLESPACE '||p_tablespace_name||' INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS';
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.DROP_TABLESPACE', p_error_text => SQLERRM);
      RAISE;
   END drop_tablespace;

   PROCEDURE modify_datafile(p_file_id IN NUMBER,
                             p_type IN VARCHAR2,
                             p_autoextend IN VARCHAR2,
                             p_inc_by IN NUMBER DEFAULT NULL,
                             p_max_size IN NUMBER DEFAULT NULL,
                             p_resize IN NUMBER DEFAULT NULL) IS
      --
      -- Purpose: To modify a datafile.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    02/24/2015  Creation
      -- G. Lawton  - Skillbuilders    04/30/2015  Added resize.
      --
      CURSOR c1 IS
      SELECT file_name
        FROM (SELECT file_name
                FROM dba_data_files
               WHERE file_id = p_file_id AND p_type = 'DATA'
               UNION ALL
              SELECT file_name
                FROM dba_temp_files
               WHERE file_id = p_file_id AND p_type = 'TEMP')
       WHERE ROWNUM = 1;
      lv_file_name VARCHAR2(4000);
      lv_statement varchar2(4000);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_file_name;
      CLOSE c1;
      IF lv_file_name IS NOT NULL THEN
         IF p_autoextend = 'YES' THEN
            lv_statement := 'ALTER DATABASE '||p_type||'FILE '''||lv_file_name||
                            ''' AUTOEXTEND ON NEXT '||p_inc_by|| ' M MAXSIZE '||p_max_size|| ' M';
         ELSE
            lv_statement := 'ALTER DATABASE '||p_type||'FILE '''||lv_file_name||
                            ''' AUTOEXTEND OFF';
         END IF;
         EXECUTE IMMEDIATE lv_statement;
         IF p_resize IS NOT NULL THEN
            lv_statement := 'ALTER DATABASE '||p_type||'FILE '''||lv_file_name||
                            ''' RESIZE '||p_resize||' M';
            EXECUTE IMMEDIATE lv_statement;
         END IF;
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.MODIFY_DATAFILE', p_error_text => SQLERRM);
      RAISE;
   END modify_datafile;

   PROCEDURE add_datafile (p_tablespace_name IN VARCHAR2,
                           p_tablespace_type IN VARCHAR2,
                           p_use_omf IN VARCHAR2,
                           p_use_asm IN VARCHAR2,
                           p_asm_disk_group IN VARCHAR2,
                           p_init_size IN NUMBER,
                           p_autoextend IN VARCHAR2,
                           p_inc_by IN NUMBER,
                           p_max_size IN NUMBER,
                           p_filename IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To add a datafile to a tablespace.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    02/24/2015  Creation
      --
      lv_statement VARCHAR2(4000);
      lv_filename VARCHAR2(200) := p_filename;
      lv_filesize_spec VARCHAR2 (2000);
   BEGIN
      IF p_autoextend = 'YES' THEN
         lv_filesize_spec :=  p_init_size||' M AUTOEXTEND ON NEXT '||p_inc_by||
                              ' M MAXSIZE '|| p_max_size||' M';
      ELSE
         lv_filesize_spec := p_init_size || ' M';
      END IF;
      IF p_use_asm = 'YES' THEN
         lv_filename := p_asm_disk_group;
      END IF;
      IF p_use_omf = 'YES' THEN
         IF p_tablespace_type IN ('PERMANENT', 'UNDO') THEN
            lv_statement := 'ALTER TABLESPACE '||p_tablespace_name||
                            ' ADD DATAFILE SIZE '||lv_filesize_spec;
         ELSIF p_tablespace_type = 'TEMPORARY' THEN
            lv_statement := 'ALTER TABLESPACE '||p_tablespace_name||
                            ' ADD TEMPFILE SIZE '||lv_filesize_spec;
         END IF;
      ELSE
         IF p_tablespace_type IN ('PERMANENT', 'UNDO') THEN
            lv_statement := 'ALTER TABLESPACE '||p_tablespace_name||
                            ' ADD DATAFILE '''||lv_filename||''' SIZE '||lv_filesize_spec;
         ELSIF p_tablespace_type = 'TEMPORARY' THEN
            lv_statement := 'ALTER TABLESPACE '||p_tablespace_name||
                            ' ADD TEMPFILE '''||lv_filename||''' SIZE '||lv_filesize_spec;
         END IF;
      END IF;
      IF lv_statement IS NOT NULL THEN
         EXECUTE IMMEDIATE lv_statement;
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.ADD_DATAFILE', p_error_text => SQLERRM);
      RAISE;
   END add_datafile;

   FUNCTION highlight_omf_asm RETURN VARCHAR2 IS
      --
      -- Purpose: To highlight OMF and ASM strings in APEX reports.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    02/26/2015  Creation
      --
      CURSOR c1 IS
      SELECT value
        FROM v$parameter
       WHERE name = 'db_unique_name';
      lv_db_unique_name VARCHAR2(200);
      CURSOR c2 IS
      SELECT LISTAGG('+'||name||'/'||UPPER(lv_db_unique_name)||'/DATAFILE/',',') WITHIN GROUP (ORDER BY name) name
        FROM v$asm_diskgroup
       ORDER BY 1;
      lv_string VARCHAR2(4000);
      CURSOR c3 IS
      SELECT LISTAGG('+'||name||'/'||UPPER(lv_db_unique_name)||'/TEMPFILE/',',') WITHIN GROUP (ORDER BY name) name
        FROM v$asm_diskgroup
       ORDER BY 1;
      lv_string2 VARCHAR2(4000);
      CURSOR c4 IS
      SELECT value
        FROM v$parameter
       WHERE name = 'db_create_file_dest';
      lv_omf_path VARCHAR2(200);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_db_unique_name;
      CLOSE c1;
      OPEN c2;
         FETCH c2 INTO lv_string;
      CLOSE c2;
      OPEN c3;
         FETCH c3 INTO lv_string2;
         lv_string := lv_string||','||lv_string2;
      CLOSE c3;
      OPEN c4;
         FETCH c4 INTO lv_omf_path;
      CLOSE c4;
      IF lv_omf_path IS NOT NULL THEN
         lv_string := lv_string||','||lv_omf_path||'/'||UPPER(lv_db_unique_name)||'/datafile/';
      END IF;
      RETURN lv_string;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.HIGHLIGHT_OMF_ASM', p_error_text => SQLERRM);
      RAISE;
   END highlight_omf_asm;

   FUNCTION query_schema(p_owner IN VARCHAR2,
                         p_object_type IN VARCHAR2,
                         p_object_name IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2 IS
      --
      -- Purpose: To return the query string for APEX reports on schema objects.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/08/2015  Creation
      -- G. Lawton  - Skillbuilders    06/16/2015  Added name check to prevent SQL injection
      --
      lv_string VARCHAR2(30);
      lv_object_type VARCHAR2(30) := REPLACE(p_object_type, '_', ' ');
   BEGIN

      -- Check names
      lv_string := DBMS_ASSERT.SCHEMA_NAME(p_owner);
      lv_string := DBMS_ASSERT.SIMPLE_SQL_NAME(p_object_type);
      IF p_object_name IS NOT NULL THEN
         lv_string := DBMS_ASSERT.SIMPLE_SQL_NAME(p_object_name);
      END IF;

      IF lv_object_type = 'SCHEMA' THEN
         RETURN 'SELECT * FROM dba_users WHERE username = '''||p_owner||'''';
      ELSIF lv_object_type = 'TABLE' THEN
         RETURN q'[
         SELECT APEX_ITEM.checkbox2 (
                   1,
                   owner || '.' || table_name,
                   'UNCHECKED' || CASE
                      WHEN owner = 'SYS' THEN ' disabled'
                      ELSE NULL
                   END) AS " ",
                table_name,
                tablespace_name,
                last_analyzed,
                num_rows,
                blocks,
                empty_blocks
           FROM dba_tables
          WHERE owner = ]'||''''||p_owner||'''
            AND (table_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY table_name';
      ELSIF lv_object_type = 'INDEX' THEN
         RETURN q'[
         SELECT APEX_ITEM.CHECKBOX2 (
                1,
                table_owner || '.' || index_name,
                'UNCHECKED' || CASE
                WHEN table_owner = 'SYS' THEN ' disabled'
                ELSE NULL
                END) AS " ",
                table_name,
                index_name,
                uniqueness,
                status,
                tablespace_name AS "Tablespace",
                last_analyzed,
                blevel AS "B Level",
                num_rows AS "Rows",
                distinct_keys
           FROM dba_indexes
          WHERE owner = ]'||''''||p_owner||'''
            AND (index_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY table_name, index_name';
      ELSIF lv_object_type IN ('VIEW', 'FUNCTION', 'PROCEDURE', 'PACKAGE', 'PACKAGE BODY', 'TRIGGER') THEN
         RETURN q'[
         SELECT APEX_ITEM.checkbox2 (
                   1,
                   owner || '.' || object_name,
                   'UNCHECKED' || CASE
                      WHEN owner = 'SYS' THEN ' disabled'
                      ELSE NULL
                   END) AS " ",
                object_name AS name,
                created,
                last_ddl_time AS last_modified,
                status
           FROM dba_objects
          WHERE owner = ]'||''''||p_owner||'''
            AND object_type = '''||lv_object_type||'''
            AND (object_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY object_name';
      ELSIF lv_object_type IN ('SEQUENCE') THEN
         RETURN q'[
         SELECT sequence_name,
                min_value,
                max_value,
                increment_by,
                cycle_flag AS "Cycle",
                order_flag AS "Order",
                cache_size,
                last_number AS "Next"
           FROM dba_sequences
          WHERE sequence_owner = ]'||''''||p_owner||'''
            AND (sequence_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY sequence_name';
      ELSIF lv_object_type IN ('SYNONYM') THEN
         RETURN q'[
         SELECT A.synonym_name AS "Synonym",
                A.table_owner AS "Object Owner",
                B.object_type,
                A.table_name AS "Object Name",
                A.db_link
           FROM dba_synonyms A, dba_objects B
          WHERE A.table_name = B.object_name
            AND A.table_owner = B.owner
            AND B.object_type != 'PACKAGE BODY'
            AND A.owner = ]'||''''||p_owner||'''
            AND (A.synonym_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY A.synonym_name';
      ELSIF lv_object_type IN ('DATABASE LINK') THEN
         RETURN q'[
         SELECT A.db_link AS "Database Link",
                A.username,
                A.host,
                A.created,
                B.last_ddl_time AS "Last Modified",
                B.status
           FROM dba_db_links A, dba_objects B
          WHERE A.db_link = B.object_name
            AND A.owner = B.owner
            AND A.owner = ]'||''''||p_owner||'''
            AND (A.db_link = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY A.db_link';
      ELSIF lv_object_type IN ('JOB') THEN
         RETURN q'[
         SELECT A.job_name, A.job_type,
                A.job_action, A.schedule_type, A.start_date, A.repeat_interval,
                A.state, A.run_count, A.failure_count,
                A.last_start_date, A.next_run_date,
                A.raise_events, A.credential_name, A.credential_owner
           FROM dba_scheduler_jobs A, dba_objects B
          WHERE A.job_name = B.object_name
            AND A.owner = B.owner
            AND A.owner = ]'||''''||p_owner||'''
            AND (A.job_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY A.job_name';
      ELSE
         RETURN q'[
         SELECT object_name AS name,
                created,
                last_ddl_time AS last_modified,
                status
           FROM dba_objects
          WHERE owner = ]'||''''||p_owner||'''
            AND object_type = '''||lv_object_type||'''
            AND (object_name = '''||p_object_name||''' OR NVL('''||p_object_name||''', ''NULL'') = ''NULL'')
          ORDER BY object_name';
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.QUERY_SCHEMA', p_error_text => SQLERRM);
      RAISE;
   END query_schema;

   PROCEDURE insert_alert(p_component_id IN VARCHAR2 DEFAULT 'SBADMIN',
                          p_message_text IN VARCHAR2,
                          p_scan_sequence IN NUMBER) IS
      --
      -- Purpose: To insert an alert into ACA_ALERT_LOG.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    05/13/2015  Creation
      --
   BEGIN
      INSERT INTO aca_alert_log(originating_timestamp, component_id, message_text, scan_sequence)
      VALUES (SYSTIMESTAMP, p_component_id, p_message_text, p_scan_sequence);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.INSERT_ALERT', p_error_text => SQLERRM);
      RAISE;
   END insert_alert;

   PROCEDURE check_recovery_area_usage(p_scan_sequence IN NUMBER) IS
      --
      -- Purpose: To check the percentage usage of the recovery area and raise an alert
      --          if it is above the configured value.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    05/13/2015  Creation
      --
      lv_percent_space_used NUMBER;
   BEGIN
      SELECT SUM(percent_space_used) INTO lv_percent_space_used FROM v$recovery_area_usage;
      IF lv_percent_space_used > TO_NUMBER(aca_util.get_config_value(p_name => 'RECOVERY_AREA_USAGE_ALERT')) THEN
         insert_alert(p_component_id => 'SBA',
                      p_message_text => 'Fast Recovery Area Usage is at '||TO_CHAR(lv_percent_space_used)||'%',
                      p_scan_sequence => p_scan_sequence);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CHECK_RECOVERY_AREA_USAGE', p_error_text => SQLERRM);
      RAISE;
   END check_recovery_area_usage;

   PROCEDURE check_os_filesystem_usage(p_scan_sequence IN NUMBER) IS
      --
      -- Purpose: To check the percentage usage of the OS Filesystems and raise an alert
      --          if it is above the configured value.
      --    Note: Not implemented for Windows.
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    05/14/2015  Creation
      -- G. Lawton  - Skillbuilders    09/15/2015  Changed Linux df command to /bin/df -Ph
      --                                           to Posix format for consistent parsing
      -- G. Lawton  - Skillbuilders    10/23/2015  Changed to use shell script dfCommand.sh
      --                                           to avoid filesystem permission denied error.
      -- G. Lawton  - Skillbuilders    10/23/2015  Added check and set application parameter
      --                                           OS_FILESYSTEM_USAGE_CHECK.
      -- G. Lawton  - Skillbuilders    01/15/2016  Excluded OS_TYPE WINDOWS Too difficult to
      --                                           implement at this time.
      --
      os_type_not_supported EXCEPTION;
      os_command_failed EXCEPTION;

      lv_command VARCHAR2(80);
      lv_status VARCHAR2(4000);
      lv_success_message VARCHAR2(4000);
      lv_failure_message VARCHAR2(4000);
      lv_output VARCHAR2(32000);
      lv_percent_space_used NUMBER := 0;
      lv_os_scripts_directory VARCHAR2(4000) := aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY');
      output_array APEX_APPLICATION_GLOBAL.VC_ARR2;
      line_array APEX_APPLICATION_GLOBAL.VC_ARR2;
      crlf VARCHAR2(2) := '
';

   BEGIN

      IF aca_util.get_config_value(p_name => 'OS_FILESYSTEM_USAGE_CHECK') != 'YES' THEN
         RETURN; -- Return without doing check
      END IF;

      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'UNIX' THEN
         lv_command := lv_os_scripts_directory||'/dfCommand.sh';
      ELSIF aca_util.get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         RETURN; -- Return without doing check
      ELSE
         RAISE os_type_not_supported;
      END IF;

      aca_util.run_os_command_with_output(p_command => lv_command,
                                          p_credential_name => aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME'),
                                          p_timeout => 10,
                                          p_status => lv_status,
                                          p_output => lv_output,
                                          p_success_message => lv_success_message,
                                          p_failure_message => lv_failure_message);

      IF lv_status != 'SUCCEEDED' THEN
         RAISE os_command_failed;
      END IF;

      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'UNIX' THEN
         output_array := APEX_UTIL.STRING_TO_TABLE(lv_output, CHR(10));
         FOR i IN 2..output_array.COUNT LOOP
            line_array := APEX_UTIL.STRING_TO_TABLE(REGEXP_REPLACE(output_array(i),' +',' '), ' ');
            EXIT WHEN line_array.COUNT = 0;
            lv_percent_space_used := TO_NUMBER(REPLACE(TRIM(line_array(5)), '%', ''));

            IF lv_percent_space_used > TO_NUMBER(aca_util.get_config_value(p_name => 'OS_FILESYSTEM_USAGE_ALERT')) THEN
               insert_alert(p_component_id => 'SBA',
                            p_message_text => 'OS Filesystem Usage above configured value.'||crlf||output_array(1)||crlf||output_array(i),
                            p_scan_sequence => p_scan_sequence);
            END IF;
            lv_percent_space_used := 0;
         END LOOP;
      ELSIF aca_util.get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         RETURN; -- this is a placeholder
      ELSE
         RAISE os_type_not_supported;
      END IF;

   EXCEPTION
      WHEN os_type_not_supported THEN
         aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CHECK_OS_FILESYSTEM_USAGE',
                                  p_error_text => 'OS type not supported');
         aca_util.set_config_value(p_name => 'OS_FILESYSTEM_USAGE_CHECK', p_value => 'DISABLED');
         COMMIT;
         RAISE;
      WHEN os_command_failed THEN
         aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CHECK_OS_FILESYSTEM_USAGE',
                                  p_error_text => 'OS Command failed');
         aca_util.set_config_value(p_name => 'OS_FILESYSTEM_USAGE_CHECK', p_value => 'DISABLED');
         COMMIT;
         RAISE;
      WHEN OTHERS THEN
         aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.CHECK_OS_FILESYSTEM_USAGE', p_error_text => SQLERRM);
         aca_util.set_config_value(p_name => 'OS_FILESYSTEM_USAGE_CHECK', p_value => 'DISABLED');
         COMMIT;
         RAISE;
   END check_os_filesystem_usage;

   PROCEDURE scan_alert_log IS
      --
      -- Purpose: To scan the alert log using the predetermined filters.
      --
      --    Note: Can be tested as SYS with exec dbms_system.ksdwrt(2,'ORA-00600: This is a test error message for monitoring and can be ignored.');
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/11/2015  Creation
      -- G. Lawton  - Skillbuilders    04/18/2015  Added exit if message length > 30000
      --                                           Maybe this should be changed to a CLOB.
      -- G. Lawton  - Skillbuilders    06/08/2015  Added workspace configuration, email from
      --                                           and application identifier.
      -- G. Lawton  - Skillbuilders    19/10/2015  Added not null check for notifications.
      -- G. Lawton  - Skillbuilders    01/12/2015  Excluded TNSLSNR entries.
      -- G. Lawton  - Skillbuilders    01/12/2015  Added alert log file exclusion.
      --                                           Note. This was added to prevent transient
      --                                           error logging during clone operations.
      -- G. Lawton  - Skillbuilders    02/12/2015  Added alert log history to address dashboard
      --                                           performance issue.
      -- G. Lawton  - Skillbuilders    01/30/2017  Added calls to aca_util.send_notification.
      --

      CURSOR c1 IS
      SELECT last_run_date
        FROM aca_last_run_dates
       WHERE name = 'SCAN_ALERT_LOG';
      CURSOR c2 IS
      SELECT *
        FROM aca_alert_log_filters
       WHERE filter_type = 'LIKE';
      CURSOR c3 IS
      SELECT *
        FROM aca_alert_log_filters
       WHERE filter_type = 'NOT LIKE';
      lv_alert_log_scan_seq NUMBER;
      CURSOR c4 IS
      SELECT *
        FROM aca_alert_log
       WHERE acknowledged = 'NO'
         AND scan_sequence = lv_alert_log_scan_seq
       ORDER BY originating_timestamp DESC;
      r4 c4%ROWTYPE;

      CURSOR c5 IS
      SELECT *
        FROM aca_alert_log_exclude_files
       WHERE (exclude_until IS NULL OR exclude_until >= SYSTIMESTAMP)
       ORDER BY exclude_until DESC NULLS FIRST;
      r5 c5%ROWTYPE;

      lv_last_run_date TIMESTAMP WITH TIME ZONE;
      lv_statement VARCHAR2(4000);
      lv_like_counter NUMBER := 0;
      lv_notification_users VARCHAR2(4000) := sec_util.get_notification_users;
      lv_message VARCHAR2(32000);
      crlf VARCHAR2(2) := '
';
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_last_run_date;
      CLOSE c1;
      IF lv_last_run_date IS NULL THEN
         UPDATE aca_last_run_dates
            SET last_run_date = SYSTIMESTAMP
          WHERE name = 'SCAN_ALERT_LOG';
         RETURN;
      END IF;
      SELECT aca_alert_log_scan_seq.NEXTVAL INTO lv_alert_log_scan_seq FROM DUAL;

      lv_statement := '
-- EXCLUDE_THIS_SQL --
INSERT INTO aca_alert_log(originating_timestamp, component_id, message_text, filename, scan_sequence)
WITH scanlog AS (
SELECT /*+ MATERIALIZE */
       originating_timestamp, TRIM(UPPER(component_id)) component_id, message_text, filename, '||TO_CHAR(lv_alert_log_scan_seq)||' scan_sequence'||crlf||'
  FROM v$diag_alert_ext
 WHERE originating_timestamp > SYSTIMESTAMP - 1)

SELECT *
  FROM scanlog
 WHERE TRIM(UPPER(component_id)) != ''TNSLSNR''
   AND originating_timestamp > :lv_last_run_date'||crlf;

      FOR r5 IN c5 LOOP
         lv_statement := lv_statement||'   AND UPPER(filename) NOT LIKE UPPER(''%'||r5.exclude_file||'%'')'||crlf;
      END LOOP;

      FOR r2 IN c2 LOOP
         IF lv_like_counter = 0 THEN
            lv_statement := lv_statement||'   AND ('||crlf;
         ELSE
            lv_statement := lv_statement||'       OR '||crlf;
         END IF;
         lv_statement := lv_statement||'       message_text LIKE ''%'||r2.filter||'%'''||crlf;
         lv_like_counter := lv_like_counter + 1;
      END LOOP;
      IF lv_like_counter <> 0 THEN
            lv_statement := lv_statement||'       )'||crlf;
      END IF;

      FOR r3 IN c3 LOOP
         lv_statement := lv_statement||'   AND message_text NOT LIKE ''%'||r3.filter||'%'''||crlf;
      END LOOP;

      EXECUTE IMMEDIATE lv_statement USING lv_last_run_date;

      -- Other checks to be added here --
      check_recovery_area_usage(p_scan_sequence => lv_alert_log_scan_seq);
      check_os_filesystem_usage(p_scan_sequence => lv_alert_log_scan_seq);
      -----------------------------------

      UPDATE aca_last_run_dates
         SET last_run_date = SYSTIMESTAMP
       WHERE name = 'SCAN_ALERT_LOG';

      OPEN c4;
         LOOP
            FETCH c4 INTO r4;
            EXIT WHEN c4%NOTFOUND;
            IF LENGTH(lv_message) > 30000 THEN
               lv_message := lv_message||crlf||crlf||'Message truncated.';
               EXIT;
            END IF;
            lv_message := lv_message||TO_CHAR(r4.originating_timestamp, 'MM/DD/YYYY HH24:MI:SS.FF3')||' '||
                          r4.component_id||' '||r4.message_text||crlf;
         END LOOP;
      CLOSE c4;

      IF lv_message IS NOT NULL THEN
         IF lv_notification_users IS NOT NULL THEN
            aca_util.send_notification(p_to => lv_notification_users,
                                       p_subject => 'Alert Log Entry',
                                       p_message => lv_message);
         END IF;
      END IF;

      -- Delete exclude file entries
      DELETE FROM aca_alert_log_exclude_files
       WHERE exclude_until IS NOT NULL
         AND exclude_until < SYSTIMESTAMP;

      -- Move acknowledged entries to history
      INSERT INTO aca_alert_log_history(id, originating_timestamp, component_id, message_text,
                                        acknowledged, acknowledged_date, scan_sequence, filename)
      SELECT id, originating_timestamp, component_id, message_text,
             acknowledged, acknowledged_date, scan_sequence, filename
        FROM aca_alert_log
       WHERE acknowledged = 'YES';

      DELETE FROM aca_alert_log
       WHERE acknowledged = 'YES';

      COMMIT;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SCAN_ALERT_LOG', p_error_text => SQLERRM);
      IF lv_notification_users IS NOT NULL THEN
         aca_util.send_notification(p_to => lv_notification_users,
                                    p_subject => 'SCAN ALERT LOG - RUN ERROR',
                                    p_message => SQLERRM);
      END IF;
   END scan_alert_log;

   PROCEDURE set_alert_log_exclude_files(p_job_name IN VARCHAR2,
                                         p_db_name IN VARCHAR2,
                                         p_action IN VARCHAR2 DEFAULT 'BEGIN') IS
      --
      -- Purpose: To exclude alert log files
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    12/02/2015  Creation
      -- G. Lawton  - Skillbuilders    12/02/2015  This was added to prevent transient
      --                                           error logging during clone operations.
      -- G. Lawton  - Skillbuilders    01/21/2016  Modified for Windows
      --

      lv_slash VARCHAR2(1) := '/';
   BEGIN
      IF aca_util.get_config_value('OS_TYPE') = 'WINDOWS' THEN
         lv_slash := '\';
      END IF;
      IF p_action = 'BEGIN' THEN
         INSERT INTO aca_alert_log_exclude_files(job_name, exclude_file, exclude_until)
         VALUES (UPPER(p_job_name), lv_slash||p_db_name||lv_slash||'alert'||lv_slash||'log.xml', NULL);
       ELSE
         UPDATE aca_alert_log_exclude_files
            SET exclude_until = SYSTIMESTAMP + (1/24/10)
          WHERE job_name = UPPER(p_job_name);
      END IF;
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SET_ALERT_LOG_EXCLUDE_FILES', p_error_text => SQLERRM);
      RAISE;
   END set_alert_log_exclude_files;

   FUNCTION raise_alarm RETURN VARCHAR2 IS
      --
      -- Purpose: To raise a Dashboard Alert (APEX App. ACA Page 1)
      --
      -- MODIFICATION HISTORY
      -- Person                        Date        Comments
      -- ----------------------------  ----------  ------------------------------------------
      -- G. Lawton  - Skillbuilders    03/12/2015  Creation
      -- G. Lawton  - Skillbuilders    03/12/2015  Added application errors
      --                                           Note: This is not strictly a database issue
      --                                           but it simplifies the raising of an alarm.
      -- G. Lawton  - Skillbuilders    02/27/2019  Added call to CDB
      --
      lv_system_alert NUMBER := 0;
      lv_alert_log NUMBER := 0;
      lv_app_error NUMBER := 0;
      sql_stmt VARCHAR(4000) := 'SELECT COUNT(1) FROM aca_system_alerts@dblink2cdb';
   BEGIN
      IF aca_util.db_is_cdb THEN
         EXECUTE IMMEDIATE sql_stmt INTO lv_system_alert;
      ELSE
         SELECT COUNT(1) INTO lv_system_alert FROM aca_system_alerts;
      END IF;
      SELECT COUNT(1) INTO lv_alert_log FROM aca_alert_log WHERE acknowledged = 'NO';
      SELECT COUNT(1) INTO lv_app_error FROM aca_application_errors WHERE acknowledged = 'NO';
      IF lv_system_alert = 0 AND lv_alert_log = 0 AND lv_app_error = 0 THEN
         RETURN 'NO';
      ELSE
         RETURN 'YES';
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.RAISE_ALARM', p_error_text => SQLERRM);
      RAISE;
   END raise_alarm;

   FUNCTION get_instance_property(p_name IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To get the value of an instance property
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   06/29/2015  Creation
      --
      CURSOR c1 IS
      SELECT value
        FROM v$parameter
       WHERE UPPER(name) = UPPER(p_name);
      lv_value v$parameter.value%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_value;
      CLOSE c1;
      RETURN lv_value;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.GET_INSTANCE_PROPERTY', p_error_text => SQLERRM);
      RAISE;
   END get_instance_property;

   FUNCTION schema_ora_maintained(p_schema IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To check if a schema is Oracle maintained
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   09/23/2015  Creation
      --
      TYPE cursor_type IS REF CURSOR;
      c1 cursor_type;
      lv_query VARCHAR2(4000) := '
      SELECT ''YES''
        FROM dba_users
       WHERE username = :schema
         AND oracle_maintained = ''Y''';
      lv_exists VARCHAR2(3) := 'NO';
   BEGIN
      IF p_schema IS NULL THEN
         RETURN FALSE;
      END IF;
      IF DBMS_DB_VERSION.VERSION = 11 THEN
         IF p_schema LIKE 'SYS%' THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      ELSIF DBMS_DB_VERSION.VERSION = 12 THEN
         OPEN c1 FOR lv_query USING p_schema;
            FETCH c1 INTO lv_exists;
         CLOSE c1;
         IF lv_exists = 'YES' THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      ELSE
         IF p_schema LIKE 'SYS%' THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SCHEMA_ORA_MAINTAINED', p_error_text => SQLERRM);
      RAISE;
   END schema_ora_maintained;

   PROCEDURE scan_tablespace_usage IS
      --
      -- Purpose: To save tablespace usage history
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   12/15/2015  Creation
      --
   BEGIN
      INSERT INTO aca_tablespace_usage(cdate, tablespace_name, size_mb, free_mb, used_mb)
      SELECT SYSDATE cdate, B.tablespace_name, tbs_size size_mb, A.free_space free_mb, tbs_size - A.free_space used_mb
        FROM (SELECT tablespace_name,
                     ROUND (SUM (bytes) / 1024 / 1024, 2) AS free_space
                FROM dba_free_space
               GROUP BY tablespace_name) A,
             (SELECT tablespace_name, SUM (bytes) / 1024 / 1024 AS tbs_size
                FROM dba_data_files
               GROUP BY tablespace_name
              UNION
              SELECT tablespace_name, SUM (bytes) / 1024 / 1024 tbs_size
                FROM dba_temp_files
               GROUP BY tablespace_name) B
       WHERE A.tablespace_name(+) = B.tablespace_name;
      DELETE FROM aca_tablespace_usage
       WHERE TRUNC(cdate) < (TRUNC(SYSDATE) - TO_NUMBER(aca_util.get_config_value(p_name => 'TABLESPACE_USAGE_RETENTION')));
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.SCAN_TABLESPACE_USAGE', p_error_text => SQLERRM);
      RAISE;
   END;

   FUNCTION get_users_default_tablespace(p_username IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To get the default tablespace for a given user.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/06/2016  Creation
      --
      CURSOR c1 IS
      SELECT default_tablespace
        FROM dba_users
       WHERE UPPER(username) = UPPER(p_username);
      lv_default_tablespace dba_users.default_tablespace%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_default_tablespace;
      CLOSE c1;
      RETURN lv_default_tablespace;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATABASE_UTIL.GET_USERS_DEFAULT_TABLESPACE', p_error_text => SQLERRM);
      RAISE;
   END get_users_default_tablespace;

END aca_database_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_DATAPUMP_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   FUNCTION inc(p_num IN OUT NUMBER) RETURN NUMBER IS
   BEGIN
      p_num   := p_num + 1;
      RETURN p_num;
   END inc;

   PROCEDURE schedule_export(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'EXPORT_TEMPLATE_SCHEDULE') IS
      --
      -- Purpose: To schedule an export
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   04/13/2015  Re-Created
      -- GL Skillbuilders   01/26/2016  Added p_content
      -- GL Skillbuilders   09/13/2016  Added JOB_NAME
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_datapump_jobs
       WHERE datapump_type = 'EXPORT'
         AND id = p_id;
      r1 c1%ROWTYPE;

      lv_username_password VARCHAR2(4000);
      lv_dumpdir VARCHAR2(30);
      lv_dumppath VARCHAR2(1000);
      lv_raise_events PLS_INTEGER := DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED;

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      -- Fetch export schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      lv_username_password := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                              aca_util.get_config_value(p_name => 'DB_PASSWORD');

      IF r1.datapump_directory IS NOT NULL THEN
         lv_dumpdir := r1.datapump_directory;
      ELSE
         lv_dumpdir := aca_util.get_config_value(p_name => 'DATA_PUMP_DIRECTORY');
      END IF;

      lv_dumppath := aca_util.get_directory_path(lv_dumpdir);

      subs(inc(idx)).name    := 'JOB_NAME';            subs(idx).value := r1.name||'_'||TO_CHAR(aca_expdp_job_seq.NEXTVAL);
      subs(inc(idx)).name    := 'NAME';                subs(idx).value := r1.name;
      subs(inc(idx)).name    := 'USERNAME_PASSWORD';   subs(idx).value := lv_username_password;
      subs(inc(idx)).name    := 'DUMPDIR';             subs(idx).value := lv_dumpdir;
      subs(inc(idx)).name    := 'DUMPPATH';            subs(idx).value := lv_dumppath;
      subs(inc(idx)).name    := 'LOGFILE';             subs(idx).value := r1.log_file;
      subs(inc(idx)).name    := 'CONTENT';             subs(idx).value := r1.content;
      subs(inc(idx)).name    := 'REUSE_DUMPFILES';     subs(idx).value := 'Y';

      IF r1.parallel_threads IS NOT NULL AND r1.parallel_threads <> 1 THEN
         subs(inc(idx)).name := 'PARALLEL';            subs(idx).value := r1.parallel_threads;
      END IF;

      IF r1.compression IS NOT NULL AND r1.compression != 'NONE' THEN
         subs(inc(idx)).name := 'COMPRESSION';         subs(idx).value := r1.compression;
      END IF;

      IF r1.encryption IS NOT NULL AND r1.encryption != 'NONE' THEN
         subs(inc(idx)).name := 'ENCRYPTION';          subs(idx).value := r1.encryption;
         subs(inc(idx)).name := 'ENCRYPTION_PASSWORD'; subs(idx).value := r1.encryption_pwd;
      END IF;

      IF r1.estimate_only = 'YES' THEN
         subs(inc(idx)).name := 'ESTIMATE_ONLY';       subs(idx).value := 'Y';
         subs(inc(idx)).name := 'DUMPFILE';            subs(idx).value := NULL;
      ELSE
         subs(inc(idx)).name := 'ESTIMATE_ONLY';       subs(idx).value := 'N';
         subs(inc(idx)).name := 'DUMPFILE';            subs(idx).value := r1.dump_file;
      END IF;

      IF r1.datapump_mode = 'TABLE' THEN
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := r1.table_schema||'.'||REPLACE(r1.tables, ':', ','||r1.table_schema||'.');
      ELSE
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := NULL;
      END IF;

      IF r1.datapump_mode = 'SCHEMA' THEN
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := REPLACE(r1.schemas, ':', ',');
      ELSE
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := NULL;
      END IF;

      IF r1.datapump_mode = 'TABLESPACE' THEN
         subs(inc(idx)).name := 'TABLESPACES';         subs(idx).value := REPLACE(r1.tablespaces, ':', ',');
      ELSE
         subs(inc(idx)).name := 'TABLESPACES';         subs(idx).value := NULL;
      END IF;

      IF r1.datapump_mode = 'FULL' THEN
         subs(inc(idx)).name := 'FULL';                subs(idx).value := 'Y';
      ELSE
         subs(inc(idx)).name := 'FULL';                subs(idx).value := 'N';
      END IF;

      IF r1.max_filesize IS NOT NULL THEN
         subs(inc(idx)).name := 'FILESIZE';            subs(idx).value := r1.max_filesize||'M';
      END IF;

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => NULL,
                           p_job_execution => r1.job_execution,
                           p_repeat_interval => r1.repeat_interval,
                           p_start_date => r1.start_date,
                           p_end_date => r1.end_date,
                           p_completion_recipients => r1.completion_recipients,
                           p_success_recipients => r1.success_recipients,
                           p_failure_recipients => r1.failure_recipients,
                           p_notifications => 'YES',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATAPUMP_UTIL.SCHEDULE_EXPORT', p_error_text => SQLERRM);
      RAISE;
   END schedule_export;

   PROCEDURE run_export(p_template_name IN VARCHAR2 DEFAULT 'EXPORT_TEMPLATE',
                        p_name IN VARCHAR2,
                        p_description IN VARCHAR2,
                        p_datapump_type IN VARCHAR2,
                        p_datapump_directory IN VARCHAR2,
                        p_dump_file IN VARCHAR2,
                        p_log_file IN VARCHAR2,
                        p_compression IN VARCHAR2,
                        p_parallel_threads IN VARCHAR2,
                        p_max_filesize IN VARCHAR2,
                        p_estimate_only IN VARCHAR2,
                        p_content IN VARCHAR2 DEFAULT NULL,
                        p_encryption IN VARCHAR2,
                        p_encryption_pwd IN VARCHAR2,
                        p_datapump_mode IN VARCHAR2,
                        p_table_schema IN VARCHAR2,
                        p_schemas IN VARCHAR2,
                        p_tables IN VARCHAR2,
                        p_tablespaces IN VARCHAR2) IS
      --
      -- Purpose: To start an export
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   04/13/2015  Re-Created
      -- GL Skillbuilders   01/26/2016  Added p_content
      -- GL Skillbuilders   09/13/2016  Added JOB_NAME
      --
      lv_username_password VARCHAR2(4000);
      lv_dumpdir VARCHAR2(30);
      lv_dumppath VARCHAR2(1000);

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      lv_username_password := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                              aca_util.get_config_value(p_name => 'DB_PASSWORD');

      IF p_datapump_directory IS NOT NULL THEN
         lv_dumpdir := p_datapump_directory;
      ELSE
         lv_dumpdir := aca_util.get_config_value(p_name => 'DATA_PUMP_DIRECTORY');
      END IF;

      lv_dumppath := aca_util.get_directory_path(lv_dumpdir);

      subs(inc(idx)).name    := 'JOB_NAME';            subs(idx).value := p_name||'_'||TO_CHAR(aca_expdp_job_seq.NEXTVAL);
      subs(inc(idx)).name    := 'NAME';                subs(idx).value := p_name;
      subs(inc(idx)).name    := 'USERNAME_PASSWORD';   subs(idx).value := lv_username_password;
      subs(inc(idx)).name    := 'DUMPDIR';             subs(idx).value := lv_dumpdir;
      subs(inc(idx)).name    := 'DUMPPATH';            subs(idx).value := lv_dumppath;
      subs(inc(idx)).name    := 'LOGFILE';             subs(idx).value := p_log_file;
      subs(inc(idx)).name    := 'CONTENT';             subs(idx).value := p_content;
      subs(inc(idx)).name    := 'REUSE_DUMPFILES';     subs(idx).value := 'Y';

      IF p_parallel_threads IS NOT NULL AND p_parallel_threads <> 1 THEN
         subs(inc(idx)).name := 'PARALLEL';            subs(idx).value := p_parallel_threads;
      END IF;

      IF p_compression IS NOT NULL AND p_compression != 'NONE' THEN
         subs(inc(idx)).name := 'COMPRESSION';         subs(idx).value := p_compression;
      END IF;

      IF p_encryption IS NOT NULL AND p_encryption != 'NONE' THEN
         subs(inc(idx)).name := 'ENCRYPTION';          subs(idx).value := p_encryption;
         subs(inc(idx)).name := 'ENCRYPTION_PASSWORD'; subs(idx).value := p_encryption_pwd;
      END IF;

      IF p_estimate_only = 'YES' THEN
         subs(inc(idx)).name := 'ESTIMATE_ONLY';       subs(idx).value := 'Y';
         subs(inc(idx)).name := 'DUMPFILE';            subs(idx).value := NULL;
      ELSE
         subs(inc(idx)).name := 'ESTIMATE_ONLY';       subs(idx).value := 'N';
         subs(inc(idx)).name := 'DUMPFILE';            subs(idx).value := p_dump_file;
      END IF;

      IF p_datapump_mode = 'TABLE' THEN
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := p_table_schema||'.'||REPLACE(p_tables, ':', ','||p_table_schema||'.');
      ELSE
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := NULL;
      END IF;

      IF p_datapump_mode = 'SCHEMA' THEN
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := REPLACE(p_schemas, ':', ',');
      ELSE
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := NULL;
      END IF;

      IF p_datapump_mode = 'TABLESPACE' THEN
         subs(inc(idx)).name := 'TABLESPACES';         subs(idx).value := REPLACE(p_tablespaces, ':', ',');
      ELSE
         subs(inc(idx)).name := 'TABLESPACES';         subs(idx).value := NULL;
      END IF;

      IF p_datapump_mode = 'FULL' THEN
         subs(inc(idx)).name := 'FULL';                subs(idx).value := 'Y';
      ELSE
         subs(inc(idx)).name := 'FULL';                subs(idx).value := 'N';
      END IF;

      IF p_max_filesize IS NOT NULL THEN
         subs(inc(idx)).name := 'FILESIZE';            subs(idx).value := p_max_filesize||'M';
      END IF;

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => p_name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => p_description,
                           p_executable_code => NULL,
                           p_command_code => NULL,
                           p_job_execution => 'IMMEDIATE',
                           p_repeat_interval => NULL,
                           p_start_date => NULL,
                           p_end_date => NULL,
                           p_notifications => 'NO',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATAPUMP_UTIL.RUN_EXPORT', p_error_text => SQLERRM);
      RAISE;
   END run_export;

   PROCEDURE run_import(p_template_name IN VARCHAR2 DEFAULT 'IMPORT_TEMPLATE',
                        p_name IN VARCHAR2,
                        p_description IN VARCHAR2,
                        p_datapump_type IN VARCHAR2,
                        p_datapump_directory IN VARCHAR2,
                        p_dump_file IN VARCHAR2,
                        p_log_file IN VARCHAR2,
                        p_parallel_threads IN VARCHAR2,
                        p_table_exists_action IN VARCHAR2,
                        p_content IN VARCHAR2 DEFAULT NULL,
                        p_encryption_pwd IN VARCHAR2,
                        p_datapump_mode IN VARCHAR2,
                        p_schema IN VARCHAR2,
                        p_tables IN VARCHAR2,
                        p_remap_schema_to IN VARCHAR2 DEFAULT NULL,
                        p_remap_tablespace_from IN VARCHAR2 DEFAULT NULL,
                        p_remap_tablespace_to IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To start an import
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  -------------------------------------------------------
      -- GL Skillbuilders   09/16/2015  Created
      -- GL Skillbuilders   01/26/2016  Added p_content
      --
      lv_username_password VARCHAR2(4000);
      lv_dumpdir VARCHAR2(30);
      lv_dumppath VARCHAR2(1000);

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      lv_username_password := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                              aca_util.get_config_value(p_name => 'DB_PASSWORD');

      IF p_datapump_directory IS NOT NULL THEN
         lv_dumpdir := p_datapump_directory;
      ELSE
         lv_dumpdir := aca_util.get_config_value(p_name => 'DATA_PUMP_DIRECTORY');
      END IF;

      lv_dumppath := aca_util.get_directory_path(lv_dumpdir);

      subs(inc(idx)).name    := 'USERNAME_PASSWORD';      subs(idx).value := lv_username_password;
      subs(inc(idx)).name    := 'NAME';                   subs(idx).value := p_name;
      subs(inc(idx)).name    := 'DUMPDIR';                subs(idx).value := lv_dumpdir;
      subs(inc(idx)).name    := 'DUMPPATH';               subs(idx).value := lv_dumppath;
      subs(inc(idx)).name    := 'DUMPFILE';               subs(idx).value := p_dump_file;
      subs(inc(idx)).name    := 'LOGFILE';                subs(idx).value := p_log_file;
      subs(inc(idx)).name    := 'TABLE_EXISTS_ACTION';    subs(idx).value := p_table_exists_action;
      subs(inc(idx)).name    := 'CONTENT';                subs(idx).value := p_content;

      IF p_parallel_threads IS NOT NULL AND p_parallel_threads <> 1 THEN
         subs(inc(idx)).name := 'PARALLEL';            subs(idx).value := p_parallel_threads;
      END IF;

      IF p_encryption_pwd IS NOT NULL THEN
         subs(inc(idx)).name := 'ENCRYPTION_PASSWORD'; subs(idx).value := p_encryption_pwd;
      END IF;

      IF p_datapump_mode = 'TABLE' THEN
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := p_schema||'.'||REPLACE(p_tables, ',', ','||p_schema||'.');
      ELSE
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := NULL;
      END IF;

      IF p_datapump_mode = 'SCHEMA' THEN
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := p_schema;
      ELSE
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := NULL;
      END IF;

      subs(inc(idx)).name := 'TABLESPACES';            subs(idx).value := NULL;
      subs(inc(idx)).name := 'FULL';                   subs(idx).value := 'N';

      IF p_remap_schema_to IS NOT NULL THEN
         subs(inc(idx)).name := 'REMAP_SCHEMA';        subs(idx).value := p_schema||':'||p_remap_schema_to;
      ELSE
         subs(inc(idx)).name := 'REMAP_SCHEMA';        subs(idx).value := NULL;
      END IF;

      IF p_remap_tablespace_from IS NOT NULL THEN
         subs(inc(idx)).name := 'REMAP_TABLESPACE';    subs(idx).value := p_remap_tablespace_from||':'||p_remap_tablespace_to;
      ELSE
         subs(inc(idx)).name := 'REMAP_TABLESPACE';    subs(idx).value := NULL;
      END IF;

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => p_name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => p_description,
                           p_executable_code => NULL,
                           p_command_code => NULL,
                           p_job_execution => 'IMMEDIATE',
                           p_repeat_interval => NULL,
                           p_start_date => NULL,
                           p_end_date => NULL,
                           p_notifications => 'NO',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATAPUMP_UTIL.RUN_IMPORT', p_error_text => SQLERRM);
      RAISE;
   END run_import;

   PROCEDURE schedule_import(p_id IN NUMBER,
                             p_template_name IN VARCHAR2 DEFAULT 'IMPORT_TEMPLATE_SCHEDULE') IS
      --
      -- Purpose: To schedule an import
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   12/13/2015  Created
      -- GL Skillbuilders   01/26/2016  Added p_content
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_datapump_jobs
       WHERE datapump_type = 'IMPORT'
         AND id = p_id;
      r1 c1%ROWTYPE;

      lv_username_password VARCHAR2(4000);
      lv_dumpdir VARCHAR2(30);
      lv_dumppath VARCHAR2(1000);
      lv_raise_events PLS_INTEGER := DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED;

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      -- Fetch import schedule
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      lv_username_password := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                              aca_util.get_config_value(p_name => 'DB_PASSWORD');

      IF r1.datapump_directory IS NOT NULL THEN
         lv_dumpdir := r1.datapump_directory;
      ELSE
         lv_dumpdir := aca_util.get_config_value(p_name => 'DATA_PUMP_DIRECTORY');
      END IF;

      lv_dumppath := aca_util.get_directory_path(lv_dumpdir);

      subs(inc(idx)).name    := 'NAME';                   subs(idx).value := r1.name;
      subs(inc(idx)).name    := 'USERNAME_PASSWORD';      subs(idx).value := lv_username_password;
      subs(inc(idx)).name    := 'DUMPDIR';                subs(idx).value := lv_dumpdir;
      subs(inc(idx)).name    := 'DUMPPATH';               subs(idx).value := lv_dumppath;
      subs(inc(idx)).name    := 'DUMPFILE';               subs(idx).value := r1.dump_file;
      subs(inc(idx)).name    := 'LOGFILE';                subs(idx).value := r1.log_file;
      subs(inc(idx)).name    := 'TABLE_EXISTS_ACTION';    subs(idx).value := r1.table_exists_action;
      subs(inc(idx)).name    := 'CONTENT';                subs(idx).value := r1.content;

      IF r1.parallel_threads IS NOT NULL AND r1.parallel_threads <> 1 THEN
         subs(inc(idx)).name := 'PARALLEL';            subs(idx).value := r1.parallel_threads;
      END IF;

      IF r1.encryption_pwd IS NOT NULL THEN
         subs(inc(idx)).name := 'ENCRYPTION_PASSWORD'; subs(idx).value := r1.encryption_pwd;
      END IF;

      IF r1.datapump_mode = 'TABLE' THEN
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := r1.schemas||'.'||REPLACE(r1.tables, ',', ','||r1.schemas||'.');
      ELSE
         subs(inc(idx)).name := 'TABLES';              subs(idx).value := NULL;
      END IF;

      IF r1.datapump_mode = 'SCHEMA' THEN
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := r1.schemas;
      ELSE
         subs(inc(idx)).name := 'SCHEMAS';             subs(idx).value := NULL;
      END IF;

      subs(inc(idx)).name := 'TABLESPACES';            subs(idx).value := NULL;
      subs(inc(idx)).name := 'FULL';                   subs(idx).value := 'N';

      IF r1.remap_schema_to IS NOT NULL THEN
         subs(inc(idx)).name := 'REMAP_SCHEMA';        subs(idx).value := r1.schemas||':'||r1.remap_schema_to;
      ELSE
         subs(inc(idx)).name := 'REMAP_SCHEMA';        subs(idx).value := NULL;
      END IF;

      IF r1.remap_tablespace_from IS NOT NULL THEN
         subs(inc(idx)).name := 'REMAP_TABLESPACE';    subs(idx).value := r1.remap_tablespace_from||':'||r1.remap_tablespace_to;
      ELSE
         subs(inc(idx)).name := 'REMAP_TABLESPACE';    subs(idx).value := NULL;
      END IF;

      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => NULL,
                           p_job_execution => r1.job_execution,
                           p_repeat_interval => r1.repeat_interval,
                           p_start_date => r1.start_date,
                           p_end_date => r1.end_date,
                           p_completion_recipients => r1.completion_recipients,
                           p_success_recipients => r1.success_recipients,
                           p_failure_recipients => r1.failure_recipients,
                           p_notifications => 'YES',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_DATAPUMP_UTIL.SCHEDULE_IMPORT', p_error_text => SQLERRM);
      RAISE;
   END schedule_import;

END aca_datapump_util ;
/


CREATE OR REPLACE PACKAGE BODY ACA_ERROR_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: Provides utilities for logging internal application errors
   --
   -- MODIFICATION HISTORY
   -- Person         Date          Comments
   -- ------------   ------        ------------------------------------------
   -- Garry Lawton   05/06/2015    Creation

   PROCEDURE log_error(p_program_name IN VARCHAR2, p_error_text IN VARCHAR2) IS
   --
   -- Purpose: Provides utilities for logging internal application errors
   --
   -- MODIFICATION HISTORY
   -- Person         Date          Comments
   -- ------------   ----------    ---------------------------------------------
   -- Garry Lawton   05/06/2015    Creation
   -- Garry Lawton   01/30/2017    Added call to send_notification.
   crlf VARCHAR2(2) := '
';
   BEGIN
      ROLLBACK;
      INSERT INTO aca_application_errors(program_name, error_text)
           VALUES(p_program_name, p_error_text);
      COMMIT;
      IF sec_util.get_notification_users IS NOT NULL THEN
         aca_util.send_notification(p_to => sec_util.get_notification_users,
                                    p_subject => 'Application Error',
                                    p_message => 'Program: '||p_program_name||crlf||
                                                 'Error: '||p_error_text);
      END IF;
   END log_error;

   PROCEDURE acknowledge_errors IS
   --
   -- Purpose: To set acknowledged flag to YES for all un-acknowledged errors
   --
   -- MODIFICATION HISTORY
   -- Person         Date          Comments
   -- ------------   ------        ---------------------------------------------
   -- Garry Lawton   05/06/2015    Creation
   BEGIN
       UPDATE aca_application_errors
          SET acknowledged = 'YES'
        WHERE acknowledged = 'NO';
   END acknowledge_errors;

   PROCEDURE test_error_logging IS
      --
      -- Purpose: To test error logging.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/06/2015  Creation
      --
      x NUMBER;
   BEGIN
      x := 1/0;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_ERROR_UTIL.TEST_ERROR_LOGGING', p_error_text => SQLERRM);
      RAISE;
   END test_error_logging;

END aca_error_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_INSTALL_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: Utilities for application ACA installation
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   05/26/2015  Creation
   --

   PROCEDURE load_aca_jobs(p_dummy IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To load tables aca_jobs, aca_job_arguments
      --                         and aca_job_substitutions
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/28/2015  Creation
      -- GL Skillbuilders   01/18/2017  Added lock jobs
      --
      lv_executable_code CLOB;
      lv_command_code CLOB;
   BEGIN

--- APEX_EXPORT_EXE_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash

OS_HOME_DIRECTORY=#OS_HOME_DIRECTORY#
OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#

NAME=#NAME#

. $OS_HOME_DIRECTORY/.bash_profile

if [[ -f ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock ]] ; then
   exit 0
fi
touch ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
exec aca_apex_util.export(''#NAME#'');
EOF

exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
exit 0';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(1,'APEX_EXPORT_EXE_TEMPLATE','Apex Workspace and Application Export','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,NULL,NULL,'IMMEDIATE',NULL,NULL,NULL,'YES','YES',NULL,'APEX','NO','NO');


--- BACKUP_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash

. #OS_HOME_DIRECTORY#/.bash_profile

export NAME=#NAME#
export OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
export LOCK_FILE=#OS_SCRIPTS_DIRECTORY#/#NAME#.lock
export OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
export LOG_FILE=#OS_LOG_DIRECTORY#/#NAME#.log
export NOW=$(date +"%Y-%m-%d-%H-%M-%S")

if [[ -f ${LOCK_FILE} ]] ; then
   echo "\n**** Lock file detected - Script already running - Ignore" >> ${LOG_FILE}
   exit 0
fi
touch ${LOCK_FILE}

rman target / @${OS_SCRIPTS_DIRECTORY}/#NAME#.rman log=${LOG_FILE}
rman_exit_code=$?
if [ $rman_exit_code -ne 0 ]; then
    echo -e "\n**** Unable to make a backup." >> ${LOG_FILE}
    rm ${LOCK_FILE}
    exit 1
fi

cp ${LOG_FILE} ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to copy log file." >> ${LOG_FILE}
    rm ${LOCK_FILE}
    exit 1
fi

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
exec aca_util.update_log_filename(''$NAME'', ''${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log'');
EOF
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to update log filename." >> ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
    rm ${LOCK_FILE}
    exit 1
fi

rm -f ${LOG_FILE}
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to remove original log file." >> ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
    rm ${LOCK_FILE}
    exit 1
fi

rm ${LOCK_FILE}
exit 0';

lv_command_code :=
'# NOTE: This is an example and will be overwritten
RUN{
ALLOCATE CHANNEL D1 TYPE DISK;
REPORT SCHEMA;
CROSSCHECK BACKUPSET;
DELETE NOPROMPT EXPIRED BACKUPSET;
BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT ''#BACKUP_DIRECTORY#/db_${NOW}_%U.bset'';
BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT ''#BACKUP_DIRECTORY#/arch_${NOW}.bset'' delete all input;
BACKUP CURRENT CONTROLFILE FORMAT ''#BACKUP_DIRECTORY#/ctl_${NOW}.bset'';
RESTORE DATABASE VALIDATE;
DELETE NOPROMPT OBSOLETE;
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(2,'BACKUP_TEMPLATE','Backup Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#/#NAME#.log','BACKUP','NO','NO');


--- BACKUP_TEMPLATE_PDB ---

lv_executable_code :=
'#! /bin/bash

. #OS_HOME_DIRECTORY#/.bash_profile

export NAME=#NAME#
export OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
export LOCK_FILE=#OS_SCRIPTS_DIRECTORY#/#NAME#.lock
export OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
export LOG_FILE=#OS_LOG_DIRECTORY#/#NAME#.log
export NOW=$(date +"%Y-%m-%d-%H-%M-%S")

if [[ -f ${LOCK_FILE} ]] ; then
   echo "\n**** Lock file detected - Script already running - Ignore" >> ${LOG_FILE}
   exit 0
fi
touch ${LOCK_FILE}

rman target #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# @${OS_SCRIPTS_DIRECTORY}/#NAME#.rman log=${LOG_FILE}
rman_exit_code=$?
if [ $rman_exit_code -ne 0 ]; then
    echo -e "\n**** Unable to make a backup." >> ${LOG_FILE}
    rm ${LOCK_FILE}
    exit 1
fi

cp ${LOG_FILE} ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to copy log file." >> ${LOG_FILE}
    rm ${LOCK_FILE}
    exit 1
fi

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
exec aca_util.update_log_filename(''$NAME'', ''${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log'');
EOF
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to update log filename." >> ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
    rm ${LOCK_FILE}
    exit 1
fi

rm -f ${LOG_FILE}
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to remove original log file." >> ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
    rm ${LOCK_FILE}
    exit 1
fi

rm ${LOCK_FILE}
exit 0';

lv_command_code :=
'# NOTE: This is an example and will be overwritten
RUN{
ALLOCATE CHANNEL D1 TYPE DISK;
REPORT SCHEMA;
CROSSCHECK BACKUPSET;
DELETE NOPROMPT EXPIRED BACKUPSET;
BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT ''#BACKUP_DIRECTORY#/db_${NOW}_%U.bset'';
BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT ''#BACKUP_DIRECTORY#/arch_${NOW}.bset'' delete all input;
BACKUP CURRENT CONTROLFILE FORMAT ''#BACKUP_DIRECTORY#/ctl_${NOW}.bset'';
RESTORE DATABASE VALIDATE;
DELETE NOPROMPT OBSOLETE;
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(3,'BACKUP_TEMPLATE_PDB','Backup Template PDB','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#/#NAME#.log','BACKUP','NO','NO');


--- CLONE_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash
. #OS_HOME_DIRECTORY#/.bash_profile

export NAME=#NAME#
export DB_USER=#DB_USER#
export OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
export LOG_FILE=#OS_LOG_DIRECTORY#/#NAME#.log
export COMMAND_FILE=#OS_SCRIPTS_DIRECTORY#/#NAME#.rman
export LOCK_FILE=#OS_SCRIPTS_DIRECTORY#/#NAME#.lock
export SYS_PASSWORD=#SYS_PASSWORD#
export SOURCE_TNS_NAME=#SOURCE_TNS_NAME#
export DESTINATION_TNS_NAME=#DESTINATION_TNS_NAME#
export DESTINATION_DB_NAME=#DESTINATION_DB_NAME#
export NOW=$(date +"%Y-%m-%d-%H-%M-%S")

if [[ -f ${LOCK_FILE} ]] ; then
   echo "\n**** Lock file detected - Script already running - Ignore" >> ${LOG_FILE}
   exit 0
fi
touch ${LOCK_FILE}

sqlplus /nolog << EOF >> ${LOG_FILE}
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect sys/${SYS_PASSWORD}@${SOURCE_TNS_NAME} as sysdba
exec ${DB_USER}.aca_clone_util.rewrite_command_file(''${NAME}'');
exit;
EOF

exit_code=$?
if [ $exit_code -ne 0 ]
then
   echo -e "\n**** Unable to rewrite command file at ${SOURCE_TNS_NAME}." >> ${LOG_FILE}
   echo Script aborted >> ${LOG_FILE}
   rm ${LOCK_FILE}
   exit 1
fi

sqlplus /nolog << EOF >> ${LOG_FILE}
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect sys/${SYS_PASSWORD}@${SOURCE_TNS_NAME} as sysdba
exec ${DB_USER}.aca_database_util.set_alert_log_exclude_files(''$NAME'', ''${DESTINATION_DB_NAME}'', ''BEGIN'');
exit;
EOF

exit_code=$?
if [ $exit_code -ne 0 ]
then
   echo -e "\n**** Unable to set alert log exclude for ${DESTINATION_DB_NAME}." >> ${LOG_FILE}
   echo Script aborted >> ${LOG_FILE}
   rm ${LOCK_FILE}
   exit 1
fi

echo " " >> ${LOG_FILE}
echo " Startup nomount database at ${DESTINATION_TNS_NAME}" >> ${LOG_FILE}
echo " " >> ${LOG_FILE}

sqlplus /nolog << EOF >> ${LOG_FILE}
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect sys/${SYS_PASSWORD}@${DESTINATION_TNS_NAME} as sysdba
shutdown abort;
startup nomount;
exit;
EOF

exit_code=$?
if [ $exit_code -ne 0 ]
then
   echo -e "\n**** Unable to start the database at ${DESTINATION_TNS_NAME} in nomount state." >> ${LOG_FILE}
   echo Script aborted >> ${LOG_FILE}
   rm ${LOCK_FILE}
   exit 1
fi

echo " " >> ${LOG_FILE}
echo " Starting clone to database at ${DESTINATION_TNS_NAME}" >> ${LOG_FILE}
echo " " >> ${LOG_FILE}

rman log=${LOG_FILE} append << EOF >> ${LOG_FILE}
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect target sys/${SYS_PASSWORD}@${SOURCE_TNS_NAME}
connect auxiliary sys/${SYS_PASSWORD}@${DESTINATION_TNS_NAME}
'||CHR(64)||'${COMMAND_FILE}
EOF

rman_exit_code=$?

if [ $rman_exit_code -ne 0 ]
then
   echo -e "\n**** Unable to clone the database from ${SOURCE_TNS_NAME} to ${DESTINATION_TNS_NAME}." >> ${LOG_FILE}
   echo Script aborted >> ${LOG_FILE}
   rm ${LOCK_FILE}
   exit 1
fi

echo " " >> ${LOG_FILE}
echo "Final Maintenance Steps at ${DESTINATION_TNS_NAME}" >> $LOG_FILE
echo " " >> ${LOG_FILE}

sqlplus /nolog << EOF >> ${LOG_FILE}
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect sys/${SYS_PASSWORD}@${DESTINATION_TNS_NAME} as sysdba
exec dbms_scheduler.set_scheduler_attribute(''SCHEDULER_DISABLED'',''TRUE'');
exit;
EOF

exit_code=$?
if [ $exit_code -ne 0 ]
then
   echo -e "\n**** Final maintenance steps failed - ${DESTINATION_TNS_NAME}" >> $LOG_FILE
   echo Script aborted >> $LOG_FILE
   rm ${LOCK_FILE}
   exit 1
fi

echo " " >> ${LOG_FILE}
echo "Finished clone to database at ${DESTINATION_TNS_NAME}" >> ${LOG_FILE}
echo " " >> ${LOG_FILE}

sqlplus /nolog << EOF >> ${LOG_FILE}
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect sys/${SYS_PASSWORD}@${SOURCE_TNS_NAME} as sysdba
exec ${DB_USER}.aca_database_util.set_alert_log_exclude_files(''$NAME'', ''${DESTINATION_DB_NAME}'', ''END'');
exit;
EOF

exit_code=$?
if [ $exit_code -ne 0 ]
then
   echo -e "\n**** Unable to reset alert log exclude for ${DESTINATION_DB_NAME}." >> ${LOG_FILE}
   echo Script aborted >> ${LOG_FILE}
   rm ${LOCK_FILE}
   exit 1
fi

cp ${LOG_FILE} ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to copy log file." >> ${LOG_FILE}
    rm ${LOCK_FILE}
    exit 1
fi

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
connect sys/${SYS_PASSWORD}@${SOURCE_TNS_NAME} as sysdba
exec ${DB_USER}.aca_util.update_log_filename(''$NAME'', ''${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log'');
EOF
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to update log filename." >> ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
    rm ${LOCK_FILE}
    exit 1
fi

rm -f ${LOG_FILE}
exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo -e "\n**** Unable to remove original log file." >> ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
    rm ${LOCK_FILE}
    exit 1
fi

rm ${LOCK_FILE}
exit 0';

lv_command_code :=
'# NOTE: This command file will be overwritten by a scheduled clone
RUN
{
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(4,'CLONE_TEMPLATE','Clone Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#/#NAME#.log','CLONE_DB','NO','NO');


--- EXPORT_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash
. #OS_HOME_DIRECTORY#/.bash_profile

if [[ -f #OS_SCRIPTS_DIRECTORY#/#NAME#.lock ]] ; then
   exit 0
fi
touch #OS_SCRIPTS_DIRECTORY#/#NAME#.lock

'||CHR(35)||' Hide username/password from ps
(cat - << EOF ; cat - ) | expdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=#OS_SCRIPTS_DIRECTORY#/#NAME#.par
EOF

expdp_exit_code=$?
if [ $expdp_exit_code -ne 0 ]; then
    rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
    exit 1
fi

rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
exit 0';

lv_command_code :=
'JOB_NAME=#JOB_NAME#
DIRECTORY=#DUMPDIR#
$DUMPFILE$
LOGFILE=#LOGFILE#
$FILESIZE$
$PARALLEL$
$COMPRESSION$
$ENCRYPTION$
$ENCRYPTION_PASSWORD$
REUSE_DUMPFILES=#REUSE_DUMPFILES#
ESTIMATE_ONLY=#ESTIMATE_ONLY#
FULL=#FULL#
CONTENT=#CONTENT#
$SCHEMAS$
$TABLESPACES$
$TABLES$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(5,'EXPORT_TEMPLATE','Data Pump Export Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#/#LOGFILE#','EXPORT','NO','NO');

--- EXPORT_TEMPLATE_SCHEDULE ---

lv_executable_code :=
'#! /bin/bash

OS_HOME_DIRECTORY=#OS_HOME_DIRECTORY#
OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
NAME=#NAME#
DUMPPATH=#DUMPPATH#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#

. ${OS_HOME_DIRECTORY}/.bash_profile

if [[ -f ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock ]] ; then
   exit 0
fi
touch ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock

NOW=$(date +"%Y-%m-%d-%H-%M-%S")

'||CHR(35)||' Export (hide username/password from ps)
(cat - << EOF ; cat - ) | expdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=${OS_SCRIPTS_DIRECTORY}/${NAME}.par
EOF

expdp_exit_code=$?
if [ $expdp_exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

mkdir ${DUMPPATH}/${NAME}-${NOW}
chmod 750 ${DUMPPATH}/${NAME}-${NOW}
cp ${DUMPPATH}/${DUMPFILE/''%U''/''*''} ${DUMPPATH}/${NAME}-${NOW}
exit_code=$?
if [ $exit_code -ne 0 ]; then
   rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
   exit 1
fi

cp ${DUMPPATH}/${LOGFILE} ${DUMPPATH}/${NAME}-${NOW}/${NAME}.log
exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
exec aca_util.update_log_filename(''$NAME'', ''${DUMPPATH}/${NAME}-${NOW}/${NAME}.log'');
EOF
exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

rm -f ${DUMPPATH}/$LOGFILE
exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
exit 0';

lv_command_code :=
'JOB_NAME=#JOB_NAME#
DIRECTORY=#DUMPDIR#
$DUMPFILE$
LOGFILE=#LOGFILE#
$FILESIZE$
$PARALLEL$
$COMPRESSION$
$ENCRYPTION$
$ENCRYPTION_PASSWORD$
REUSE_DUMPFILES=#REUSE_DUMPFILES#
ESTIMATE_ONLY=#ESTIMATE_ONLY#
FULL=#FULL#
CONTENT=#CONTENT#
$SCHEMAS$
$TABLESPACES$
$TABLES$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(6,'EXPORT_TEMPLATE_SCHEDULE','Scheduled Data Pump Export Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#/#LOGFILE#','EXPORT','NO','NO');

--- IMPORT_HELP_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash
. #OS_HOME_DIRECTORY#/.bash_profile

if [[ -f #OS_SCRIPTS_DIRECTORY#/#NAME#.lock ]] ; then
   exit 0
fi
touch #OS_SCRIPTS_DIRECTORY#/#NAME#.lock

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
ALTER TABLE sbh_page_links DISABLE CONSTRAINT sbh_plk_sbh_hlp_fk;
exit;
EOF
exit_code=$?
if [ $exit_code -eq 1 ]; then
    rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
    exit 1
fi

(cat - << EOF ; cat - ) | impdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=#OS_SCRIPTS_DIRECTORY#/#NAME#.par
EOF
exit_code=$?
if [ $exit_code -eq 1 ]; then
    rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
    exit 1
fi

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
ALTER TABLE sbh_page_links ENABLE CONSTRAINT sbh_plk_sbh_hlp_fk;
exit;
EOF
exit_code=$?
if [ $exit_code -eq 1 ]; then
    rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
    exit 1
fi

rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
exit 0';

lv_command_code :=
'DIRECTORY=#DUMPDIR#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#
TABLE_EXISTS_ACTION=#TABLE_EXISTS_ACTION#
FULL=#FULL#
CONTENT=#CONTENT#
$PARALLEL$
$ENCRYPTION_PASSWORD$
$SCHEMAS$
$TABLESPACES$
$TABLES$
$REMAP_SCHEMA$
$REMAP_TABLESPACE$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(7,'IMPORT_HELP_TEMPLATE','Import Help Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#/#LOGFILE#','IMPORT','NO','NO');

--- IMPORT_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash
. #OS_HOME_DIRECTORY#/.bash_profile

if [[ -f #OS_SCRIPTS_DIRECTORY#/#NAME#.lock ]] ; then
   exit 0
fi
touch #OS_SCRIPTS_DIRECTORY#/#NAME#.lock

'||CHR(35)||' Hide username/password from ps
(cat - << EOF ; cat - ) | impdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=#OS_SCRIPTS_DIRECTORY#/#NAME#.par
EOF

impdp_exit_code=$?
if [ $impdp_exit_code -eq 1 ]; then
    rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
    exit 1
fi

rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
exit 0';

lv_command_code :=
'TRANSFORM=SEGMENT_ATTRIBUTES:n
TRANSFORM=OID:n
DIRECTORY=#DUMPDIR#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#
TABLE_EXISTS_ACTION=#TABLE_EXISTS_ACTION#
FULL=#FULL#
CONTENT=#CONTENT#
$PARALLEL$
$ENCRYPTION_PASSWORD$
$SCHEMAS$
$TABLESPACES$
$TABLES$
$REMAP_SCHEMA$
$REMAP_TABLESPACE$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(8,'IMPORT_TEMPLATE','Data Pump Import Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#/#LOGFILE#','IMPORT','NO','NO');

--- IMPORT_TEMPLATE_SCHEDULE ---

lv_executable_code :=
'#! /bin/bash

export OS_HOME_DIRECTORY=#OS_HOME_DIRECTORY#
export OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
export NAME=#NAME#
export DUMPPATH=#DUMPPATH#
export DUMPFILE=#DUMPFILE#
export LOGFILE=#LOGFILE#
export NOW=$(date +"%Y-%m-%d-%H-%M-%S")

. ${OS_HOME_DIRECTORY}/.bash_profile

if [[ -f ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock ]] ; then
   exit 0
fi

touch ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock

(cat - << EOF ; cat - ) | impdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=${OS_SCRIPTS_DIRECTORY}/${NAME}.par
EOF

impdp_exit_code=$?
if [ $impdp_exit_code -eq 1 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

mv ${DUMPPATH}/${LOGFILE} ${DUMPPATH}/${NAME}-${NOW}.log
exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

sqlplus /nolog << EOF
WHENEVER SQLERROR EXIT SQL.SQLCODE
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
exec aca_util.update_log_filename(''$NAME'', ''${DUMPPATH}/${NAME}-${NOW}.log'');
EOF
exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
exit 0';

lv_command_code :=
'TRANSFORM=SEGMENT_ATTRIBUTES:n
TRANSFORM=OID:n
DIRECTORY=#DUMPDIR#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#
TABLE_EXISTS_ACTION=#TABLE_EXISTS_ACTION#
FULL=#FULL#
CONTENT=#CONTENT#
$PARALLEL$
$ENCRYPTION_PASSWORD$
$SCHEMAS$
$TABLESPACES$
$TABLES$
$REMAP_SCHEMA$
$REMAP_TABLESPACE$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(9,'IMPORT_TEMPLATE_SCHEDULE','Scheduled Data Pump Import Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#/#LOGFILE#','IMPORT','NO','NO');

--- REFRESH_ACA_BACKUP_SETS ---

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(10,'REFRESH_ACA_BACKUP_SETS','Refresh table ACA_BACKUP_SETS','PLSQL_BLOCK',NULL,'BEGIN
   aca_backup_util.refresh_aca_backup_sets;
END;',NULL,NULL,NULL,NULL,'SCHEDULE','FREQ=DAILY;INTERVAL=1;BYHOUR=4;BYMINUTE=0;',NULL,NULL,'YES','YES',NULL,'OTHER','NO','NO');

--- REMOVE_TEMPORARY_JOBS ---

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(11,'REMOVE_TEMPORARY_JOBS','Remove Temporary Jobs','PLSQL_BLOCK',NULL,'BEGIN
   DELETE FROM aca_jobs
    WHERE permanent = ''NO'';
END;',NULL,NULL,NULL,NULL,'SCHEDULE','FREQ=WEEKLY',NULL,NULL,'YES','YES',NULL,'OTHER','NO','NO');

--- RMAN_CONFIG_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash
. #OS_HOME_DIRECTORY#/.bash_profile

if [[ -f #OS_SCRIPTS_DIRECTORY#/#NAME#.lock ]] ; then
   exit 0
fi
touch #OS_SCRIPTS_DIRECTORY#/#NAME#.lock

rman target / @#OS_SCRIPTS_DIRECTORY#/#NAME#.rman log=#OS_LOG_DIRECTORY#/#NAME#.log append
rman_exit_code=$?
if [ $rman_exit_code -ne 0 ]; then
    rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
    exit 1
fi
rm #OS_SCRIPTS_DIRECTORY#/#NAME#.lock
exit 0';

lv_command_code :=
'# NOTE: This is an example and will be overwritten
RUN{
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 10 DAYS;
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(12,'RMAN_CONFIG_TEMPLATE','RMAN Configuration','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#/#NAME#.log','BACKUP','NO','NO');

--- SCAN_ALERT_LOG ---

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(13,'SCAN_ALERT_LOG','Scan the alert log using the pre-defined filters','PLSQL_BLOCK',NULL,'BEGIN
   aca_database_util.scan_alert_log;
END;',NULL,NULL,NULL,NULL,'SCHEDULE','FREQ=MINUTELY;INTERVAL=5',NULL,NULL,'YES','YES',NULL,'OTHER','NO','NO');

--- SCAN_TABLESPACE_USAGE ---

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(14,'SCAN_TABLESPACE_USAGE','Scan tablespace usage','PLSQL_BLOCK',NULL,'BEGIN
   aca_database_util.scan_tablespace_usage;
END;',NULL,NULL,NULL,NULL,'SCHEDULE','FREQ=HOURLY',NULL,NULL,'YES','YES',NULL,'OTHER','NO','NO');

--- SQL_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash

OS_HOME_DIRECTORY=#OS_HOME_DIRECTORY#
OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#

NAME=#NAME#

. $OS_HOME_DIRECTORY/.bash_profile

if [[ -f ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock ]] ; then
   exit 0
fi
touch ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock

NOW=$(date +"%Y-%m-%d-%H-%M-%S")

sqlplus /nolog << EOF
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
SET ECHO ON
SPOOL ${OS_LOG_DIRECTORY}/${NAME}.log
WHENEVER SQLERROR EXIT SQL.SQLCODE
'||CHR(64)||'${OS_SCRIPTS_DIRECTORY}/${NAME}.sql
EOF

exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

cp ${OS_LOG_DIRECTORY}/${NAME}.log ${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log
exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

sqlplus /nolog << EOF
CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#
exec aca_util.update_log_filename(''$NAME'', ''${OS_LOG_DIRECTORY}/${NAME}-${NOW}.log'');
EOF

exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

rm -f ${OS_LOG_DIRECTORY}/${NAME}.log

exit_code=$?
if [ $exit_code -ne 0 ]; then
    rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
    exit 1
fi

rm ${OS_SCRIPTS_DIRECTORY}/${NAME}.lock
exit 0';

lv_command_code :=
'-- Starting Test --
SELECT table_name, tablespace_name FROM user_tables;
-- End Test --';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(15,'SQL_TEMPLATE','SQL Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sql',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#/#NAME#.log','SQL','NO','NO');

--- EXECUTABLE_TEMPLATE ---

lv_executable_code :=
'#! /bin/bash

log_file=#OS_LOG_DIRECTORY#/#NAME#.log
sub1=#SUB1#
sub2=#SUB2#

echo "Argument 1 is $1" > $log_file
echo "Argument 2 is $2" >> $log_file
echo "Substitution 1 is $sub1" >> $log_file
echo "Substitution 2 is $sub2" >> $log_file
';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(16,'EXECUTABLE_TEMPLATE','Example OS executable template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#/#NAME#.sh',lv_executable_code,NULL,NULL,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_SCRIPTS_DIRECTORY#/#NAME#.log','OTHER','NO','NO');

--- TEST_PROCEDURE ---

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(17,'TEST_PROCEDURE','Test stored procedure','STORED_PROCEDURE','ACA_TEST_SCHEDULER_PROC',NULL,NULL,NULL,NULL,NULL,'IMMEDIATE',NULL,NULL,NULL,'YES','YES',NULL,'OTHER','NO','NO');

--- WIN_APEX_EXPORT_EXE_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock

if exist %LOCK_FILE% (
   exit /b 0
)

echo locked > %LOCK_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo exec aca_apex_util.export(''#NAME#''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(18,'WIN_APEX_EXPORT_EXE_TEMPLATE','Windows Apex Workspace and Application Export','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,NULL,NULL,'IMMEDIATE',NULL,NULL,NULL,'YES','YES',NULL,'APEX','NO','NO');

--- WIN_BACKUP_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
set LOG_FILE=#OS_LOG_DIRECTORY#\#NAME#.log
set NOW=%date:~-4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%
set NOW=%NOW: =%

if exist %LOCK_FILE% (
   echo "Lock file detected - Script already running - Ignore" >> %LOG_FILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\rman target / @%OS_SCRIPTS_DIRECTORY%\%NAME%.rman log=%LOG_FILE%
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to make a backup." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)


copy %LOG_FILE% %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to copy log file." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo exec aca_util.update_log_filename(''%NAME%'', ''%OS_LOG_DIRECTORY%\%NAME%-%NOW%.log''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo "Unable to update log filename." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOG_FILE%
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to remove original log file." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'# NOTE: This is an example and will be overwritten
RUN{
ALLOCATE CHANNEL D1 TYPE DISK;
REPORT SCHEMA;
CROSSCHECK BACKUPSET;
DELETE NOPROMPT EXPIRED BACKUPSET;
BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT ''#BACKUP_DIRECTORY#\db_${NOW}_%U.bset'';
BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT ''#BACKUP_DIRECTORY#\arch_${NOW}.bset'' delete all input;
BACKUP CURRENT CONTROLFILE FORMAT ''#BACKUP_DIRECTORY#\ctl_${NOW}.bset'';
RESTORE DATABASE VALIDATE;
DELETE NOPROMPT OBSOLETE;
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(19,'WIN_BACKUP_TEMPLATE','Windows Backup Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#\#NAME#.log','BACKUP','NO','NO');

--- WIN_BACKUP_TEMPLATE_PDB ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
set LOG_FILE=#OS_LOG_DIRECTORY#\#NAME#.log
set NOW=%date:~-4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%
set NOW=%NOW: =%

if exist %LOCK_FILE% (
   echo "Lock file detected - Script already running - Ignore" >> %LOG_FILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\rman target #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# @%OS_SCRIPTS_DIRECTORY%\%NAME%.rman log=%LOG_FILE%
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to make a backup." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)


copy %LOG_FILE% %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to copy log file." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo exec aca_util.update_log_filename(''%NAME%'', ''%OS_LOG_DIRECTORY%\%NAME%-%NOW%.log''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo "Unable to update log filename." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOG_FILE%
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to remove original log file." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'# NOTE: This is an example and will be overwritten
RUN{
ALLOCATE CHANNEL D1 TYPE DISK;
REPORT SCHEMA;
CROSSCHECK BACKUPSET;
DELETE NOPROMPT EXPIRED BACKUPSET;
BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT ''#BACKUP_DIRECTORY#\db_${NOW}_%U.bset'';
BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT ''#BACKUP_DIRECTORY#\arch_${NOW}.bset'' delete all input;
BACKUP CURRENT CONTROLFILE FORMAT ''#BACKUP_DIRECTORY#\ctl_${NOW}.bset'';
RESTORE DATABASE VALIDATE;
DELETE NOPROMPT OBSOLETE;
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(20,'WIN_BACKUP_TEMPLATE_PDB','Windows Backup Template PDB','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#\#NAME#.log','BACKUP','NO','NO');


--- WIN_CLONE_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set NAME=#NAME#
set DB_USER=#DB_USER#
set OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
set LOG_FILE=#OS_LOG_DIRECTORY#\#NAME#.log
set COMMAND_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.rman
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set SYS_PASSWORD=#SYS_PASSWORD#
set SOURCE_TNS_NAME=#SOURCE_TNS_NAME#
set DESTINATION_TNS_NAME=#DESTINATION_TNS_NAME#
set DESTINATION_DB_NAME=#DESTINATION_DB_NAME#
set NOW=%date:~-4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%
set NOW=%NOW: =%

if exist %LOCK_FILE% (
   echo Lock file detected - Script already running - Ignore >> %LOG_FILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT sys/%SYS_PASSWORD%@%SOURCE_TNS_NAME% AS SYSDBA^
'||CHR(38)||' echo exec %DB_USER%.aca_clone_util.rewrite_command_file(''%NAME%''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo Unable to rewrite command file at %SOURCE_TNS_NAME%. >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT sys/%SYS_PASSWORD%@%SOURCE_TNS_NAME% AS SYSDBA^
'||CHR(38)||' echo exec %DB_USER%.aca_database_util.set_alert_log_exclude_files(''%NAME%'', ''%DESTINATION_DB_NAME%'', ''BEGIN''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG
if %ERRORLEVEL% NEQ 0 (
   echo Unable to set alert log exclude for %DESTINATION_DB_NAME%. >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

echo. >> %LOG_FILE%
echo Startup nomount database at %DESTINATION_TNS_NAME% >> %LOG_FILE%
echo. >> %LOG_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT sys/%SYS_PASSWORD%@%DESTINATION_TNS_NAME% AS SYSDBA^
'||CHR(38)||' echo shutdown abort;^
'||CHR(38)||' echo startup nomount;^
'||CHR(38)||' echo exit;
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo Unable to start the database at %DESTINATION_TNS_NAME% in nomount state. >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

echo. >> %LOG_FILE%
echo Starting clone to database at %DESTINATION_TNS_NAME% >> %LOG_FILE%
echo. >> %LOG_FILE%

%ORACLE_HOME%\bin\rman target sys/%SYS_PASSWORD%@%SOURCE_TNS_NAME% auxiliary sys/%SYS_PASSWORD%@%DESTINATION_TNS_NAME% cmdfile %COMMAND_FILE% log=%LOG_FILE% append

if %ERRORLEVEL% NEQ 0 (
        echo Unable to clone the database from %SOURCE_TNS_NAME% to %DESTINATION_TNS_NAME%. >> %LOG_FILE%
        del %LOCK_FILE%
        exit /b 1
)

echo. >> %LOG_FILE%
echo Final Maintenance Steps at %DESTINATION_TNS_NAME% >> %LOG_FILE%
echo. >> %LOG_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT sys/%SYS_PASSWORD%@%DESTINATION_TNS_NAME% AS SYSDBA^
'||CHR(38)||' echo exec dbms_scheduler.set_scheduler_attribute(''SCHEDULER_DISABLED'',''TRUE''^^^);^
'||CHR(38)||' echo exit;
) | %ORACLE_HOME%\bin\sqlplus /NOLOG


if %ERRORLEVEL% NEQ 0 (
        echo Final maintenance steps failed - %DESTINATION_TNS_NAME% >> %LOG_FILE%
        del %LOCK_FILE%
        exit /b 1
)

echo. >> %LOG_FILE%
echo Finished clone to database at %DESTINATION_TNS_NAME% >> %LOG_FILE%
echo. >> %LOG_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT sys/%SYS_PASSWORD%@%SOURCE_TNS_NAME% AS SYSDBA^
'||CHR(38)||' echo exec %DB_USER%.aca_database_util.set_alert_log_exclude_files(''%NAME%'', ''%DESTINATION_DB_NAME%'', ''END''^^^);^
'||CHR(38)||' echo exit;
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
        echo Unable to reset alert log exclude for - %DESTINATION_TNS_NAME% >> %LOG_FILE%
        del %LOCK_FILE%
        exit /b 1
)

copy %LOG_FILE% %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log

if %ERRORLEVEL% NEQ 0 (
        echo Unable to copy log file. >> %LOG_FILE%
        del %LOCK_FILE%
        exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT sys/%SYS_PASSWORD%@%SOURCE_TNS_NAME% AS SYSDBA^
'||CHR(38)||' echo exec %DB_USER%.aca_util.update_log_filename(''%NAME%'', ''%OS_LOG_DIRECTORY%\%NAME%-%NOW%.log''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
        echo Unable to update log filename. >> %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
        del %LOCK_FILE%
        exit /b 1
)

del %LOG_FILE%

if %ERRORLEVEL% NEQ 0 (
        echo Unable to remove original log file. >> %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
        del %LOCK_FILE%
        exit /b 1
)

del %LOCK_FILE%

echo. >> %OS_LOG_DIRECTORY%\%NAME%_%NOW%.log
echo Finished scheduled clone. >> %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
echo. >> %OS_LOG_DIRECTORY%\%NAME%_%NOW%.log';

lv_command_code :=
'# NOTE: This command file will be overwritten by a scheduled clone
RUN
{
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(21,'WIN_CLONE_TEMPLATE','Windows Clone Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#\#NAME#.log','CLONE_DB','NO','NO');

--- WIN_EXPORT_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set LOGFILE=#LOGFILE#
set DUMPPATH=#DUMPPATH#

if exist %LOCK_FILE% (
   echo Lock file detected - Script already running - Ignore >> %LOGFILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\expdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=%OS_SCRIPTS_DIRECTORY%\%NAME%.par

if %ERRORLEVEL% NEQ 0 (
   echo Data pump export failed. %ERRORLEVEL% >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'JOB_NAME=#JOB_NAME#
DIRECTORY=#DUMPDIR#
$DUMPFILE$
LOGFILE=#LOGFILE#
$FILESIZE$
$PARALLEL$
$COMPRESSION$
$ENCRYPTION$
$ENCRYPTION_PASSWORD$
REUSE_DUMPFILES=#REUSE_DUMPFILES#
ESTIMATE_ONLY=#ESTIMATE_ONLY#
CONTENT=#CONTENT#
FULL=#FULL#
$SCHEMAS$
$TABLESPACES$
$TABLES$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(22,'WIN_EXPORT_TEMPLATE','Windows Data Pump Export Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#\#LOGFILE#','EXPORT','NO','NO');

--- WIN_EXPORT_TEMPLATE_SCHEDULE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set DUMPPATH=#DUMPPATH#
set DUMPFILE=#DUMPFILE#
set LOGFILE=#LOGFILE#
set NOW=%date:~-4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%
set NOW=%NOW: =%

if exist %LOCK_FILE% (
   echo Lock file detected - Script already running - Ignore >> %LOGFILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\expdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=%OS_SCRIPTS_DIRECTORY%\%NAME%.par

if %ERRORLEVEL% NEQ 0 (
   echo Data pump export failed. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

mkdir %DUMPPATH%\%NAME%-%NOW%
setlocal enabledelayedexpansion
set DUMPFILE=!DUMPFILE:%U=*!
setlocal disabledelayedexpansion

copy %DUMPPATH%\%DUMPFILE% %DUMPPATH%\%NAME%-%NOW%
if %ERRORLEVEL% NEQ 0 (
   echo Unable to copy dump file. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

copy %DUMPPATH%\%LOGFILE% %DUMPPATH%\%NAME%-%NOW%\%NAME%.log
if %ERRORLEVEL% NEQ 0 (
   echo Unable to copy log file. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo exec aca_util.update_log_filename(''%NAME%'', ''%DUMPPATH%\%NAME%-%NOW%\%NAME%.log''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo Unable to update log filename. >> %DUMPPATH%\%NAME%-%NOW%\%NAME%.log
   del %LOCK_FILE%
   exit /b 1
)

del %DUMPPATH%\%LOGFILE%
if %ERRORLEVEL% NEQ 0 (
   echo Unable to remove original log file. >> %DUMPPATH%\%NAME%-%NOW%\%NAME%.log
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'JOB_NAME=#JOB_NAME#
DIRECTORY=#DUMPDIR#
$DUMPFILE$
LOGFILE=#LOGFILE#
$FILESIZE$
$PARALLEL$
$COMPRESSION$
$ENCRYPTION$
$ENCRYPTION_PASSWORD$
REUSE_DUMPFILES=#REUSE_DUMPFILES#
ESTIMATE_ONLY=#ESTIMATE_ONLY#
FULL=#FULL#
CONTENT=#CONTENT#
$SCHEMAS$
$TABLESPACES$
$TABLES$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(23,'WIN_EXPORT_TEMPLATE_SCHEDULE','Windows Scheduled Data Pump Export Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#\#LOGFILE#','EXPORT','NO','NO');

--- WIN_IMPORT_HELP_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set LOGFILE=#LOGFILE#
set DUMPPATH=#DUMPPATH#

if exist %LOCK_FILE% (
   echo Lock file detected - Script already running - Ignore >> %DUMPPATH%\%LOGFILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo ALTER TABLE sbh_page_links DISABLE CONSTRAINT sbh_plk_sbh_hlp_fk;
) | %ORACLE_HOME%\bin\sqlplus /NOLOG
if %ERRORLEVEL% NEQ 0 (
   echo Unable to disable constraint sbh_plk_sbh_hlp_fk >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

%ORACLE_HOME%\bin\impdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=%OS_SCRIPTS_DIRECTORY%\%NAME%.par

if %ERRORLEVEL% NEQ 0 (
   echo Data pump import failed. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo ALTER TABLE sbh_page_links ENABLE CONSTRAINT sbh_plk_sbh_hlp_fk;
) | %ORACLE_HOME%\bin\sqlplus /NOLOG
if %ERRORLEVEL% NEQ 0 (
   echo Unable to enable constraint sbh_plk_sbh_hlp_fk >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'DIRECTORY=#DUMPDIR#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#
TABLE_EXISTS_ACTION=#TABLE_EXISTS_ACTION#
FULL=#FULL#
CONTENT=#CONTENT#
$PARALLEL$
$ENCRYPTION_PASSWORD$
$SCHEMAS$
$TABLESPACES$
$TABLES$
$REMAP_SCHEMA$
$REMAP_TABLESPACE$
';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(24,'WIN_IMPORT_HELP_TEMPLATE','Windows Import Help Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#\#LOGFILE#','IMPORT','NO','NO');

--- WIN_IMPORT_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set LOGFILE=#LOGFILE#
set DUMPPATH=#DUMPPATH#

if exist %LOCK_FILE% (
   echo Lock file detected - Script already running - Ignore >> %LOGFILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\impdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=%OS_SCRIPTS_DIRECTORY%\%NAME%.par

if %ERRORLEVEL% NEQ 0 (
   echo Data pump import failed. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'TRANSFORM=SEGMENT_ATTRIBUTES:n
TRANSFORM=OID:n
DIRECTORY=#DUMPDIR#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#
TABLE_EXISTS_ACTION=#TABLE_EXISTS_ACTION#
FULL=#FULL#
CONTENT=#CONTENT#
$PARALLEL$
$ENCRYPTION_PASSWORD$
$SCHEMAS$
$TABLESPACES$
$TABLES$
$REMAP_SCHEMA$
$REMAP_TABLESPACE$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(25,'WIN_IMPORT_TEMPLATE','Windows Data Pump Import Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#\#LOGFILE#','IMPORT','NO','NO');

--- WIN_IMPORT_TEMPLATE_SCHEDULE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set DUMPPATH=#DUMPPATH#
set DUMPFILE=#DUMPFILE#
set LOGFILE=#LOGFILE#
set NOW=%date:~-4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%
set NOW=%NOW: =%

if exist %LOCK_FILE% (
   echo Lock file detected - Script already running - Ignore >> %LOGFILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\impdp #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME# parfile=%OS_SCRIPTS_DIRECTORY%\%NAME%.par

if %ERRORLEVEL% NEQ 0 (
   echo Data pump import failed. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

copy %DUMPPATH%\%LOGFILE% %DUMPPATH%\%NAME%-%NOW%.log
if %ERRORLEVEL% NEQ 0 (
   echo Unable to copy log file. >> %DUMPPATH%\%LOGFILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo exec aca_util.update_log_filename(''%NAME%'', ''%DUMPPATH%\%NAME%-%NOW%.log''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo Unable to update log filenam. >> %DUMPPATH%\%NAME%-%NOW%.log
   del %LOCK_FILE%
   exit /b 1
)

del %DUMPPATH%\%LOGFILE%
if %ERRORLEVEL% NEQ 0 (
   echo Unable to remove original log file. >> %DUMPPATH%\%NAME%-%NOW%.log
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'TRANSFORM=SEGMENT_ATTRIBUTES:n
TRANSFORM=OID:n
DIRECTORY=#DUMPDIR#
DUMPFILE=#DUMPFILE#
LOGFILE=#LOGFILE#
TABLE_EXISTS_ACTION=#TABLE_EXISTS_ACTION#
FULL=#FULL#
CONTENT=#CONTENT#
$PARALLEL$
$ENCRYPTION_PASSWORD$
$SCHEMAS$
$TABLESPACES$
$TABLES$
$REMAP_SCHEMA$
$REMAP_TABLESPACE$';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(26,'WIN_IMPORT_TEMPLATE_SCHEDULE','Windows Scheduled Data Pump Import Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.par',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#DUMPPATH#\#LOGFILE#','IMPORT','NO','NO');

--- WIN_RMAN_CONFIG_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
set LOG_FILE=#OS_LOG_DIRECTORY#\#NAME#.log

if exist %LOCK_FILE% (
   echo "Lock file detected - Script already running - Ignore" >> %LOG_FILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

%ORACLE_HOME%\bin\rman target / @%OS_SCRIPTS_DIRECTORY%\%NAME%.rman log=%LOG_FILE% append

if %ERRORLEVEL% NEQ 0 (
   echo "Unable to configure RMAN." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'# NOTE: This is an example and will be overwritten
RUN{
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 10 DAYS;
}';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(27,'WIN_RMAN_CONFIG_TEMPLATE','Windows RMAN configuration','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.rman',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#\#NAME#.log','BACKUP','NO','NO');

--- WIN_SQL_TEMPLATE ---

lv_executable_code :=
'@echo off

set ORACLE_HOME=#ORACLE_HOME#
set ORACLE_SID=#ORACLE_SID#
set NAME=#NAME#
set OS_SCRIPTS_DIRECTORY=#OS_SCRIPTS_DIRECTORY#
set LOCK_FILE=#OS_SCRIPTS_DIRECTORY#\#NAME#.lock
set OS_LOG_DIRECTORY=#OS_LOG_DIRECTORY#
set LOG_FILE=#OS_LOG_DIRECTORY#\#NAME#.log
set NOW=%date:~-4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%
set NOW=%NOW: =%

if exist %LOCK_FILE% (
   echo "Lock file detected - Script already running - Ignore" >> %LOG_FILE%
   exit /b 0
)

echo locked > %LOCK_FILE%

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo SET ECHO ON^
'||CHR(38)||' echo SPOOL %OS_LOG_DIRECTORY%\%NAME%.log^
'||CHR(38)||' echo @%OS_SCRIPTS_DIRECTORY%\%NAME%.sql
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo "SQL script failed." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

copy %LOG_FILE% %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to copy log file." >> %LOG_FILE%
   del %LOCK_FILE%
   exit /b 1
)

(
echo WHENEVER SQLERROR EXIT SQL.SQLCODE^
'||CHR(38)||' echo CONNECT #USERNAME_PASSWORD#@#DB_HOST#:#DB_PORT#/#DB_SERVICE_NAME#^
'||CHR(38)||' echo exec aca_util.update_log_filename(''%NAME%'', ''%OS_LOG_DIRECTORY%\%NAME%-%NOW%.log''^^^);
) | %ORACLE_HOME%\bin\sqlplus /NOLOG

if %ERRORLEVEL% NEQ 0 (
   echo "Unable to update log filename." >> %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
   del %LOCK_FILE%
   exit /b 1
)

del %LOG_FILE%
if %ERRORLEVEL% NEQ 0 (
   echo "Unable to remove original log file." >> %OS_LOG_DIRECTORY%\%NAME%-%NOW%.log
   del %LOCK_FILE%
   exit /b 1
)

del %LOCK_FILE%';

lv_command_code :=
'-- Starting Test --
SELECT table_name, tablespace_name FROM user_tables;
-- End Test --';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(28,'WIN_SQL_TEMPLATE','Windows SQL Template','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,'#OS_SCRIPTS_DIRECTORY#\#NAME#.sql',lv_command_code,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#\#NAME#.log','SQL','NO','NO');

--- WIN_TEST_EXECUTABLE ---

lv_executable_code :=
'echo hello > #OS_LOG_DIRECTORY#\#NAME#.log';

INSERT INTO aca_jobs (ID,NAME,DESCRIPTION,PROGRAM_TYPE,PROCEDURE_NAME,PLSQL_CODE,EXECUTABLE_FILENAME,EXECUTABLE_CODE,COMMAND_FILENAME,COMMAND_CODE,JOB_EXECUTION,REPEAT_INTERVAL,START_DATE,END_DATE,ENABLED,PERMANENT,LOG_FILENAME,LOG_CATEGORY,LOG_RUN,NOTIFICATIONS)
VALUES(29,'WIN_TEST_EXECUTABLE','Test Windows executable','EXECUTABLE',NULL,NULL,'#OS_SCRIPTS_DIRECTORY#\#NAME#.bat',lv_executable_code,NULL,NULL,'IMMEDIATE',NULL,NULL,NULL,'YES','YES','#OS_LOG_DIRECTORY#\#NAME#.log','OTHER','NO','NO');

      -- Lock the jobs

      UPDATE aca_jobs
         SET locked = 'YES';

      -- ACA_JOB_ARGUMENTS

      INSERT INTO aca_job_arguments (JOB_ID,NAME,VALUE,ENABLED,ORDER_SEQUENCE)
      VALUES(16,'ARG1', NULL,'YES',10);
      INSERT INTO aca_job_arguments (JOB_ID,NAME,VALUE,ENABLED,ORDER_SEQUENCE)
      VALUES(16,'ARG2', NULL,'YES',20);

      INSERT INTO aca_job_arguments (JOB_ID,NAME,VALUE,ENABLED,ORDER_SEQUENCE)
      VALUES(17,'P_PARAM1','X','YES',10);
      INSERT INTO aca_job_arguments (JOB_ID,NAME,VALUE,ENABLED,ORDER_SEQUENCE)
      VALUES(17,'P_PARAM2','Z','YES',20);

      -- ACA_JOB_SUBSTITUTIONS

      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(1,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(1,'USERNAME_PASSWORD','YES',20);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(2,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(2,'USERNAME_PASSWORD','YES',20);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(3,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(3,'USERNAME_PASSWORD','YES',20);

      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)  
      VALUES(4,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(4,'SYS_PASSWORD','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(4,'SOURCE_TNS_NAME','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(4,'DESTINATION_TNS_NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(4,'DESTINATION_DB_NAME','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      
      VALUES(5,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'DUMPDIR','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'DUMPPATH','YES',55);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'DUMPFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'LOGFILE','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'PARALLEL','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'FILESIZE','YES',85);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'REUSE_DUMPFILES','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'COMPRESSION','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'ENCRYPTION','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'ENCRYPTION_PASSWORD','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'ESTIMATE_ONLY','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'FULL','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'SCHEMAS','YES',200);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'TABLESPACES','YES',210);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'TABLES','YES',220);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'CONTENT','YES',230);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(5,'JOB_NAME','YES',240);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'DUMPDIR','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'DUMPPATH','YES',55);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'DUMPFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'LOGFILE','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'PARALLEL','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'FILESIZE','YES',85);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'REUSE_DUMPFILES','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'COMPRESSION','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'ENCRYPTION','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'ENCRYPTION_PASSWORD','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'ESTIMATE_ONLY','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'FULL','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'SCHEMAS','YES',200);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'TABLESPACES','YES',210);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'TABLES','YES',220);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'CONTENT','YES',230);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(6,'JOB_NAME','YES',240);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'NAME','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'DUMPDIR','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'DUMPPATH','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'DUMPFILE','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'LOGFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'PARALLEL','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'ENCRYPTION_PASSWORD','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'TABLE_EXISTS_ACTION','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'FULL','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'SCHEMAS','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'TABLESPACES','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'TABLES','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'REMAP_SCHEMA','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'REMAP_TABLESPACE','YES',150);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(7,'CONTENT','YES',160);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'DUMPDIR','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'DUMPPATH','YES',55);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'DUMPFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'LOGFILE','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'PARALLEL','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'ENCRYPTION_PASSWORD','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'TABLE_EXISTS_ACTION','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'FULL','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'SCHEMAS','YES',200);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'TABLESPACES','YES',210);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'TABLES','YES',220);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'REMAP_SCHEMA','YES',230);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'REMAP_TABLESPACE','YES',240);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(8,'CONTENT','YES',250);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'NAME','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'DUMPDIR','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'DUMPPATH','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'DUMPFILE','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'LOGFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'PARALLEL','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'ENCRYPTION_PASSWORD','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'TABLE_EXISTS_ACTION','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'FULL','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'SCHEMAS','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'TABLESPACES','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'TABLES','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'REMAP_SCHEMA','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'REMAP_TABLESPACE','YES',150);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(9,'CONTENT','YES',160);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(12,'NAME','YES',10);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(15,'NAME','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(15,'USERNAME_PASSWORD','YES',40);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(16,'SUB1','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(16,'SUB2','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      
      VALUES(18,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(18,'USERNAME_PASSWORD','YES',20);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(19,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(19,'USERNAME_PASSWORD','YES',20);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(20,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(20,'USERNAME_PASSWORD','YES',20);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(21,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(21,'SYS_PASSWORD','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(21,'SOURCE_TNS_NAME','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(21,'DESTINATION_TNS_NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(21,'DESTINATION_DB_NAME','YES',50);
     
     INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'DUMPDIR','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'DUMPPATH','YES',55);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'DUMPFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'LOGFILE','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'PARALLEL','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'FILESIZE','YES',85);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'REUSE_DUMPFILES','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'COMPRESSION','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'ENCRYPTION','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'ENCRYPTION_PASSWORD','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'ESTIMATE_ONLY','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'FULL','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'SCHEMAS','YES',200);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'TABLESPACES','YES',210);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'TABLES','YES',220);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'CONTENT','YES',230);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(22,'JOB_NAME','YES',240);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'DUMPDIR','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'DUMPPATH','YES',55);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'DUMPFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'LOGFILE','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'PARALLEL','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'FILESIZE','YES',85);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'REUSE_DUMPFILES','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'COMPRESSION','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'ENCRYPTION','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'ENCRYPTION_PASSWORD','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'ESTIMATE_ONLY','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'FULL','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'SCHEMAS','YES',200);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'TABLESPACES','YES',210);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'TABLES','YES',220);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'CONTENT','YES',230);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(23,'JOB_NAME','YES',240);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'NAME','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'DUMPDIR','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'DUMPPATH','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'DUMPFILE','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'LOGFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'PARALLEL','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'ENCRYPTION_PASSWORD','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'TABLE_EXISTS_ACTION','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'FULL','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'SCHEMAS','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'TABLESPACES','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'TABLES','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'REMAP_SCHEMA','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'REMAP_TABLESPACE','YES',150);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(24,'CONTENT','YES',160);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'NAME','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'DUMPDIR','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'DUMPPATH','YES',55);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'DUMPFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'LOGFILE','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'PARALLEL','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'ENCRYPTION_PASSWORD','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'TABLE_EXISTS_ACTION','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'FULL','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'SCHEMAS','YES',200);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'TABLESPACES','YES',210);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'TABLES','YES',220);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'REMAP_SCHEMA','YES',230);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'REMAP_TABLESPACE','YES',240);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(25,'CONTENT','YES',250);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'USERNAME_PASSWORD','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'NAME','YES',20);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'DUMPDIR','YES',30);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'DUMPPATH','YES',40);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'DUMPFILE','YES',50);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'LOGFILE','YES',60);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'PARALLEL','YES',70);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'ENCRYPTION_PASSWORD','YES',80);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'TABLE_EXISTS_ACTION','YES',90);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'FULL','YES',100);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'SCHEMAS','YES',110);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'TABLESPACES','YES',120);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'TABLES','YES',130);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'REMAP_SCHEMA','YES',140);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'REMAP_TABLESPACE','YES',150);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(26,'CONTENT','YES',160);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(27,'NAME','YES',10);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(28,'NAME','YES',10);
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(28,'USERNAME_PASSWORD','YES',20);
      
      INSERT INTO aca_job_substitutions (JOB_ID,NAME,ENABLED,ORDER_SEQUENCE)
      VALUES(29,'NAME','YES',10);

   END load_aca_jobs;

   PROCEDURE init IS
      -- Purpose: To initialize application tables.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/26/2015  Creation
      -- GL Skillbuilders   06/12/2015  Changes for V1.0.2
      -- GL Skillbuilders   07/05/2015  Changes for V1.0.3
      -- GL Skillbuilders   07/05/2015  Changes for V1.0.4
      -- GL Skillbuilders   09/21/2015  Changes for V1.0.5
      -- GL Skillbuilders   10/17/2015  Changes for V1.0.6
      -- GL Skillbuilders   10/23/2015  Changes for V1.0.7
      -- GL Skillbuilders   11/11/2015  Changes for V1.0.8
      -- GL Skillbuilders   12/07/2015  Changes for V1.0.9
      -- GL Skillbuilders   12/15/2015  Changes for V1.1.0
      -- GL Skillbuilders   01/28/2016  Changes for V1.1.1
      --

   BEGIN

-- Table inserts

-- ACA_ALERT_LOG_FILTERS

INSERT INTO aca_alert_log_filters (FILTER,FILTER_TYPE,DESCRIPTION,ENABLED)
VALUES('ORA-','LIKE','Any ORA error','YES');
INSERT INTO aca_alert_log_filters (FILTER,FILTER_TYPE,DESCRIPTION,ENABLED)
VALUES('ORA-3136','NOT LIKE','WARNING: inbound connection timed out (ORA-3136) ','YES');
INSERT INTO aca_alert_log_filters (FILTER,FILTER_TYPE,DESCRIPTION,ENABLED)
VALUES('result of ORA-28','NOT LIKE','Killed session','YES');

-- ACA_LAST_RUN_DATES

INSERT INTO aca_last_run_dates
VALUES('SCAN_ALERT_LOG',SYSTIMESTAMP);

-- ACA_CONFIGURATION

INSERT INTO aca_configuration (ID,NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES(0,'INSTALLATION_COMPLETE','NO','This is an internal parameter used to indicate that post installation configuration has been completed','NO',0);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('APEX_WORKSPACE',NULL,'The APEX workspace in which this application resides. This is required for notifications.','YES',10);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('APP_IDENTIFIER',NULL,'This value should uniquely identify this installation. All notifications will contain this value.','YES',20);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('APP_EMAIL_FROM',NULL,'All notifications will have this address as sender.','YES',30);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ASM','NO','ASM Used','YES',40);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ASM_HOSTNAME',NULL,'ASM Host Name','YES',50);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ASM_PORT',NULL,'ASM Port Number','YES',60);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ASM_SID',NULL,'ASM System Identifier','YES',70);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ASM_SYSASM_USER',NULL,'ASM User with SYSASM privs.','YES',80);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ASM_SYSASM_PASSWORD',NULL,'Password of ASM User with SYSASM privs.','YES',90);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_TYPE',NULL,'Operating System Type. UNIX (also for Linux) or WINDOWS.','NO',100);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_CREDENTIAL_NAME','OS_USER','The credential name used by the scheduler','NO',110);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_USER',NULL,'Operating System username. This is used for the scheduler credential.','YES',120);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_PASSWORD',NULL,'Operating System user''s password. This is used for the scheduler credential.','YES',130);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_HOME_DIRECTORY',NULL,'Operating System user''s home directory','YES',140);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_SCRIPTS_DIRECTORY',NULL,'Operating System scripts directory.','YES',150);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_LOG_DIRECTORY',NULL,'OS Directory for log files.','YES',160);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_APEX_DIRECTORY',NULL,'OS Directory for APEX exports.','YES',170);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_EXECUTABLE_NAME','/bin/bash','Executable used by the scheduler. This parameter only applies to OS_TYPE UNIX.','YES',180);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_FILESYSTEM_USAGE_CHECK','NO','Check operating system filesystem usage. YES or NO. Note: If this check fails then this parameter will automatically be set to DISABLED to prevent further checking. This parameter only applies to OS_TYPE UNIX.','YES',190);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('OS_FILESYSTEM_USAGE_ALERT','95','Raise an alert when an OS filesystem percentage usage exceeds this value. This parameter only applies to OS_TYPE UNIX.','YES',200);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DB_EDITION','STANDARD','Database Edition STANDARD, ENTERPRISE or EXPRESS','NO',210);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('ORACLE_HOME',NULL,'Oracle Home','YES',220);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DB_HOST',NULL,'SQL*Net Host Name / IP Address','YES',230);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DB_PORT',NULL,'SQL*Net Port Number','YES',240);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DB_SERVICE_NAME',NULL,'SQL*Net Service Name','YES',250);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DB_USER',NULL,'Database user. Used for data pump exports and imports','YES',260);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DB_PASSWORD',NULL,'Database user''s password. Used for data pump exports and imports.','YES',270);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DATA_PUMP_DIRECTORY','SBA_DATA_PUMP_DIR','Name of the Oracle directory object which is used for data pump export and import.','NO',280);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('DATA_PUMP_DIRECTORY_PATH',NULL,'OS path to the directory used by DATA_PUMP_DIRECTORY Oracle directory object.','YES',290);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('RECOVERY_AREA_USAGE_ALERT','95','Raise an alert when the fast recovery area percentage usage exceeds this value.','YES',300);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('MEDIA_MANAGER','NO','A Media Manager is available for backups.','YES',310);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('TABLESPACE_USAGE_RETENTION','30','Tablespace usage retention in days.','YES',320);

INSERT INTO aca_configuration (NAME,VALUE,DESCRIPTION,ENABLED,ORDER_SEQUENCE)
VALUES('WIN_PROGRAMS_PATH','C:\Windows\System32','Path of WINDOWS executables. Only applies to OS_TYPE WINDOWS.','YES',330);

-- SBH_HELP

INSERT INTO sbh_help (ID,HELP_ID,OBJECT_TYPE,TITLE,SHORT_TITLE,TEXT,ENABLED,ORDER_SEQUENCE)
VALUES(0,NULL,'TEXT','SkillBuilders Oracle Database Manager','Oracle Database Manager','
 <hr />
 <p style="text-align: center;">
 <span style="color:#4b66a7;"><span style="font-size: 24px;"><span style="font-family: times new roman,times,serif;">SkillBuilders Oracle Database Manager</span></span></span>
 </p>
 <hr />
','YES',10);

-- ACA_METRICS

INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(1000,'AVG_USERS_WAITING','Average Users Waiting Counts','Users','OBJECT_TYPE_EVENT_CLASS');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(1001,'DB_TIME_WAITING','Database Time Spent Waiting (%)','% (TimeWaited / DBTime)','OBJECT_TYPE_EVENT_CLASS');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2000,'BUFFER_CACHE_HIT','Buffer Cache Hit Ratio','% (LogRead - PhyRead)/LogRead','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2001,'MEMORY_SORTS_PCT','Memory Sorts Ratio','% MemSort/(MemSort + DiskSort)','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2002,'REDO_ALLOCATION_HIT','Redo Allocation Hit Ratio','% (#Redo - RedoSpaceReq)/#Redo','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2003,'USER_TRANSACTIONS_SEC','User Transaction Per Sec','Transactions Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2004,'PHYSICAL_READS_SEC','Physical Reads Per Sec','Reads Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2005,'PHYSICAL_READS_TXN','Physical Reads Per Txn','Reads Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2006,'PHYSICAL_WRITES_SEC','Physical Writes Per Sec','Writes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2007,'PHYSICAL_WRITES_TXN','Physical Writes Per Txn','Writes Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2008,'PHYSICAL_READS_DIR_SEC','Physical Reads Direct Per Sec','Reads Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2009,'PHYSICAL_READS_DIR_TXN','Physical Reads Direct Per Txn','Reads Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2010,'PHYSICAL_WRITES_DIR_SEC','Physical Writes Direct Per Sec','Writes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2011,'PHYSICAL_WRITES_DIR_TXN','Physical Writes Direct Per Txn','Writes Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2012,'PHYSICAL_READS_LOB_SEC','Physical Reads Direct Lobs Per Sec','Reads Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2013,'PHYSICAL_READS_LOB_TXN','Physical Reads Direct Lobs Per Txn','Reads Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2014,'PHYSICAL_WRITES_LOB_SEC','Physical Writes Direct Lobs Per Sec','Writes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2015,'PHYSICAL_WRITES_LOB_TXN','Physical Writes Direct Lobs  Per Txn','Writes Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2016,'REDO_GENERATED_SEC','Redo Generated Per Sec','Bytes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2017,'REDO_GENERATED_TXN','Redo Generated Per Txn','Bytes Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2018,'LOGONS_SEC','Logons Per Sec','Logons Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2019,'LOGONS_TXN','Logons Per Txn','Logons Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2020,'OPEN_CURSORS_SEC','Open Cursors Per Sec','Cursors Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2021,'OPEN_CURSORS_TXN','Open Cursors Per Txn','Cursors Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2022,'USER_COMMITS_SEC','User Commits Per Sec','Commits Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2023,'USER_COMMITS_TXN','User Commits Percentage','% (UserCommit/TotalUserTxn)','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2024,'USER_ROLLBACKS_SEC','User Rollbacks Per Sec','Rollbacks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2025,'USER_ROLLBACKS_TXN','User Rollbacks Percentage','% (UserRollback/TotalUserTxn)','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2026,'USER_CALLS_SEC','User Calls Per Sec','Calls Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2027,'USER_CALLS_TXN','User Calls Per Txn','Calls Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2028,'RECURSIVE_CALLS_SEC','Recursive Calls Per Sec','Calls Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2029,'RECURSIVE_CALLS_TXN','Recursive Calls Per Txn','Calls Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2030,'SESS_LOGICAL_READS_SEC','Logical Reads Per Sec','Reads Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2031,'SESS_LOGICAL_READS_TXN','Logical Reads Per Txn','Reads Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2032,'DBWR_CKPT_SEC','DBWR Checkpoints Per Sec','Check Points Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2033,'BACKGROUND_CKPT_SEC','Background Checkpoints Per Sec','Check Points Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2034,'REDO_WRITES_SEC','Redo Writes Per Sec','Writes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2035,'REDO_WRITES_TXN','Redo Writes Per Txn','Writes Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2036,'LONG_TABLE_SCANS_SEC','Long Table Scans Per Sec','Scans Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2037,'LONG_TABLE_SCANS_TXN','Long Table Scans Per Txn','Scans Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2038,'TOTAL_TABLE_SCANS_SEC','Total Table Scans Per Sec','Scans Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2039,'TOTAL_TABLE_SCANS_TXN','Total Table Scans Per Txn','Scans Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2040,'FULL_INDEX_SCANS_SEC','Full Index Scans Per Sec','Scans Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2041,'FULL_INDEX_SCANS_TXN','Full Index Scans Per Txn','Scans Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2042,'TOTAL_INDEX_SCANS_SEC','Total Index Scans Per Sec','Scans Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2043,'TOTAL_INDEX_SCANS_TXN','Total Index Scans Per Txn','Scans Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2044,'TOTAL_PARSES_SEC','Total Parse Count Per Sec','Parses Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2045,'TOTAL_PARSES_TXN','Total Parse Count Per Txn','Parses Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2046,'HARD_PARSES_SEC','Hard Parse Count Per Sec','Parses Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2047,'HARD_PARSES_TXN','Hard Parse Count Per Txn','Parses Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2048,'PARSE_FAILURES_SEC','Parse Failure Count Per Sec','Parses Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2049,'PARSE_FAILURES_TXN','Parse Failure Count Per Txn','Parses Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2050,'CURSOR_CACHE_HIT','Cursor Cache Hit Ratio','% CursorCacheHit/SoftParse','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2051,'DISK_SORT_SEC','Disk Sort Per Sec','Sorts Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2052,'DISK_SORT_TXN','Disk Sort Per Txn','Sorts Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2053,'ROWS_PER_SORT','Rows Per Sort','Rows Per Sort','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2054,'EXECUTE_WITHOUT_PARSE','Execute Without Parse Ratio','% (ExecWOParse/TotalExec)','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2055,'SOFT_PARSE_PCT','Soft Parse Ratio','% SoftParses/TotalParses','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2056,'USER_CALLS_PCT','User Calls Ratio','% UserCalls/AllCalls','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2057,NULL,'Host CPU Utilization (%)','% Busy/(Idle+Busy)','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2058,'NETWORK_BYTES_SEC','Network Traffic Volume Per Sec','Bytes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2059,'ENQUEUE_TIMEOUTS_SEC','Enqueue Timeouts Per Sec','Timeouts Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2060,'ENQUEUE_TIMEOUTS_TXN','Enqueue Timeouts Per Txn','Timeouts Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2061,'ENQUEUE_WAITS_SEC','Enqueue Waits Per Sec','Waits Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2062,'ENQUEUE_WAITS_TXN','Enqueue Waits Per Txn','Waits Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2063,'ENQUEUE_DEADLOCKS_SEC','Enqueue Deadlocks Per Sec','Deadlocks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2064,'ENQUEUE_DEADLOCKS_TXN','Enqueue Deadlocks Per Txn','Deadlocks Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2065,'ENQUEUE_REQUESTS_SEC','Enqueue Requests Per Sec','Requests Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2066,'ENQUEUE_REQUESTS_TXN','Enqueue Requests Per Txn','Requests Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2067,'DB_BLKGETS_SEC','DB Block Gets Per Sec','Blocks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2068,'DB_BLKGETS_TXN','DB Block Gets Per Txn','Blocks Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2069,'CONSISTENT_GETS_SEC','Consistent Read Gets Per Sec','Blocks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2070,'CONSISTENT_GETS_TXN','Consistent Read Gets Per Txn','Blocks Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2071,'DB_BLKCHANGES_SEC','DB Block Changes Per Sec','Blocks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2072,'DB_BLKCHANGES_TXN','DB Block Changes Per Txn','Blocks Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2073,'CONSISTENT_CHANGES_SEC','Consistent Read Changes Per Sec','Blocks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2074,'CONSISTENT_CHANGES_TXN','Consistent Read Changes Per Txn','Blocks Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2075,'SESSION_CPU_SEC','CPU Usage Per Sec','CentiSeconds Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2076,'SESSION_CPU_TXN','CPU Usage Per Txn','CentiSeconds Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2077,'CR_BLOCKS_CREATED_SEC','CR Blocks Created Per Sec','Blocks Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2078,'CR_BLOCKS_CREATED_TXN','CR Blocks Created Per Txn','Blocks Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2079,'CR_RECORDS_APPLIED_SEC','CR Undo Records Applied Per Sec','Undo Records Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2080,'CR_RECORDS_APPLIED_TXN','CR Undo Records Applied Per Txn','Records Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2081,'RB_RECORDS_APPLIED_SEC','User Rollback UndoRec Applied Per Sec','Records Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2082,'RB_RECORDS_APPLIED_TXN','User Rollback Undo Records Applied Per Txn','Records Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2083,'LEAF_NODE_SPLITS_SEC','Leaf Node Splits Per Sec','Splits Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2084,'LEAF_NODE_SPLITS_TXN','Leaf Node Splits Per Txn','Splits Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2085,'BRANCH_NODE_SPLITS_SEC','Branch Node Splits Per Sec','Splits Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2086,'BRANCH_NODE_SPLITS_TXN','Branch Node Splits Per Txn','Splits Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2087,'PX_DOWNGRADED_25_SEC','PX downgraded 1 to 25% Per Sec','PX Operations Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2088,'PX_DOWNGRADED_50_SEC','PX downgraded 25 to 50% Per Sec','PX Operations Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2089,'PX_DOWNGRADED_75_SEC','PX downgraded 50 to 75% Per Sec','PX Operations Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2090,'PX_DOWNGRADED_SEC','PX downgraded 75 to 99% Per Sec','PX Operations Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2091,'PX_DOWNGRADED_SER_SEC','PX downgraded to serial Per Sec','PX Operations Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2092,NULL,'Physical Read Total IO Requests Per Sec','Requests Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2093,NULL,'Physical Read Total Bytes Per Sec','Bytes Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2094,NULL,'GC CR Block Received Per Second','Blocks Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2095,NULL,'GC CR Block Received Per Txn','Blocks Per Txn',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2096,NULL,'GC Current Block Received Per Second','Blocks Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2097,NULL,'GC Current Block Received Per Txn','Blocks Per Txn',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2098,'GC_AVG_CR_GET_TIME','Global Cache Average CR Get Time','CentiSeconds Per Get','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2099,'GC_AVG_CUR_GET_TIME','Global Cache Average Current Get Time','CentiSeconds Per Get','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2100,NULL,'Physical Write Total IO Requests Per Sec','Requests Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2101,'GC_BLOCKS_CORRUPT','Global Cache Blocks Corrupted','Blocks','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2102,'GC_BLOCKS_LOST','Global Cache Blocks Lost','Blocks','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2103,'LOGONS_CURRENT','Current Logons Count','Logons','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2104,'OPEN_CURSORS_CURRENT','Current Open Cursors Count','Cursors','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2105,'USER_LIMIT_PCT','User Limit %','% Sessions/License_Limit','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2106,'SQL_SRV_RESPONSE_TIME','SQL Service Response Time','CentiSeconds Per Call','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2107,'DATABASE_WAIT_TIME','Database Wait Time Ratio','% Wait/DB_Time','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2108,'DATABASE_CPU_TIME','Database CPU Time Ratio','% Cpu/DB_Time','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2109,'RESPONSE_TXN','Response Time Per Txn','CentiSeconds Per Txn','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2110,'ROW_CACHE_HIT','Row Cache Hit Ratio','% Hits/Gets','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2111,'ROW_CACHE_MISS','Row Cache Miss Ratio','% Misses/Gets','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2112,'LIBARY_CACHE_HIT','Library Cache Hit Ratio','% Hits/Pins','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2113,'LIBARY_CACHE_MISS','Library Cache Miss Ratio','% Misses/Gets','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2114,'SHARED_POOL_FREE_PCT','Shared Pool Free %','% Free/Total','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2115,'PGA_CACHE_HIT','PGA Cache Hit %','% Bytes/TotalBytes','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2118,'PROCESS_LIMIT_PCT','Process Limit %','% Processes/Limit','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2119,'SESSION_LIMIT_PCT','Session Limit %','% Sessions/Limit','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2120,NULL,'Executions Per Txn','Executes Per Txn',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2121,'EXECUTIONS_PER_SEC','Executions Per Sec','Executes Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2122,NULL,'Txns Per Logon','Txns Per Logon',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2123,'DB_TIME_PER_SEC','Database Time Per Sec','CentiSeconds Per Second','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2124,NULL,'Physical Write Total Bytes Per Sec','Bytes Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2125,NULL,'Physical Read IO Requests Per Sec','Requests Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2126,NULL,'Physical Read Bytes Per Sec','Bytes Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2127,NULL,'Physical Write IO Requests Per Sec','Requests Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2128,NULL,'Physical Write Bytes Per Sec','Bytes Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2129,NULL,'DB Block Changes Per User Call','Blocks Per Call',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2130,NULL,'DB Block Gets Per User Call','Blocks Per Call',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2131,NULL,'Executions Per User Call','Executes Per Call',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2132,NULL,'Logical Reads Per User Call','Reads Per Call',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2133,NULL,'Total Sorts Per User Call','Sorts Per Call',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2134,NULL,'Total Table Scans Per User Call','Tables Per Call',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2135,NULL,'Current OS Load','Number Of Processes',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2136,'STREAMS_POOL_USED_PCT','Streams Pool Usage Percentage','% Memory allocated / Size of Streams pool','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2137,NULL,'PQ QC Session Count','Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2138,NULL,'PQ Slave Session Count','Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2139,NULL,'Queries parallelized Per Sec','Queries Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2140,NULL,'DML statements parallelized Per Sec','Statements Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2141,NULL,'DDL statements parallelized Per Sec','Statements Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2142,NULL,'PX operations not downgraded Per Sec','PX Operations Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2143,NULL,'Session Count','Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2144,NULL,'Average Synchronous Single-Block Read Latency','Milliseconds',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2145,NULL,'I/O Megabytes per Second','Megabtyes per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2146,NULL,'I/O Requests per Second','Requests per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2147,NULL,'Average Active Sessions','Active Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2148,NULL,'Active Serial Sessions','Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2149,NULL,'Active Parallel Sessions','Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2150,NULL,'Captured user calls','calls',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2151,NULL,'Replayed user calls','calls',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2152,NULL,'Workload Capture and Replay status','status',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2153,NULL,'Background CPU Usage Per Sec','CentiSeconds Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2154,NULL,'Background Time Per Sec','Active Sessions',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2155,NULL,'Host CPU Usage Per Sec','CentiSeconds Per Second',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2156,NULL,'Cell Physical IO Interconnect Bytes','bytes',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2157,NULL,'Temp Space Used','bytes',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2158,NULL,'Total PGA Allocated','bytes',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2159,NULL,'Total PGA Used by SQL Workareas','bytes',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2160,NULL,'Run Queue Per Sec','Processes',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2161,NULL,'VM in bytes Per Sec','bytes per sec',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(2162,NULL,'VM out bytes Per Sec','bytes per sec',NULL);
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(4000,'BLOCKED_USERS','Blocked User Session Count','Sessions','OBJECT_TYPE_SESSION');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(6000,'ELAPSED_TIME_PER_CALL','Elapsed Time Per User Call','Microseconds Per Call','OBJECT_TYPE_SERVICE');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(6001,'CPU_TIME_PER_CALL','CPU Time Per User Call','Microseconds Per Call','OBJECT_TYPE_SERVICE');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(7000,'AVG_FILE_READ_TIME','Average File Read Time (Files-Long)','CentiSeconds Per Read','OBJECT_TYPE_FILE');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(7001,'AVG_FILE_WRITE_TIME','Average File Write Time (Files-Long)','CentiSeconds Per Write','OBJECT_TYPE_FILE');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(9000,'TABLESPACE_PCT_FULL','Tablespace Space Usage','Tablespace % Full','OBJECT_TYPE_TABLESPACE');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(9001,'TABLESPACE_BYT_FREE','Tablespace Bytes Space Usage','Tablespace KiloBytes','OBJECT_TYPE_TABLESPACE');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(13000,'WCR_AVG_IO_LAT','WRC average IO latency','sec','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(13001,'WCR_PCPU','Percentage of replay threads on CPU','%','OBJECT_TYPE_SYSTEM');
INSERT INTO aca_metrics (METRIC_ID,METRIC_NAME,METRIC_DESCRIPTION,METRIC_UNIT,OBJECT_TYPE)
VALUES(13002,'WCR_PIO','Percentage of replay threads doing IO','%','OBJECT_TYPE_SYSTEM');

-- ACA_REPORTS

INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(1,'USER_TABLES','SELECT table_name,
       status,
       TO_CHAR (pct_free) pct_free,
       TO_CHAR (last_analyzed, ''MM-DD-YYYY HH24:MI'') last_analyzed
  FROM user_tables
 ORDER BY 1','Lists user tables','For test purposes');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(2,'ASM_DISKS','SELECT disk_number,
       group_number,
       mount_status,
       header_status,
       os_mb,
       total_mb,
       free_mb,
       state,
       name,
       path,
       failgroup
  FROM v$asm_disk','List Disks','Page 113');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(3,'ASM_DISK_GROUPS','SELECT group_number,
       name,
       state,
       type,
       sector_size,
       block_size,
       allocation_unit_size,
       total_mb,
       free_mb,
       hot_used_mb,
       cold_used_mb,
       required_mirror_free_mb,
       usable_file_mb,
       offline_disks,
       compatibility,
       database_compatibility,
       voting_files
  FROM v$asm_diskgroup','ASM disk groups','Page 112 & 113');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(4,'ASM_INSTANCE_INFO','SELECT status,
       TO_CHAR(TO_TIMESTAMP(startup_time), ''Mon dd, YYYY HH:MI:SS am tzd''),
       NULL,
       instance_name,
       version,
       host_name,
       CASE
          WHEN SUBSTR (version, 1, 2) = ''12'' THEN
             SYS_CONTEXT (''userenv'', ''oracle_home'')
       ELSE
          NULL
       END
  FROM v$instance','ASM General Instance Info','Page 110');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(5,'ASM_DIAGNOSTICS','SELECT DISTINCT originating_timestamp, message_text
  FROM x$dbgalertext
 WHERE message_text LIKE ''ORA-%''','ASM Diagnostic Summary','Page 110');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(6,'ASM_DISK_GROUP_USAGE','SELECT NAME, TYPE, ROUND(bytes / 1024 / 1024) AS mbytes FROM
(SELECT g.name, f.type, SUM(f.bytes) AS bytes
  FROM v$asm_file f
  JOIN v$asm_diskgroup g USING (group_number)
 GROUP BY g.name, f.type
 UNION ALL
SELECT name, ''Unallocated'', free_mb * 1024 * 1024 AS bytes
  FROM v$asm_diskgroup
 ORDER BY name, TYPE)','ASM Disk Groupe Usage in GB','Page 110');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(7,'ASM_SERVICED_DATABASES','SELECT db_name, name, status
  FROM v$asm_client JOIN v$asm_diskgroup USING (group_number)
 ORDER BY db_name, name','ASM serviced databases','Page 110');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(8,'ASM_CFS','SELECT f.fs_name,
       f.available_time,
       f.state,
       (f.total_size - f.total_free) / f.total_size * 100,
       f.total_size - f.total_free,
       f.total_size,
       v.size_mb,
       v.volume_name,
       g.name
  FROM v$asm_filesystem f
  JOIN v$asm_volume v
    ON (f.fs_name = v.mountpath)
  JOIN v$asm_diskgroup g
 USING (group_number)','Serviced ASM Cluster File Systems','Page 110');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(9,'ASM_OTHER_VOLUMES','SELECT v.volume_name,
       v.volume_device,
       v.usage,
       g.name,
       (v.size_mb / 1000) size_gb,
       (v.size_mb / 1000) allocated_gb,
       v.redundancy
  FROM v$asm_volume v JOIN v$asm_diskgroup g USING (group_number)','ASM other volumes','Page 110');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(10,'ASM_AVAILABLE_DISKS','SELECT path, state , header_status , os_mb
  FROM v$asm_disk
 WHERE group_number = 0
   AND NOT header_status = ''MEMBER''','List all available and un-used disks','Page 113');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(11,'ASM_OPERATIONS','SELECT group_number,
       operation,
       POWER,
       actual,
       sofar,
       est_minutes
  FROM v$asm_operation
 WHERE state = ''RUN''','ASM Running Operations','Page 112 & Page 113');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(14,'ASM_PARAMETERS','SELECT name, value
  FROM v$parameter
 WHERE name LIKE ''%asm%''',NULL,NULL);
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(15,'ASM_FILES','SELECT group_number
  FROM v$asm_file',NULL,NULL);
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(16,'ASM_ALERT_LOG','SELECT *
  FROM (SELECT TO_CHAR(originating_timestamp, ''MM/DD/YYYY HH24:MI:SS.FF'') originating_time,
               message_text
          FROM (SELECT originating_timestamp, message_text
                  FROM x$dbgalertext
                 ORDER BY originating_timestamp DESC)
         WHERE ROWNUM <= #a1#)
ORDER BY 1','Show the ASM Alert Log','Page 116. #a1# is a substitution string that is replaced with P116_ROWS');
INSERT INTO aca_reports (ID,NAME,QUERY,DESCRIPTION,NOTES)
VALUES(17,'ASM_DISK_GROUP_USAGE2','SELECT name,
       type,
       total_mb,
       CASE type
          WHEN ''EXTERN'' THEN total_mb
          WHEN ''NORMAL'' THEN total_mb/2
          WHEN ''HIGH''   THEN total_mb/3
       END AS actual_mb,
       CASE type
          WHEN ''EXTERN'' THEN free_mb
          WHEN ''NORMAL'' THEN free_mb/2
          WHEN ''HIGH''   THEN free_mb/3
       END AS free_mb
  FROM v$asm_diskgroup
 ORDER BY 1','ASM Disk Group size and usage','Page 110');

-- ACA_REPORT_COLUMN_LABELS

INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(1,'Table Name',NULL,10);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(1,'Status',NULL,20);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(1,'PCT Free',NULL,30);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(1,'Last Analyzed',NULL,40);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Disk',NULL,10);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Group Number',NULL,20);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Mount Status',NULL,30);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Header Status',NULL,40);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'OS MB',NULL,50);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Total MB',NULL,60);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Free MB',NULL,70);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'State',NULL,80);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Name',NULL,90);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Path',NULL,95);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(2,'Failure Group',NULL,100);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Edit',NULL,20);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Name',NULL,30);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'State',NULL,40);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Redundancy',NULL,50);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Sector Size',NULL,60);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Block Size',NULL,70);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Allocation Unit Size',NULL,80);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Total MB',NULL,90);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Free MB',NULL,100);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Hot Used MB',NULL,110);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Cold Used MB',NULL,120);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Required Mirror Free MB',NULL,130);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Usable File MB',NULL,140);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Offline Disks',NULL,150);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Compatibility',NULL,160);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Database Compatibility',NULL,170);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(3,'Voting Files',NULL,180);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Current state',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Up since',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Availability',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Instance name',NULL,4);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Version',NULL,5);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Host',NULL,6);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(4,'Oracle Home',NULL,7);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(5,'Alert Time',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(5,'Message',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(6,'Name',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(6,'Type',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(6,'Size',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(7,'DB Name',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(7,'Name',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(7,'Status',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Mount Point',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Availability',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'State',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Used (%)',NULL,4);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Used (GB)',NULL,5);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Size (GB)',NULL,6);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Allocated Space (GB)',NULL,7);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Volume',NULL,8);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(8,'Disk Group',NULL,9);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Volume',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Volume Device',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Usage',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Disk Group',NULL,4);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Size (GB)',NULL,5);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Allocated Space (GB)',NULL,6);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(9,'Redundancy',NULL,7);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(10,'Path',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(10,'State',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(10,'Header Status',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(10,'Size (MB)',NULL,4);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(11,'Group Member',NULL,1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(11,'Operation',NULL,2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(11,'Power',NULL,3);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(11,'Actual',NULL,4);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(11,'So Far',NULL,5);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(11,'Est. Minutes',NULL,6);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(14,'Name','Parameter Name',1);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(14,'Value','Parameter Value',2);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(15,'Group Number',NULL,10);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(16,'Originating Time',NULL,10);
INSERT INTO aca_report_column_labels (REPORT_ID,LABEL,DESCRIPTION,ORDER_SEQUENCE)
VALUES(16,'Text',NULL,20);

   load_aca_jobs;

   END init;

END aca_install_util;
/

CREATE OR REPLACE PACKAGE BODY ACA_RMAN_CONFIG IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   FUNCTION get_config_value(p_name IN v$rman_configuration.name%TYPE,
                             p_value_like IN VARCHAR2 DEFAULT NULL) RETURN v$rman_configuration.value%TYPE IS
      --
      -- Purpose: To get an RMAN configuration value
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   03/25/2015  Creation
      --
      lv_value v$rman_configuration.value%TYPE;
      CURSOR c1 IS
      SELECT value
        FROM v$rman_configuration
       WHERE name = UPPER(p_name)
         AND (VALUE LIKE p_value_like OR p_value_like IS NULL)
         AND ROWNUM = 1;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_value;
      CLOSE c1;
      RETURN lv_value;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_RMAN_CONFIG.GET_CONFIG_VALUE', p_error_text => SQLERRM);
      RAISE;
   END get_config_value;

   PROCEDURE configure_rman(p_backup_type VARCHAR2 DEFAULT NULL,
                            p_parallelism VARCHAR2 DEFAULT '1',
                            p_backup_location VARCHAR2 DEFAULT NULL,
                            p_comp_algorithm VARCHAR2 DEFAULT 'BASIC',
                            p_comp_release VARCHAR2 DEFAULT 'DEFAULT',
                            p_comp_opt VARCHAR2 DEFAULT 'YES',
                            p_maxpiecesize NUMBER DEFAULT NULL,
                            p_autobackup IN VARCHAR2,
                            p_autobackup_disk_loc IN VARCHAR2,
                            p_optimization IN VARCHAR2,
                            p_exclude_tablespaces IN VARCHAR2,
                            p_retention_policy IN VARCHAR2,
                            p_rp_days IN VARCHAR2,
                            p_rp_backups IN VARCHAR2,
                            p_archlog_del_policy IN VARCHAR2,
                            p_archlog_backups IN VARCHAR2,
                            p_tape_backup_type VARCHAR2 DEFAULT NULL,
                            p_tape_parallelism VARCHAR2 DEFAULT '1',
                            p_tape_parameters VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To configure RMAN
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   03/25/2015  Creation
      -- GL Skillbuilders   05/04/2015  Added Tape (Media Manager) configuration
      -- GL Skillbuilders   06/09/2015  Added Media Manager check.
      --
      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 1;
      tablespace_array APEX_APPLICATION_GLOBAL.VC_ARR2 := APEX_UTIL.STRING_TO_TABLE(p_exclude_tablespaces);
      lv_backup_location VARCHAR2(1000) := p_backup_location;
      lv_autobackup_disk_loc VARCHAR2(1000) := p_autobackup_disk_loc;
      lv_slash VARCHAR2(1) := '/';
      lv_autobackup VARCHAR2(10);
      lv_optimization VARCHAR2(10);
      lv_comp_opt VARCHAR2(10);
      lv_command_code VARCHAR2(32000);
      lv_template_name VARCHAR2(30) := 'RMAN_CONFIG_TEMPLATE';
      crlf VARCHAR2(2) := CHR(10);

   BEGIN

      -- Set backslash and line terminator
      IF aca_util.get_config_value('OS_TYPE') = 'WINDOWS' THEN
         lv_slash := '\';
         crlf := CHR(13)||CHR(10);
      END IF;

      IF SUBSTR(lv_backup_location, -1, 1) != lv_slash THEN
         lv_backup_location := lv_backup_location||lv_slash;
      END IF;

      IF SUBSTR(lv_autobackup_disk_loc, -1, 1) != lv_slash THEN
         lv_autobackup_disk_loc := lv_autobackup_disk_loc||lv_slash;
      END IF;

      -- Build RMAN command code
      lv_command_code := '# Configuring RMAN'||';'||crlf;

      -- Backup Type
      lv_command_code := lv_command_code||'CONFIGURE DEVICE TYPE DISK BACKUP TYPE TO '||p_backup_type;

      -- Parallelism
      IF p_parallelism IS NOT NULL THEN
         lv_command_code := lv_command_code||' PARALLELISM '||p_parallelism||';'||crlf;
      ELSE
         lv_command_code := lv_command_code||';'||crlf;
      END IF;

      -- Media Manager
      IF aca_util.get_config_value(p_name => 'MEDIA_MANAGER') = 'YES' THEN

         -- Tape Backup Type
         lv_command_code := lv_command_code||'CONFIGURE DEVICE TYPE SBT_TAPE BACKUP TYPE TO '||p_tape_backup_type;

         -- Tape Parallelism
         IF p_tape_parallelism IS NOT NULL THEN
            lv_command_code := lv_command_code||' PARALLELISM '||p_tape_parallelism||';'||crlf;
         ELSE
            lv_command_code := lv_command_code||';'||crlf;
         END IF;

         -- Tape Parameters
         IF p_tape_parameters IS NOT NULL THEN
            lv_command_code := lv_command_code||'CONFIGURE CHANNEL DEVICE TYPE SBT_TAPE PARMS '''||p_tape_parameters||''';'||crlf;
         ELSE
            lv_command_code := lv_command_code||'CONFIGURE CHANNEL DEVICE TYPE SBT_TAPE CLEAR;'||crlf;
         END IF;

      END IF;

      -- Backup Location and Max Piece Size
      IF p_backup_location IS NULL AND p_maxpiecesize IS NULL THEN
         lv_command_code := lv_command_code||'CONFIGURE CHANNEL DEVICE TYPE DISK CLEAR;'||crlf;
      ELSIF p_backup_location IS NULL AND p_maxpiecesize IS NOT NULL THEN
         lv_command_code := lv_command_code||'CONFIGURE CHANNEL DEVICE TYPE DISK MAXPIECESIZE '||p_maxpiecesize||'G;'||crlf;
      ELSIF p_backup_location IS NOT NULL AND p_maxpiecesize IS NULL THEN
         lv_command_code := lv_command_code||'CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT '''||lv_backup_location||'%U'';'||crlf;
      ELSE
         lv_command_code := lv_command_code||'CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT '''||lv_backup_location||'%U'' MAXPIECESIZE '||p_maxpiecesize||'G;'||crlf;
      END IF;

      -- Compression
      IF p_comp_opt = 'YES' THEN
         lv_comp_opt   := 'TRUE';
      ELSE
         lv_comp_opt   := 'FALSE';
      END IF;

      lv_command_code := lv_command_code||'CONFIGURE COMPRESSION ALGORITHM '''||p_comp_algorithm||''' AS OF RELEASE '''||p_comp_release||''' OPTIMIZE FOR LOAD '||lv_comp_opt||';';

      -- Control File Autobackup
      IF p_autobackup = 'YES' THEN
         lv_autobackup := 'ON';
      ELSE
         lv_autobackup := 'OFF';
      END IF;

      lv_command_code := lv_command_code||'CONFIGURE CONTROLFILE AUTOBACKUP '||lv_autobackup||';'||crlf;

      IF p_autobackup_disk_loc IS NULL THEN
         lv_command_code := lv_command_code||'CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO ''%F'';'||crlf;
      ELSE
         lv_command_code := lv_command_code||'CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '''||lv_autobackup_disk_loc||'%F'';'||crlf;
      END IF;

      -- Backup Optimization
      IF p_optimization = 'YES' THEN
         lv_optimization := 'ON';
      ELSE
         lv_optimization := 'OFF';
      END IF;
      lv_command_code := lv_command_code||'CONFIGURE BACKUP OPTIMIZATION '||lv_optimization||';'||crlf;

      -- Exclude Tablespaces
      FOR r IN (SELECT name
                  FROM v$tablespace A, dba_tablespaces B
                 WHERE A.name = B.tablespace_name
                   AND A.included_in_database_backup = 'NO'
                   AND B.contents != 'TEMPORARY'
                   AND INSTR(':'||p_exclude_tablespaces||':', ':'||B.tablespace_name||':') = 0) LOOP
         lv_command_code := lv_command_code||'CONFIGURE EXCLUDE FOR TABLESPACE '''||r.name||''' CLEAR ;'||crlf;
      END LOOP;

      FOR i IN 1 .. tablespace_array.COUNT LOOP
         lv_command_code := lv_command_code||'CONFIGURE EXCLUDE FOR TABLESPACE '''||tablespace_array(i)||''';'||crlf;
      END LOOP;

      -- Retension Policy
      CASE p_retention_policy
         WHEN 'N' THEN
            lv_command_code := lv_command_code||'CONFIGURE RETENTION POLICY TO NONE;'||crlf;
         WHEN 'R' THEN
            lv_command_code := lv_command_code||'CONFIGURE RETENTION POLICY TO REDUNDANCY '||p_rp_backups||';'||crlf;
         WHEN 'W' THEN
            lv_command_code := lv_command_code||'CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF '||p_rp_days||' DAYS;'||crlf;
         ELSE
            NULL;
      END CASE;

      -- Archive Log Deletion Policy
      CASE p_archlog_del_policy
         WHEN 'N' THEN
            lv_command_code := lv_command_code||'CONFIGURE ARCHIVELOG DELETION POLICY TO NONE;'||crlf;
         WHEN 'D' THEN
            lv_command_code := lv_command_code||'CONFIGURE ARCHIVELOG DELETION POLICY TO BACKED UP '||p_archlog_backups||' TIMES TO DISK ;'||crlf;
         ELSE
            NULL;
      END CASE;

      -- Make string substitutions
      subs(idx).name := 'NAME'; subs(idx).value := 'RMAN_CONFIG'; idx := idx + 1;
      -- Configure RMAN

      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         lv_template_name := 'WIN_RMAN_CONFIG_TEMPLATE';
      END IF;

      aca_util.prepare_job(p_template_name => lv_template_name,
                           p_job_name => 'RMAN_CONFIG',
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => 'Configuring RMAN',
                           p_executable_code => NULL,
                           p_command_code => lv_command_code,
                           p_job_execution => 'IMMEDIATE',
                           p_repeat_interval => NULL,
                           p_start_date => NULL,
                           p_end_date => NULL,
                           p_notifications => 'NO',
                           p_log_run => 'YES');
      COMMIT;
      DBMS_LOCK.SLEEP(3);

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_RMAN_CONFIG.CONFIGURE_RMAN', p_error_text => SQLERRM);
      RAISE;
   END configure_rman;

END aca_rman_config;
/


CREATE OR REPLACE PACKAGE BODY ACA_SCHEDULER_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   PROCEDURE schedule_job(p_name IN VARCHAR2) IS
      --
      -- Purpose: To schedule a user defined job
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ----------------------------------------------------
      -- GL Skillbuilders   09/08/2016  Creation
      -- GL Skillbuilders   01/18/2017  Added column locked
      --
      CURSOR c1 IS
      SELECT program_type, procedure_parameters
        FROM aca_scheduler_jobs
       WHERE NAME = p_name;
      r1 c1%ROWTYPE;
      lv_id NUMBER;
      parameters_array APEX_APPLICATION_GLOBAL.VC_ARR2;
   BEGIN

      -- Drop job if it already exists
      aca_util.drop_scheduled_job(p_job_name => p_name);
      aca_util.drop_aca_job(p_job_name => p_name);

      -- Copy job to aca_jobs
      SELECT aca_job_pk_seq.NEXTVAL INTO lv_id FROM DUAL;
      INSERT INTO aca_jobs
            (id, job_id, name, description, program_type,
             procedure_name, plsql_code, credential_name,
             executable_name, executable_filename, executable_code,
             command_filename, command_code, job_execution,
             repeat_interval, start_date, end_date, enabled, notes,
             order_sequence, created_by, creation_date, modified_by,
             modification_date, permanent, completion_recipients,
             success_recipients, failure_recipients, log_filename,
             log_category, log_run, notifications, locked)
      SELECT lv_id, NULL job_id, name, description, program_type,
             procedure_name, plsql_code, NULL credential_name, NULL executable_name,
             DECODE(program_type, 'EXECUTABLE', '#OS_SCRIPTS_DIRECTORY#/'||name||'.sh', NULL) executable_filename,
             executable_code,  NULL command_filename, NULL command_code,
             job_execution, repeat_interval, start_date, end_date, enabled, notes,
             order_sequence, created_by, creation_date, modified_by, modification_date,
             'NO' permanent, completion_recipients,success_recipients, failure_recipients,
             DECODE(program_type, 'EXECUTABLE', '#OS_LOG_DIRECTORY#/'||name||'.log', NULL) log_filename,
             DECODE(program_type, 'PLSQL_BLOCK', 'PL/SQL', 'STORED_PROCEDURE', 'PROCEDURE', 'EXECUTABLE') log_category,
              'YES' log_run, 'YES' notifications, 'YES' locked
        FROM aca_scheduler_jobs
       WHERE NAME = p_name;

       OPEN c1;
          FETCH c1 INTO r1;
       CLOSE c1;

      -- Add the job arguments (procedure parameters)
      IF r1.program_type = 'STORED_PROCEDURE' AND r1.procedure_parameters IS NOT NULL THEN
          parameters_array := APEX_UTIL.STRING_TO_TABLE(r1.procedure_parameters, ',');
          FOR i IN 1..parameters_array.COUNT LOOP
             INSERT INTO aca_job_arguments(job_id, name, value, order_sequence)
             VALUES (lv_id, 'P'||TO_CHAR(i), parameters_array(i), i);
          END LOOP;
       END IF;

       -- Schedule the job
       aca_util.schedule_job(lv_id);

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_SCHEDULER_UTIL.SCHEDULE_JOB', p_error_text => SQLERRM);
      RAISE;
   END schedule_job;

END aca_scheduler_util;
/


CREATE OR REPLACE PACKAGE BODY ACA_SQL_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   FUNCTION inc(p_num IN OUT NUMBER) RETURN NUMBER IS
   BEGIN
      p_num   := p_num + 1;
      RETURN p_num;
   END inc;

   PROCEDURE run_sql(p_id IN NUMBER,
                     p_template_name IN VARCHAR2 DEFAULT 'SQL_TEMPLATE') IS
      --
      -- Purpose: To run a SQL Script
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   11/20/2014  Creation
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_sql_repository
       WHERE id = p_id;
      r1 c1%ROWTYPE;

      lv_username_password VARCHAR2(200);

      subs ACA_UTIL.SUB_TAB;
      idx PLS_INTEGER := 0;

   BEGIN

      -- Fetch SQL script
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      -- Get DB user and password
      lv_username_password := aca_util.get_config_value(p_name => 'DB_USER')||'/'||
                              aca_util.get_config_value(p_name => 'DB_PASSWORD');

      -- Add substitution strings
      subs(inc(idx)).name := 'NAME';              subs(idx).value := r1.name;
      subs(inc(idx)).name := 'USERNAME_PASSWORD'; subs(idx).value := lv_username_password;

      -- Prepare and run script
      aca_util.prepare_job(p_template_name => p_template_name,
                           p_job_name => r1.name,
                           p_run_job => 'YES',
                           p_substitutions => subs,
                           p_description => r1.description,
                           p_executable_code => NULL,
                           p_command_code => r1.clob_content,
                           p_job_execution => 'IMMEDIATE',
                           p_repeat_interval => NULL,
                           p_start_date => NULL,
                           p_end_date => NULL,
                           p_notifications => 'NO',
                           p_log_run => 'YES');

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_SQL_UTIL.RUN_SQL', p_error_text => SQLERRM);
      RAISE;
   END run_sql;

 END aca_sql_util ;
/


CREATE OR REPLACE PACKAGE BODY ACA_UTIL IS
   --
   -- Copyright 2015 2016 2017 2019 SkillBuilders Inc.
   --
   -- Purpose: This package provides utilities for APEX application ODM
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/31/2014  Creation
   -- GL Skillbuilders   01/12/2017  Removed functions SBI and SBI2
   --

   FUNCTION db_is_cdb RETURN BOOLEAN IS
      --
      -- Purpose: To test if the database is a CDB
      --
      -- MODIFICATION HISTORY
      -- Person            Date        Comments
      -- ----------------  ----------  ------------------------------------------
      -- GL Skillbuilders  02/22/2019  Creation
      --
      CURSOR c1 IS
      SELECT cdb
        FROM v$database;
      lv_cdb VARCHAR2(3);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_cdb;
      CLOSE c1;
      IF lv_cdb = 'YES' THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DB_IS_CDB', p_error_text => SQLERRM);
      RAISE;
   END db_is_cdb;

   FUNCTION db_is_cdb2 RETURN VARCHAR2 IS
      --
      -- Purpose: To test if the database is a CDB for use in SQL
      --
      -- MODIFICATION HISTORY
      -- Person            Date        Comments
      -- ----------------  ----------  ------------------------------------------
      -- GL Skillbuilders  02/27/2019  Creation
      --
      CURSOR c1 IS
      SELECT cdb
        FROM v$database;
      lv_cdb VARCHAR2(3);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_cdb;
      CLOSE c1;
      IF lv_cdb = 'YES' THEN
         RETURN 'YES';
      ELSE
         RETURN 'NO';
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DB_IS_CDB2', p_error_text => SQLERRM);
      RAISE;
   END db_is_cdb2;

   PROCEDURE write_clob_to_file(destination_file IN VARCHAR2,
                                file_contents IN CLOB) IS
      --
      -- Purpose: To write a clob to an OS file.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/12/2016  Creation
      -- GL Skillbuilders   02/12/2016  Changed to replace UTL_FILE with DBMS_ADVISOR
      -- GL Skillbuilders   02/22/2019  Corrected call to DBMS_ADVISOR.CREATE_FILE to
      --                                use lv_filename
      --
      lv_directory VARCHAR2(30) := 'SBA$';
      lv_directory_seq NUMBER;
      lv_path VARCHAR2(1000);
      lv_slash VARCHAR2(2) := '/';
      lv_filename VARCHAR2(100);
      lv_reverse_filename VARCHAR2(100);
      lv_sql_statement VARCHAR2(1000);
      lv_bp VARCHAR2(30);

   BEGIN

      IF aca_util.get_os_type = 'WINDOWS' THEN
         lv_slash := '\';
      END IF;

      SELECT REVERSE(destination_file) INTO lv_reverse_filename FROM DUAL;
      lv_filename := SUBSTR(destination_file, - INSTR(lv_reverse_filename, lv_slash) + 1);
      lv_path := SUBSTR(destination_file, 1, LENGTH(destination_file) - LENGTH(lv_filename));

      SELECT aca_directory_seq.NEXTVAL INTO lv_directory_seq FROM DUAL;
      lv_directory := lv_directory||TO_CHAR(lv_directory_seq);

      lv_sql_statement := 'CREATE DIRECTORY '||lv_directory||' AS '''||lv_path||'''';
      EXECUTE IMMEDIATE lv_sql_statement;

      DBMS_ADVISOR.CREATE_FILE(BUFFER => file_contents,
                               location => lv_directory,
                               filename => lv_filename);

      lv_sql_statement := 'DROP DIRECTORY '||lv_directory;
      EXECUTE IMMEDIATE lv_sql_statement;

   EXCEPTION
      WHEN OTHERS THEN
         lv_sql_statement := 'DROP DIRECTORY '||lv_directory;
         EXECUTE IMMEDIATE lv_sql_statement;
         aca_error_util.log_error(p_program_name => 'ACA_UTIL.WRITE_CLOB_TO_FILE', p_error_text => SQLERRM);
         RAISE;
   END write_clob_to_file;

   PROCEDURE write_blob_to_file(destination_file IN VARCHAR2,
                                file_contents IN BLOB) IS
      --
      -- Purpose: To write a blob to an OS file.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/12/2016  Creation
      --
      lv_directory VARCHAR2(30) := 'SBA$';
      lv_directory_seq NUMBER;
      lv_path VARCHAR2(1000);
      lv_slash VARCHAR2(2) := '/';
      lv_filename VARCHAR2(100);
      lv_reverse_filename VARCHAR2(100);
      lv_sql_statement VARCHAR2(1000);
      lv_file UTL_FILE.FILE_TYPE;
      lv_buffer RAW(32767);
      lv_amount BINARY_INTEGER := 32767;
      lv_pos INTEGER := 1;
      lv_blob_length INTEGER;

   BEGIN

      IF aca_util.get_os_type = 'WINDOWS' THEN
         lv_slash := '\';
      END IF;

      SELECT REVERSE(destination_file) INTO lv_reverse_filename FROM DUAL;
      lv_filename := SUBSTR(destination_file, - INSTR(lv_reverse_filename, lv_slash) + 1);
      lv_path := SUBSTR(destination_file, 1, LENGTH(destination_file) - LENGTH(lv_filename));

      SELECT aca_directory_seq.NEXTVAL INTO lv_directory_seq FROM DUAL;
      lv_directory := lv_directory||TO_CHAR(lv_directory_seq);

      lv_sql_statement := 'CREATE DIRECTORY '||lv_directory||' AS '''||lv_path||'''';
      EXECUTE IMMEDIATE lv_sql_statement;

      lv_blob_length := DBMS_LOB.GETLENGTH(file_contents);

      lv_file := UTL_FILE.FOPEN(lv_directory, lv_filename, 'w', 32767);

      WHILE lv_pos < lv_blob_length LOOP
         DBMS_LOB.READ(file_contents, lv_amount, lv_pos, lv_buffer);
         UTL_FILE.PUT_RAW(lv_file, lv_buffer, TRUE);
         lv_pos := lv_pos + lv_amount;
      END LOOP;

      IF UTL_FILE.IS_OPEN(lv_file) THEN
         UTL_FILE.FCLOSE(lv_file);
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
         IF UTL_FILE.IS_OPEN(lv_file) THEN
            UTL_FILE.FCLOSE(lv_file);
         END IF;
         lv_sql_statement := 'DROP DIRECTORY '||lv_directory;
         EXECUTE IMMEDIATE lv_sql_statement;
         aca_error_util.log_error(p_program_name => 'ACA_UTIL.WRITE_BLOB_TO_FILE', p_error_text => SQLERRM);
         RAISE;
   END write_blob_to_file;

   PROCEDURE put_file(destination_file IN VARCHAR2,
                      destination_host IN VARCHAR2 DEFAULT NULL,
                      credential_name IN VARCHAR2 DEFAULT NULL,
                      file_contents IN CLOB,
                      destination_permissions IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To write a clob to an OS file.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/12/2016  Creation
      -- GL Skillbuilders   02/22/2019  Added AND aca_util.get_db_version < 18 THEN
      --
   BEGIN
      IF aca_util.get_db_edition = 'EXPRESS' AND aca_util.get_db_version < 18 THEN
         aca_util.write_clob_to_file(destination_file => destination_file,
                                     file_contents => file_contents);
      ELSE
         DBMS_SCHEDULER.PUT_FILE(destination_file => destination_file,
                                 destination_host => destination_host,
                                 credential_name => credential_name,
                                 file_contents => file_contents,
                                 destination_permissions => destination_permissions);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.PUT_FILE', p_error_text => SQLERRM);
      RAISE;
   END put_file;

   PROCEDURE put_file(destination_file IN VARCHAR2,
                      destination_host IN VARCHAR2 DEFAULT NULL,
                      credential_name IN VARCHAR2 DEFAULT NULL,
                      file_contents IN BLOB,
                      destination_permissions IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To write a blob to an OS file.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/12/2016  Creation
      --
   BEGIN
      IF aca_util.get_db_edition = 'EXPRESS' AND aca_util.get_db_version < 18 THEN
         aca_util.write_blob_to_file(destination_file => destination_file,
                                     file_contents => file_contents);
      ELSE
         DBMS_SCHEDULER.PUT_FILE(destination_file => destination_file,
                                 destination_host => destination_host,
                                 credential_name => credential_name,
                                 file_contents => file_contents,
                                 destination_permissions => destination_permissions);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.PUT_FILE', p_error_text => SQLERRM);
      RAISE;
   END put_file;

   FUNCTION load_blob_from_file(p_filename IN VARCHAR2) RETURN BLOB IS
      --
      -- Purpose: To return a files contents given it's path/name.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/11/2016  Creation
      --
      lv_blob BLOB;
      lv_bfile BFILE;
      lv_directory VARCHAR2(30) := 'SBA$';
      lv_directory_seq NUMBER;
      lv_path VARCHAR2(1000);
      lv_slash VARCHAR2(2) := '/';
      lv_filename VARCHAR2(100);
      lv_reverse_filename VARCHAR2(100);
      lv_sql_statement VARCHAR2(1000);
      lv_dest_offset INTEGER := 1;
      lv_src_offset INTEGER := 1;
      lv_amount INTEGER := DBMS_LOB.LOBMAXSIZE;
   BEGIN

      IF aca_util.get_os_type = 'WINDOWS' THEN
         lv_slash := '\';
      END IF;

      SELECT REVERSE(p_filename) INTO lv_reverse_filename FROM DUAL;
      lv_filename := SUBSTR(p_filename, - INSTR(lv_reverse_filename, lv_slash) + 1);
      lv_path := SUBSTR(p_filename, 1, LENGTH(p_filename) - LENGTH(lv_filename));

      SELECT aca_directory_seq.NEXTVAL INTO lv_directory_seq FROM DUAL;
      lv_directory := lv_directory||TO_CHAR(lv_directory_seq);

      lv_sql_statement := 'CREATE DIRECTORY '||lv_directory||' AS '''||lv_path||'''';
      EXECUTE IMMEDIATE lv_sql_statement;

      lv_bfile := BFILENAME(lv_directory, lv_filename);
      DBMS_LOB.CREATETEMPORARY(lob_loc => lv_blob, cache => FALSE);
      DBMS_LOB.FILEOPEN(lv_bfile, DBMS_LOB.FILE_READONLY);
      DBMS_LOB.LOADBLOBFROMFILE (dest_lob => lv_blob,
                                 src_bfile => lv_bfile,
                                 amount => lv_amount,
                                 dest_offset => lv_dest_offset,
                                 src_offset => lv_src_offset);
      DBMS_LOB.FILECLOSE(lv_bfile);

      lv_sql_statement := 'DROP DIRECTORY '||lv_directory;
      EXECUTE IMMEDIATE lv_sql_statement;
      RETURN lv_blob;
   EXCEPTION
      WHEN OTHERS THEN
      lv_sql_statement := 'DROP DIRECTORY '||lv_directory;
      EXECUTE IMMEDIATE lv_sql_statement;
      RAISE;
   END load_blob_from_file;

   FUNCTION get_db_product RETURN VARCHAR2 IS
      --
      -- Purpose: To get the DB Edition and Version
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/11/2016  Creation
      --
      lv_product VARCHAR2(100);
   BEGIN
      SELECT product INTO lv_product
        FROM product_component_version
       WHERE UPPER(product) LIKE '%DATABASE%';
      RETURN lv_product;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DB_PRODUCT', p_error_text => SQLERRM);
      RAISE;
   END get_db_product;

   FUNCTION get_db_edition RETURN VARCHAR2 IS
      --
      -- Purpose: To get the DB Edition
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/11/2016  Creation
      --
      lv_edition VARCHAR2(100);
   BEGIN

      SELECT UPPER(product) INTO lv_edition
        FROM product_component_version
       WHERE UPPER(product) LIKE '%DATABASE%';
       IF lv_edition LIKE '%ENTERPRISE%' THEN
          RETURN 'ENTERPRISE';
       ELSIF lv_edition LIKE '%EXPRESS%' THEN
          RETURN 'EXPRESS';
       ELSE
          RETURN 'STANDARD';
       END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DB_EDITION', p_error_text => SQLERRM);
      RAISE;
   END get_db_edition;

   FUNCTION get_db_version RETURN NUMBER IS
      --
      -- Purpose: To get the DB version
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/30/2016  Creation
      --
      lv_version VARCHAR2(30);
   BEGIN
      SELECT TO_CHAR(DBMS_DB_VERSION.VERSION) INTO lv_version FROM dual;
      RETURN TO_NUMBER(SUBSTR(lv_version, 1, 2));
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DB_VERSION', p_error_text => SQLERRM);
      RAISE;
   END get_db_version;

   FUNCTION blob2clob (p_blob IN BLOB) RETURN CLOB IS
      --
      -- Purpose: To convert a BLOB to a CLOB
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      lv_clob           CLOB;
      lv_dest_offsset   PLS_INTEGER := 1;
      lv_src_offsset    PLS_INTEGER := 1;
      lv_lang_context   PLS_INTEGER := DBMS_LOB.DEFAULT_LANG_CTX;
      lv_warning        PLS_INTEGER;
   BEGIN
      DBMS_LOB.CREATETEMPORARY(lob_loc => lv_clob, cache => FALSE);
      DBMS_LOB.CONVERTTOCLOB(dest_lob       => lv_clob,
                             src_blob       => p_blob,
                             amount         => DBMS_LOB.LOBMAXSIZE,
                             dest_offset    => lv_dest_offsset,
                             src_offset     => lv_src_offsset,
                             blob_csid      => DBMS_LOB.DEFAULT_CSID,
                             lang_context   => lv_lang_context,
                             warning        => lv_warning);
      RETURN lv_clob;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.BLOB2CLOB', p_error_text => SQLERRM);
      RAISE;
   END blob2clob;

   FUNCTION clob2blob (p_clob IN CLOB) RETURN BLOB IS
      --
      -- Purpose: To convert a CLOB to a BLOB
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   11/20/2014  Creation
      --
      lv_blob           BLOB;
      lv_dest_offsset   PLS_INTEGER := 1;
      lv_src_offsset    PLS_INTEGER := 1;
      lv_lang_context   PLS_INTEGER := DBMS_LOB.DEFAULT_LANG_CTX;
      lv_warning        PLS_INTEGER;
   BEGIN
      DBMS_LOB.CREATETEMPORARY(lob_loc => lv_blob, cache => FALSE);
      DBMS_LOB.CONVERTTOBLOB(dest_lob       => lv_blob,
                             src_clob       => p_clob,
                             amount         => DBMS_LOB.LOBMAXSIZE,
                             dest_offset    => lv_dest_offsset,
                             src_offset     => lv_src_offsset,
                             blob_csid      => DBMS_LOB.DEFAULT_CSID,
                             lang_context   => lv_lang_context,
                             warning        => lv_warning);
      RETURN lv_blob;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.CLOB2BLOB', p_error_text => SQLERRM);
      RAISE;
   END clob2blob;

   PROCEDURE print_clob(p_clob IN CLOB, p_amount IN NUMBER DEFAULT NULL) IS
      --
      -- Purpose: To print a CLOB
      --    Note: Buffer size changes may be needed for DBMS_OUTPUT.PUT_LINE
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      lv_amount NUMBER DEFAULT 8191;
      lv_offset NUMBER DEFAULT 1;
      lv_length NUMBER DEFAULT 0;
      lv_string VARCHAR2(8191);
   BEGIN
      lv_length := DBMS_LOB.GETLENGTH(p_clob);
      IF p_amount IS NOT NULL AND lv_length > p_amount THEN
         lv_offset := lv_length - p_amount;
      END IF;
      IF lv_length > 0 THEN
         WHILE (lv_offset < lv_length) LOOP
            lv_string := DBMS_LOB.SUBSTR(p_clob, lv_amount, lv_offset);
            IF V('APP_SESSION') IS NOT NULL THEN
               HTP.PRN(REPLACE(lv_string, CHR(10), '
'));
            ELSE
               DBMS_OUTPUT.PUT_LINE(lv_string);
            END IF;
            lv_offset := lv_offset + lv_amount;
         END LOOP;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.PRINT_CLOB', p_error_text => SQLERRM);
      RAISE;
   END print_clob;

   PROCEDURE put_file2(p_id IN NUMBER,
                       p_credential_name IN VARCHAR2,
                       p_os_filename IN VARCHAR2) IS
      --
      -- Purpose: To write a CLOB from the file repository to the OS file system
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   01/15/2016  Added code for UNIX and WINDOWS end of line.
      --
      CURSOR c1 IS
      SELECT *
        FROM aca_file_repository
       WHERE id = p_id;
       r1 c1%ROWTYPE;
       lv_os_type VARCHAR2(30) := aca_util.get_config_value(p_name => 'OS_TYPE');
   BEGIN
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;
      IF r1.mimetype = 'text/plain' THEN

         -- Remove CTRL-M if UNIX. Add CTRL-M if WINDOWS
         IF lv_os_type = 'UNIX' THEN
            r1.clob_content := REPLACE(r1.clob_content, CHR(13)||CHR(10), CHR(10));
         ELSIF lv_os_type = 'WINDOWS' THEN
            r1.clob_content := REPLACE(r1.clob_content, CHR(13)||CHR(10), CHR(10));
            r1.clob_content := REPLACE(r1.clob_content, CHR(10), CHR(13)||CHR(10));
         END IF;

         aca_util.put_file(destination_file => p_os_filename,
                           destination_host => NULL,
                           credential_name => p_credential_name,
                           file_contents => r1.clob_content,
                           destination_permissions => NULL);
      ELSE
         aca_util.put_file(destination_file => p_os_filename,
                           destination_host => NULL,
                           credential_name => p_credential_name,
                           file_contents => r1.blob_content,
                           destination_permissions => NULL);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.PUT_FILE', p_error_text => SQLERRM);
      RAISE;
   END put_file2;

   PROCEDURE get_file(p_credential_name IN VARCHAR2,
                      p_os_filename IN VARCHAR2 DEFAULT NULL,
                      p_amount IN NUMBER DEFAULT NULL) IS
      --
      -- Purpose: To read and print an OS file
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  -------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   01/18/2016  Changed exception to return file not found.
      -- GL Skillbuilders   02/11/2016  Added code for EXPRESS edition.
      --
      lv_blob BLOB;
   BEGIN
      DBMS_LOB.CREATETEMPORARY(lv_blob, FALSE);
      IF aca_util.get_db_edition = 'EXPRESS' AND aca_util.get_db_version < 18 THEN
         lv_blob := load_blob_from_file(p_os_filename);
      ELSE
         DBMS_SCHEDULER.GET_FILE(source_file     => p_os_filename,
                                 credential_name => p_credential_name,
                                 file_contents   => lv_blob,
                                 source_host     => NULL);
      END IF;
      print_clob(p_clob => blob2clob(lv_blob),
                 p_amount => p_amount);
   EXCEPTION
      WHEN OTHERS THEN
      print_clob(p_clob => 'File not found.',
                 p_amount => p_amount);
   END get_file;

   FUNCTION get_config_value(p_name IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To get the value of a configuration parameter given it's name
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   10/22/2014  Creation
      --
      CURSOR c1 IS
      SELECT value
        FROM aca_configuration
       WHERE NAME = p_name;
      lv_value aca_configuration.value%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_value;
      CLOSE c1;
      RETURN lv_value;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_CONFIG_VALUE', p_error_text => SQLERRM);
      RAISE;
   END get_config_value;

   PROCEDURE set_config_value(p_name IN VARCHAR2,
                              p_value IN VARCHAR2) IS
      --
      -- Purpose: To set the value of a configuration parameter.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   06/26/2015  Creation
      --
   BEGIN
      UPDATE aca_configuration
         SET value = p_value
       WHERE NAME = p_name;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.SET_CONFIG_VALUE', p_error_text => SQLERRM);
      RAISE;
   END set_config_value;

   FUNCTION get_directory_path(p_name IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To get the path of an Oracle directory given it's name
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ---------------------------------------------
      -- GL Skillbuilders   11/07/2014  Creation
      -- GL Skillbuilders   11/10/2015  Replaced aca_directories with dba_directories
      --
      CURSOR c1 IS
      SELECT directory_path
        FROM dba_directories
       WHERE directory_name = p_name;
      lv_path VARCHAR2(1000);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_path;
      CLOSE c1;
      RETURN lv_path;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DIRECTORY_PATH', p_error_text => SQLERRM);
      RAISE;
   END get_directory_path;

   FUNCTION get_job_id(p_name IN VARCHAR2) RETURN NUMBER IS
      --
      -- Purpose: To get the id of a job given it's name
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   06/26/2015  Creation
      --
      CURSOR c1 IS
      SELECT id
        FROM aca_jobs
       WHERE NAME = p_name;
      lv_id aca_jobs.id%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_id;
      CLOSE c1;
      RETURN lv_id;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_JOB_ID', p_error_text => SQLERRM);
      RAISE;
   END get_job_id;

   FUNCTION job_exists(p_job_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a scheduler job exists
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      CURSOR c1 IS
      SELECT 1
        FROM user_scheduler_jobs
       WHERE job_name = p_job_name;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.JOB_EXISTS', p_error_text => SQLERRM);
      RAISE;
   END job_exists;

   PROCEDURE drop_job(p_job_name IN VARCHAR2) IS
      --
      -- Purpose: To drop a scheduler job
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
   BEGIN
      IF job_exists(p_job_name => p_job_name) THEN
         DBMS_SCHEDULER.DROP_JOB(job_name => p_job_name, FORCE => TRUE);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DROP_JOB', p_error_text => SQLERRM);
      RAISE;
   END drop_job;

   FUNCTION program_exists(p_program_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a scheduler program exists
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      CURSOR c1 IS
      SELECT 1
        FROM user_scheduler_programs
       WHERE program_name = p_program_name;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.PROGRAM_EXISTS', p_error_text => SQLERRM);
      RAISE;
   END program_exists;

   PROCEDURE drop_program(p_program_name IN VARCHAR2) IS
      --
      -- Purpose: To drop a scheduler program
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
   BEGIN
      IF program_exists(p_program_name => p_program_name) THEN
         DBMS_SCHEDULER.DROP_PROGRAM(program_name => p_program_name);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DROP_PROGRAM', p_error_text => SQLERRM);
      RAISE;
   END drop_program;

   FUNCTION schedule_exists(p_schedule_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a scheduler schedule exists
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      CURSOR c1 IS
      SELECT 1
        FROM user_scheduler_schedules
       WHERE schedule_name = p_schedule_name;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.SCHEDULE_EXISTS', p_error_text => SQLERRM);
      RAISE;
   END schedule_exists;

   PROCEDURE drop_schedule(p_schedule_name IN VARCHAR2) IS
      --
      -- Purpose: To drop a scheduler schedule
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
   BEGIN
      IF schedule_exists(p_schedule_name => p_schedule_name) THEN
         DBMS_SCHEDULER.DROP_SCHEDULE(schedule_name => p_schedule_name);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DROP_SCHEDULE', p_error_text => SQLERRM);
      RAISE;
   END drop_schedule;

   FUNCTION credential_exists(p_credential_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a credential exists
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      CURSOR c1 IS
      SELECT 1
        FROM user_scheduler_credentials
       WHERE credential_name = p_credential_name;
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.CREDENTIAL_EXISTS', p_error_text => SQLERRM);
      RAISE;
   END credential_exists;

   PROCEDURE drop_credential(p_credential_name IN VARCHAR2) IS
      --
      -- Purpose: To drop a credential
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
   BEGIN
      IF credential_exists(p_credential_name => p_credential_name) THEN
         DBMS_SCHEDULER.DROP_CREDENTIAL(credential_name => p_credential_name);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DROP_CREDENTIAL', p_error_text => SQLERRM);
      RAISE;
   END drop_credential;

   PROCEDURE create_credential(p_credential_name IN VARCHAR2,
                               p_username IN VARCHAR2,
                               p_password IN VARCHAR2) IS
      --
      -- Purpose: To create or replace a credential
      --    Note: GRANT CREATE CREDENTIAL as SYS is needed on 12c
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   12/17/2014  Creation
      --
   BEGIN
      IF credential_exists(p_credential_name => p_credential_name) THEN
         DBMS_SCHEDULER.DROP_CREDENTIAL(credential_name => p_credential_name);
      END IF;
      DBMS_SCHEDULER.CREATE_CREDENTIAL(credential_name => p_credential_name,
                                       username => p_username,
                                       password => p_password);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.CREATE_CREDENTIAL', p_error_text => SQLERRM);
      RAISE;
   END create_credential;

   PROCEDURE create_app_credential IS
      --
      -- Purpose: To create the configured application credential
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/22/2015  Creation
      --
      lv_credential_name VARCHAR2(30) := aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME');
      lv_os_user VARCHAR2(30) := aca_util.get_config_value(p_name => 'OS_USER');
      lv_os_password VARCHAR2(30) := aca_util.get_config_value(p_name => 'OS_PASSWORD');
   BEGIN
      IF credential_exists(p_credential_name => lv_credential_name) THEN
         aca_util.drop_credential(p_credential_name => lv_credential_name);
      END IF;
      aca_util.create_credential(p_credential_name => lv_credential_name,
                                 p_username => lv_os_user,
                                 p_password => lv_os_password);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.CREATE_APP_CREDENTIAL', p_error_text => SQLERRM);
      RAISE;
   END create_app_credential;

   FUNCTION job_running(p_job_name IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if a scheduler job is running
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      CURSOR c1 IS
      SELECT 1 FROM user_scheduler_jobs
       WHERE job_name = p_job_name
         AND state = 'RUNNING';
      lv_job_running NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_job_running;
      CLOSE c1;
      IF lv_job_running = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.JOB_RUNNING', p_error_text => SQLERRM);
      RAISE;
   END job_running;

   PROCEDURE prepare_job(p_template_name IN VARCHAR2,
                         p_job_name IN VARCHAR2,
                         p_description IN VARCHAR2 DEFAULT NULL,
                         p_arguments IN ACA_UTIL.ARG_TAB DEFAULT aca_util.empty_arg_tab,
                         p_substitutions IN ACA_UTIL.SUB_TAB DEFAULT aca_util.empty_sub_tab,
                         p_executable_code IN CLOB DEFAULT NULL,
                         p_command_code IN CLOB DEFAULT NULL,
                         p_job_execution IN VARCHAR2 DEFAULT NULL,
                         p_repeat_interval IN VARCHAR2 DEFAULT NULL,
                         p_start_date IN TIMESTAMP WITH TIME ZONE DEFAULT NULL,
                         p_end_date IN TIMESTAMP WITH TIME ZONE DEFAULT NULL,
                         p_completion_recipients IN VARCHAR2 DEFAULT NULL,
                         p_success_recipients IN VARCHAR2 DEFAULT NULL,
                         p_failure_recipients IN VARCHAR2 DEFAULT NULL,
                         p_notifications IN VARCHAR2 DEFAULT 'NO',
                         p_log_run IN VARCHAR2 DEFAULT 'NO',
                         p_run_job IN VARCHAR2 DEFAULT 'YES') IS
      --
      -- Purpose: To prepare/run a job
      --          This procedure does the following:
      --          1. Checks if the job is currently running
      --          2. Drops the job if it already exists
      --          3. Copies the template to be used
      --          4. Replaces schedule specific data
      --          5. Replaces executable and command code
      --          6. Updates arguments
      --          7. Updates string substitutions
      --          8. Optionally runs the job
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   10/14/2015  Added arguments
      --
      lv_new_id NUMBER;
      CURSOR c1 IS
      SELECT *
        FROM aca_jobs
       WHERE id = lv_new_id
         FOR UPDATE;
      r1 c1%ROWTYPE;
      job_running_exception EXCEPTION;
   BEGIN

      -- Check if the job is currently running
      IF job_running(p_job_name) THEN
         RAISE job_running_exception;
      END IF;

      -- Drop job if it already exists
      aca_util.drop_scheduled_job(p_job_name => p_job_name);
      aca_util.drop_aca_job(p_job_name => p_job_name);

      --  Copy the template to be used
      aca_util.copy_aca_job(p_source_job_name => p_template_name,
                            p_target_job_name => p_job_name,
                            p_new_id => lv_new_id);

      OPEN c1;
         FETCH c1 INTO r1;

         -- Replace schedule specific data
         r1.description := p_description;
         r1.job_execution := p_job_execution;
         r1.repeat_interval := p_repeat_interval;
         r1.start_date := p_start_date;
         r1.end_date := p_end_date;

         -- Replace log and notification specific data
         r1.log_run := p_log_run;
         r1.notifications := p_notifications;
         r1.completion_recipients := p_completion_recipients;
         r1.success_recipients := p_success_recipients;
         r1.failure_recipients := p_failure_recipients;

         -- Replace executable and command code
         IF p_executable_code IS NOT NULL THEN
            r1.executable_code := p_executable_code;
         END IF;
         IF p_command_code IS NOT NULL THEN
            r1.command_code := p_command_code;
         END IF;

         -- Update job
         UPDATE aca_jobs
            SET ROW = r1
          WHERE CURRENT OF c1;

      CLOSE c1;

      -- Update arguments
      FOR i IN 1..p_arguments.COUNT LOOP
         UPDATE aca_job_arguments
            SET value = p_arguments(i).value
          WHERE job_id = lv_new_id
            AND name = p_arguments(i).name;
      END LOOP;

      -- Update string substitutions
      FOR i IN 1..p_substitutions.COUNT LOOP
         UPDATE aca_job_substitutions
            SET value = p_substitutions(i).value
          WHERE job_id = lv_new_id
            AND name = p_substitutions(i).name;
      END LOOP;

      COMMIT;

      IF p_run_job = 'YES' THEN
         aca_util.schedule_job(p_job_id => lv_new_id);
      END IF;

   EXCEPTION
      WHEN job_running_exception THEN
      RAISE_APPLICATION_ERROR(-20001, 'Job is currently running');
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.PREPARE_JOB', p_error_text => SQLERRM);
      RAISE;
   END prepare_job;

   PROCEDURE schedule_job(p_job_id IN NUMBER) IS
      --
      -- Purpose: To schedule a job
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ----------------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   03/15/2015  Removed the creation of program and schedule objects.
      -- GL Skillbuilders   01/14/2016  Added ORACLE_HOME and ORACLE_SID.
      -- GL Skillbuilders   02/13/2016  Added code for EXPRESS edition.
      -- GL Skillbuilders   01/12/2017  Added the replacing of all configuration values.
      --

      -- Application configuration
      CURSOR c4 IS
      SELECT * FROM aca_configuration;
      r4 c4%ROWTYPE;

      -- Job
      CURSOR c1 IS
      SELECT * FROM aca_jobs
       WHERE id = p_job_id;
      r1 c1%ROWTYPE;

      -- Arguments
      CURSOR c2 IS
      SELECT * FROM aca_job_arguments
       WHERE job_id = p_job_id
       ORDER BY order_sequence;
      r2 c2%ROWTYPE;

      -- Substitutions
      CURSOR c3 IS
      SELECT * FROM aca_job_substitutions
       WHERE job_id = p_job_id
       ORDER BY order_sequence;
      r3 c3%ROWTYPE;

      lv_os_type VARCHAR2(30)                := get_config_value(p_name => 'OS_TYPE');
      lv_os_credential_name VARCHAR2(30)     := get_config_value(p_name => 'OS_CREDENTIAL_NAME');
      lv_os_executable_name VARCHAR2(30)     := get_config_value(p_name => 'OS_EXECUTABLE_NAME');
      lv_os_home_directory VARCHAR2(1000)    := get_config_value(p_name => 'OS_HOME_DIRECTORY');
      lv_os_scripts_directory VARCHAR2(1000) := get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY');
      lv_os_log_directory VARCHAR2(1000)     := get_config_value(p_name => 'OS_LOG_DIRECTORY');
      lv_db_user VARCHAR2(30)                := get_config_value(p_name => 'DB_USER');

      lv_oracle_home VARCHAR2(1000)          := aca_util.get_oracle_home;
      lv_oracle_sid VARCHAR2(1000)           := aca_util.get_oracle_sid;

      lv_program_action VARCHAR2(4000);
      lv_number_of_arguments PLS_INTEGER := 0;
      lv_argument_position PLS_INTEGER := 1;
      lv_arguments VARCHAR2(4000);
      job_running_exception EXCEPTION;

   BEGIN

      -- Fetch job
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;

      -- Check if the job is currently running
      IF job_running(r1.name) THEN
         RAISE job_running_exception;
      END IF;

      -- Get the number of arguments
      SELECT COUNT(1) INTO lv_number_of_arguments
        FROM aca_job_arguments
       WHERE job_id = p_job_id;

      drop_job(p_job_name => r1.name);

      IF r1.program_type = 'PLSQL_BLOCK' THEN
         lv_program_action := r1.plsql_code;
      ELSIF r1.program_type = 'STORED_PROCEDURE' THEN
         lv_program_action := r1.procedure_name;
      ELSIF r1.program_type = 'EXECUTABLE' THEN

         -- Replace configuration values
         FOR r4 IN c4 LOOP
            r1.executable_filename := REPLACE(r1.executable_filename, '#'||r4.name||'#', r4.value);
            r1.executable_code     := REPLACE(r1.executable_code,     '#'||r4.name||'#', r4.value);
            r1.log_filename        := REPLACE(r1.log_filename,        '#'||r4.name||'#', r4.value);
         END LOOP;

         -- Replace actual ORACLE_HOME and ORACLE_SID
         r1.executable_filename := REPLACE(r1.executable_filename, '#ORACLE_HOME#', lv_oracle_home);
         r1.executable_filename := REPLACE(r1.executable_filename, '#ORACLE_SID#',  lv_oracle_sid);
         r1.executable_code     := REPLACE(r1.executable_code,     '#ORACLE_HOME#', lv_oracle_home);
         r1.executable_code     := REPLACE(r1.executable_code,     '#ORACLE_SID#',  lv_oracle_sid);
         r1.log_filename        := REPLACE(r1.log_filename,        '#ORACLE_HOME#', lv_oracle_home);
         r1.log_filename        := REPLACE(r1.log_filename,        '#ORACLE_SID#',  lv_oracle_sid);

         -- Replace job name
         r1.executable_filename := REPLACE(r1.executable_filename, '#NAME#', r1.name);
         r1.executable_code     := REPLACE(r1.executable_code,     '#NAME#', r1.name);
         r1.log_filename        := REPLACE(r1.log_filename,        '#NAME#', r1.name);

         -- Replace substitutions
         FOR r3 IN c3 LOOP
            r1.executable_filename := REPLACE(r1.executable_filename, '#'||r3.name||'#', r3.value);
            r1.executable_code     := REPLACE(r1.executable_code,     '#'||r3.name||'#', r3.value);
            r1.log_filename        := REPLACE(r1.log_filename,        '#'||r3.name||'#', r3.value);
         END LOOP;

         -- Remove CTRL-M if UNIX. Add CTRL-M if WINDOWS
         IF lv_os_type = 'UNIX' THEN
            r1.executable_code := REPLACE(r1.executable_code, CHR(13)||CHR(10), CHR(10));
         ELSIF lv_os_type = 'WINDOWS' THEN
            r1.executable_code := REPLACE(r1.executable_code, CHR(13)||CHR(10), CHR(10));
            r1.executable_code := REPLACE(r1.executable_code, CHR(10), CHR(13)||CHR(10));
         END IF;

         -- Write executable script
         aca_util.put_file(destination_file => r1.executable_filename,
                           destination_host => NULL,
                           credential_name => lv_os_credential_name,
                           file_contents => r1.executable_code,
                           destination_permissions => NULL);

         -- Set the program action to the applicable shell
         IF lv_os_type = 'UNIX' THEN
            lv_program_action := lv_os_executable_name;
         ELSIF lv_os_type = 'WINDOWS' THEN
            lv_program_action := 'cmd.exe';
         END IF;

         r1.executable_name := lv_program_action;

         -- Set permissions on executable script
         IF lv_os_type = 'UNIX' THEN
            IF aca_util.get_db_edition = 'EXPRESS' AND aca_util.get_db_version < 18 THEN
               run_os_command(p_command => lv_os_scripts_directory||'/chmodScript '||r1.executable_filename,
                              p_credential_name => lv_os_credential_name);
            ELSE
               run_os_command(p_command => 'chmod 770 '||r1.executable_filename,
                              p_credential_name => lv_os_credential_name);
            END IF;
         END IF;

         IF r1.command_filename IS NOT NULL THEN

            -- Replace configuration values
            FOR r4 IN c4 LOOP
               r1.command_filename := REPLACE(r1.command_filename,'#'||r4.name||'#', r4.value);
               r1.command_code     := REPLACE(r1.command_code,    '#'||r4.name||'#', r4.value);
            END LOOP;

            -- Replace actual ORACLE_HOME and ORACLE_SID
            r1.command_filename := REPLACE(r1.command_filename, '#ORACLE_HOME#', lv_oracle_home);
            r1.command_filename := REPLACE(r1.command_filename, '#ORACLE_SID#',  lv_oracle_sid);
            r1.command_code     := REPLACE(r1.command_code,     '#ORACLE_HOME#', lv_oracle_home);
            r1.command_code     := REPLACE(r1.command_code,     '#ORACLE_SID#',  lv_oracle_sid);

            -- Replace job name
            r1.command_filename := REPLACE(r1.command_filename, '#NAME#', r1.name);
            r1.command_code     := REPLACE(r1.command_code,     '#NAME#', r1.name);

            -- Replace substitutions
            FOR r3 IN c3 LOOP
               r1.command_filename := REPLACE(r1.command_filename, '#'||r3.name||'#', r3.value);
               r1.command_code     := REPLACE(r1.command_code,     '#'||r3.name||'#', r3.value);
               r1.command_code     := REPLACE(r1.command_code,     '$'||r3.name||'$', CASE WHEN r3.value IS NULL THEN NULL
                                                                                      ELSE r3.name||'='||r3.value END);
            END LOOP;

            -- Remove CTRL-M if UNIX. Add CTRL-M if WINDOWS
            IF lv_os_type = 'UNIX' THEN
               r1.command_code := REPLACE(r1.command_code, CHR(13)||CHR(10), CHR(10));
            ELSIF lv_os_type = 'WINDOWS' THEN
               r1.command_code := REPLACE(r1.command_code, CHR(13)||CHR(10), CHR(10));
               r1.command_code := REPLACE(r1.command_code, CHR(10), CHR(13)||CHR(10));
            END IF;

            -- Write command file
            aca_util.put_file(destination_file => r1.command_filename,
                              destination_host => NULL,
                              credential_name => lv_os_credential_name,
                              file_contents => r1.command_code,
                              destination_permissions => NULL);

            -- Set permissions on command file
            IF lv_os_type = 'UNIX' THEN
               IF aca_util.get_db_edition = 'EXPRESS' AND aca_util.get_db_version < 18 THEN
                  run_os_command(p_command => lv_os_scripts_directory||'/chmodScript '||r1.command_filename,
                                 p_credential_name => lv_os_credential_name);
               ELSE
                  run_os_command(p_command => 'chmod 770 '||r1.command_filename,
                                 p_credential_name => lv_os_credential_name);
               END IF;
            END IF;

        END IF;
      ELSE
         RETURN;
      END IF;

      -- Adjust the number of arguments
      IF r1.program_type = 'EXECUTABLE' THEN
         lv_number_of_arguments := lv_number_of_arguments + 1;
         IF lv_os_type = 'WINDOWS' THEN
            lv_number_of_arguments := lv_number_of_arguments + 1;
         END IF;
      END IF;

      -- Create the Job
      DBMS_SCHEDULER.CREATE_JOB(job_name            => r1.name,
                                job_type            => r1.program_type,
                                job_action          => lv_program_action,
                                number_of_arguments => lv_number_of_arguments,
                                start_date          => r1.start_date,
                                repeat_interval     => r1.repeat_interval,
                                end_date            => r1.end_date,
                                job_class           => 'DEFAULT_JOB_CLASS',
                                enabled             => FALSE,
                                auto_drop           => TRUE,
                                comments            => NULL,
                                credential_name     => NULL,
                                destination_name    => NULL);


      -- Add executable arguments
      IF r1.program_type = 'EXECUTABLE' THEN
         IF lv_os_type = 'WINDOWS' THEN
            DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(job_name => r1.name,
                                                  argument_position => lv_argument_position,
                                                  argument_value => '/C');
            lv_arguments := '/C';
            lv_argument_position := lv_argument_position + 1;
         END IF;
         DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(job_name => r1.name,
                                               argument_position => lv_argument_position,
                                               argument_value => r1.executable_filename);
         lv_arguments := TRIM(lv_arguments||' '||r1.executable_filename);
         lv_argument_position := lv_argument_position + 1;
      END IF;

      -- Add additional arguments
      OPEN c2;
      LOOP
         FETCH c2 INTO r2;
         EXIT WHEN c2%NOTFOUND;
            DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(job_name => r1.name,
                                                  argument_position => lv_argument_position,
                                                  argument_value => r2.value);
            lv_arguments := TRIM(lv_arguments||' '||r2.value);
            lv_argument_position := lv_argument_position + 1;
      END LOOP;
      CLOSE c2;

      -- Set the OS credential
      IF r1.program_type = 'EXECUTABLE' THEN
         DBMS_SCHEDULER.SET_ATTRIBUTE(name => r1.name,
                                      attribute => 'credential_name',
                                      value => lv_os_credential_name);
      END IF;

      -- Enable events
      DBMS_SCHEDULER.SET_ATTRIBUTE(r1.name, 'RAISE_EVENTS', DBMS_SCHEDULER.JOB_SUCCEEDED + DBMS_SCHEDULER.JOB_FAILED);

      -- Enable the job
      DBMS_SCHEDULER.ENABLE(name => r1.name);

      -- Update status in log if the job has been re-scheduled
      UPDATE aca_job_log
         SET status = 'JOB_RE_SCHEDULED'
       WHERE name = r1.name
         AND status = 'JOB_SCHEDULED';

      INSERT INTO aca_job_log
            (name, description, program_type,
             procedure_name, plsql_code, credential_name,
             executable_name, executable_args, executable_filename,
             executable_code, command_filename, command_code,
             job_execution, repeat_interval, start_date, end_date,
             notes, order_sequence, completion_recipients,
             success_recipients, failure_recipients,
             log_filename, log_category, notifications, log_run)
      VALUES(
             r1.name, r1.description, r1.program_type,
             r1.procedure_name, r1.plsql_code, lv_os_credential_name,
             r1.executable_name, lv_arguments, r1.executable_filename,
             r1.executable_code, r1.command_filename, r1.command_code,
             r1.job_execution, r1.repeat_interval, r1.start_date, r1.end_date,
             r1.notes, r1.order_sequence, r1.completion_recipients,
             r1.success_recipients, r1.failure_recipients,
             r1.log_filename, r1.log_category, r1.notifications, r1.log_run);

      COMMIT;

   EXCEPTION
      WHEN job_running_exception THEN
      RAISE_APPLICATION_ERROR(-20001, 'Job is currently running');
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.SCHEDULE_JOB', p_error_text => SQLERRM);
      RAISE;
   END schedule_job;

   PROCEDURE copy_aca_job(p_source_job_name IN VARCHAR2,
                          p_target_job_name IN VARCHAR2,
                          p_new_id OUT NUMBER) IS
      --
      -- Purpose: To copy a job
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   01/18/2017  Added column locked
      --
      --
      lv_new_id NUMBER := aca_job_pk_seq.NEXTVAL;
      CURSOR c1 IS
      SELECT id, p_target_job_name, description, program_type,
             procedure_name, plsql_code, credential_name,
             executable_name, executable_filename, executable_code,
             command_filename, command_code, job_execution,
             repeat_interval, start_date, end_date, enabled,
             completion_recipients, success_recipients, failure_recipients,
             log_filename, log_category, log_run, notifications
       FROM aca_jobs
      WHERE NAME = p_source_job_name;
      r1 c1%ROWTYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;
      INSERT INTO aca_jobs
             (id, job_id, name, description, program_type,
              procedure_name, plsql_code, credential_name,
              executable_name, executable_filename, executable_code,
              command_filename, command_code, job_execution,
              repeat_interval, start_date, end_date, enabled, permanent,
              completion_recipients, success_recipients, failure_recipients,
              log_filename, log_category, log_run, notifications, locked)
      VALUES (lv_new_id, r1.id, p_target_job_name, r1.description, r1.program_type,
              r1.procedure_name, r1.plsql_code, r1.credential_name,
              r1.executable_name, r1.executable_filename, r1.executable_code,
              r1.command_filename, r1.command_code, r1.job_execution,
              r1.repeat_interval, r1.start_date, r1.end_date, r1.enabled, 'NO',
              r1.completion_recipients, r1.success_recipients, r1.failure_recipients,
              r1.log_filename, r1.log_category, r1.log_run, r1.notifications, 'YES');
      p_new_id := lv_new_id;
      INSERT INTO aca_job_arguments(job_id, name, value, order_sequence)
      SELECT lv_new_id, name, value, order_sequence
        FROM aca_job_arguments
       WHERE job_id = r1.id;
      INSERT INTO aca_job_substitutions(job_id, name, value, order_sequence)
      SELECT lv_new_id, name, value, order_sequence
        FROM aca_job_substitutions
       WHERE job_id = r1.id;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.COPY_ACA_JOB', p_error_text => SQLERRM);
      RAISE;
   END copy_aca_job;

   PROCEDURE sleep(p_seconds IN NUMBER) IS
      -- Hack if DBMS_LOCK.SLEEP is not available.
      lv_now DATE := SYSDATE;
   BEGIN
      LOOP
         EXIT WHEN lv_now + (p_seconds * (1/86400)) <= SYSDATE;
      END LOOP;
   END sleep;

   PROCEDURE os_command(p_command IN VARCHAR2,
                        p_credential_name IN VARCHAR2,
                        p_timeout IN NUMBER DEFAULT 10,
                        p_status OUT VARCHAR2,
                        p_output OUT CLOB,
                        p_success_message OUT VARCHAR2,
                        p_failure_message OUT VARCHAR2) IS
      --
      -- Purpose: To run an OS command (Oracle 11g)
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   01/12/2016  Added cmd.exe /C for Windows
      --
      --
      NO_STDOUT_OR_STDERR EXCEPTION;
      PRAGMA EXCEPTION_INIT(NO_STDOUT_OR_STDERR, -22288);

      lv_command VARCHAR2(4000);
      lv_blob BLOB;
      lv_job_name VARCHAR2(30);
      lv_log_id VARCHAR2(50);
      lv_additional_info VARCHAR2(4000);
      lv_log_status VARCHAR2(30);
      lv_timeout NUMBER := 0;
      lv_success_message VARCHAR2(32676);
      lv_failure_message VARCHAR2(32676);
      crlf VARCHAR2(2) := '
';

      command_array APEX_APPLICATION_GLOBAL.VC_ARR2;

      CURSOR c1 IS
      SELECT additional_info, REGEXP_SUBSTR(additional_info,'job[_0-9]*'), status
        FROM user_scheduler_job_run_details
       WHERE job_name = lv_job_name;

   BEGIN

      IF get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         lv_command := 'cmd.exe /C '||p_command;
      ELSE
         lv_command := p_command;
      END IF;

      command_array := APEX_UTIL.STRING_TO_TABLE(TRIM(REGEXP_REPLACE(lv_command,'( ){2,}', ' ')), ' ');

      lv_job_name := 'SBA_'||DBMS_RANDOM.STRING('X', 10);

      DBMS_LOB.CREATETEMPORARY(lv_blob, FALSE);

      DBMS_SCHEDULER.CREATE_JOB(job_name            => lv_job_name,
                                job_type            => 'EXECUTABLE',
                                job_action          => command_array(1),
                                number_of_arguments => command_array.COUNT - 1,
                                enabled             => FALSE,
                                auto_drop           => TRUE,
                                credential_name     => p_credential_name);

      FOR i IN 2..command_array.COUNT LOOP
         DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(lv_job_name, i - 1, command_array(i));
      END LOOP;

      DBMS_SCHEDULER.ENABLE(lv_job_name);

      LOOP
         OPEN c1;
            FETCH c1 INTO lv_additional_info, lv_log_id, lv_log_status;
         CLOSE c1;
         IF lv_log_status IN ('SUCCEEDED', 'FAILED') THEN
            EXIT;
         ELSE
            DBMS_LOCK.SLEEP(1);
         END IF;
         lv_timeout := lv_timeout + 1;
         EXIT WHEN lv_timeout = p_timeout;
      END LOOP;

      p_status := lv_log_status;

      IF lv_log_status = 'SUCCEEDED' THEN
         BEGIN
            DBMS_SCHEDULER.GET_FILE(source_file     => lv_log_id ||'_stdout',
                                    credential_name => p_credential_name,
                                    file_contents   => lv_blob,
                                    source_host     => NULL);
            p_output := blob2clob(lv_blob);
         EXCEPTION
            WHEN NO_STDOUT_OR_STDERR THEN
               lv_success_message := p_command||' - Command executed successfully.'||crlf;
         END;
      ELSIF lv_log_status = 'FAILED' THEN
         BEGIN
            DBMS_SCHEDULER.GET_FILE(source_file     => lv_log_id ||'_stderr',
                                    credential_name => p_credential_name,
                                    file_contents   => lv_blob,
                                    source_host     => NULL);
            p_output := blob2clob(lv_blob);
         EXCEPTION
            WHEN NO_STDOUT_OR_STDERR THEN
               lv_failure_message := p_command||' - Command failed.'||crlf||crlf;
         END;
      END IF;
      p_success_message := lv_success_message;
      p_failure_message := lv_failure_message;
   EXCEPTION
      WHEN OTHERS THEN
      p_status := 'FAILED';
      lv_failure_message := lv_failure_message||lv_additional_info||crlf||crlf;
      lv_failure_message := lv_failure_message||SQLERRM||crlf;
      p_failure_message := lv_failure_message;
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.OS_COMMAND', p_error_text => lv_failure_message);
    END os_command;

   PROCEDURE os_command2(p_command IN VARCHAR2,
                         p_credential_name IN VARCHAR2,
                         p_timeout IN NUMBER DEFAULT 10,
                         p_status OUT VARCHAR2,
                         p_output OUT CLOB,
                         p_success_message OUT VARCHAR2,
                         p_failure_message OUT VARCHAR2) IS
      --
      -- Purpose: To run an OS command (Oracle 12c and above)
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   22/12/2014  Creation
      -- GL Skillbuilders   09/14/2015  Changed to use dynamic SQL. To prevent compilation
      --                                failure on Oracle 11g
      -- GL Skillbuilders   01/12/2016  Added cmd.exe /C for Windows
      --

      lv_command VARCHAR2(4000);
      lv_job_name VARCHAR2(30);
      lv_timeout NUMBER := 0;
      lv_failure_message VARCHAR2(32676);
      crlf VARCHAR2(2) := '
';

      command_array APEX_APPLICATION_GLOBAL.VC_ARR2;

      TYPE cursor_type IS REF CURSOR;
      c1 cursor_type;
      lv_query VARCHAR2(4000) := '
      SELECT status, additional_info, binary_output, binary_errors
        FROM user_scheduler_job_run_details
       WHERE job_name = :j';
      TYPE record_type IS RECORD (status VARCHAR2(30),
                                  additional_info VARCHAR2(4000),
                                  binary_output BLOB,
                                  binary_errors BLOB);
      r1 record_type;

   BEGIN

      IF get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         lv_command := 'cmd.exe /C '||p_command;
      ELSE
         lv_command := p_command;
      END IF;

      command_array := APEX_UTIL.STRING_TO_TABLE(TRIM(REGEXP_REPLACE(lv_command,'( ){2,}', ' ')), ' ');

      lv_job_name := 'SBA_'||DBMS_RANDOM.STRING('X', 10);

      DBMS_SCHEDULER.CREATE_JOB(job_name            => lv_job_name,
                                job_type            => 'EXECUTABLE',
                                job_action          => command_array(1),
                                number_of_arguments => command_array.COUNT - 1,
                                enabled             => FALSE,
                                auto_drop           => TRUE,
                                credential_name     => p_credential_name);

      FOR i IN 2..command_array.COUNT LOOP
         DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(lv_job_name, i - 1, command_array(i));
      END LOOP;

      DBMS_SCHEDULER.ENABLE(lv_job_name);

      LOOP
         OPEN c1 FOR lv_query USING lv_job_name;
            FETCH c1 INTO r1;
         CLOSE c1;
         IF r1.status IN ('SUCCEEDED', 'FAILED') THEN
            EXIT;
         ELSE
            DBMS_LOCK.SLEEP(1);
         END IF;
         lv_timeout := lv_timeout + 1;
         EXIT WHEN lv_timeout = p_timeout;
      END LOOP;

      p_status := r1.status;

      IF r1.status = 'SUCCEEDED' THEN
         IF DBMS_LOB.GETLENGTH(r1.binary_output) = 0 THEN
            p_success_message := p_command||' - Command executed successfully.'||crlf;
         ELSE
            p_output := blob2clob(r1.binary_output);
         END IF;
      ELSIF r1.status = 'FAILED' THEN
         IF DBMS_LOB.GETLENGTH(r1.binary_errors) = 0 THEN
            p_failure_message := p_command||' - Command failed.'||crlf;
         ELSE
            p_output := blob2clob(r1.binary_errors);
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      p_status := 'FAILED';
      lv_failure_message := lv_failure_message||r1.additional_info||crlf||crlf;
      lv_failure_message := lv_failure_message||SQLERRM||crlf;
      p_failure_message := lv_failure_message;
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.OS_COMMAND2', p_error_text => lv_failure_message);
   END os_command2;

   PROCEDURE run_os_command(p_command IN VARCHAR2,
                            p_credential_name IN VARCHAR2,
                            p_timeout IN NUMBER DEFAULT 10) IS
      --
      -- Purpose: To run an OS command ignoring output
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders               Added selecting Version 11 and Version 12
      --                                os_command call
      -- GL Skillbuilders   02/19/2019  Changed ELSIF DBMS_DB_VERSION.VERSION = 12
      --                                to ELSIF DBMS_DB_VERSION.VERSION >= 12
      --
      lv_output CLOB;
      lv_status VARCHAR2(30);
      lv_success_message VARCHAR2(32676);
      lv_failure_message VARCHAR2(32676);
   BEGIN
      IF DBMS_DB_VERSION.VERSION = 11 THEN
         os_command(p_command => p_command,
                    p_credential_name => p_credential_name,
                    p_timeout => p_timeout,
                    p_status => lv_status,
                    p_output => lv_output,
                    p_success_message => lv_success_message,
                    p_failure_message => lv_failure_message);
      ELSIF DBMS_DB_VERSION.VERSION >= 12 THEN
         os_command2(p_command => p_command,
                     p_credential_name => p_credential_name,
                     p_timeout => p_timeout,
                     p_status => lv_status,
                     p_output => lv_output,
                     p_success_message => lv_success_message,
                     p_failure_message => lv_failure_message);
      ELSE
         RAISE_APPLICATION_ERROR(-20001, 'Oracle Version not supported');
      END IF;

      IF lv_status != 'SUCCEEDED' THEN
         RAISE_APPLICATION_ERROR(-20002, lv_failure_message||' '||p_command||' - OS command failed');
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.RUN_OS_COMMAND', p_error_text => SQLERRM);
      RAISE;
   END run_os_command;

   PROCEDURE run_os_command_with_output(p_command IN VARCHAR2,
                                        p_credential_name IN VARCHAR2,
                                        p_timeout IN NUMBER DEFAULT 10,
                                        p_status OUT VARCHAR2,
                                        p_output OUT CLOB,
                                        p_success_message OUT VARCHAR2,
                                        p_failure_message OUT VARCHAR2) IS
      --
      -- Purpose: To run an OS command with output
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   03/21/2015  Creation
      -- GL Skillbuilders   02/19/2019  Changed ELSIF DBMS_DB_VERSION.VERSION = 12
      --                                to ELSIF DBMS_DB_VERSION.VERSION >= 12
      --
      version_not_supported EXCEPTION;
      PRAGMA EXCEPTION_INIT(version_not_supported, -20001);
      os_command_failed EXCEPTION;
      PRAGMA EXCEPTION_INIT(os_command_failed, -20002);

      lv_status VARCHAR2(30);
      lv_output CLOB;
      lv_success_message VARCHAR2(32676);
      lv_failure_message VARCHAR2(32676);
   BEGIN
      IF DBMS_DB_VERSION.VERSION = 11 THEN
         os_command(p_command => p_command,
                    p_credential_name => p_credential_name,
                    p_timeout => p_timeout,
                    p_status => lv_status,
                    p_output => lv_output,
                    p_success_message => lv_success_message,
                    p_failure_message => lv_failure_message);
      ELSIF DBMS_DB_VERSION.VERSION >= 12 THEN
         os_command2(p_command => p_command,
                     p_credential_name => p_credential_name,
                     p_timeout => p_timeout,
                     p_status => lv_status,
                     p_output => lv_output,
                     p_success_message => lv_success_message,
                     p_failure_message => lv_failure_message);
      ELSE
         RAISE_APPLICATION_ERROR(-20001, 'Oracle Version not supported');
      END IF;

      IF lv_status != 'SUCCEEDED' THEN
         RAISE_APPLICATION_ERROR(-20002, lv_failure_message||' '||p_command||' - OS command failed');
      END IF;

      p_status := lv_status;
      p_output := lv_output;
      p_success_message := lv_success_message;
      p_failure_message := lv_failure_message;

   EXCEPTION
      WHEN version_not_supported THEN
      RAISE;
      WHEN os_command_failed THEN
      RAISE;
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.RUN_OS_COMMAND_WITH_OUTPUT', p_error_text => SQLERRM);
      RAISE;
   END run_os_command_with_output;

   PROCEDURE run_os_command_from_apex(p_command IN VARCHAR2,
                                      p_credential_name IN VARCHAR2,
                                      p_timeout IN NUMBER DEFAULT 10) IS
      --
      -- Purpose: To run an OS command from APEX
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      -- GL Skillbuilders   02/19/2019  Changed ELSIF DBMS_DB_VERSION.VERSION = 12
      --                                to ELSIF DBMS_DB_VERSION.VERSION >= 12
      --
      lv_output CLOB;
      lv_status VARCHAR2(30);
      lv_success_message VARCHAR2(32676);
      lv_failure_message VARCHAR2(32676);

   BEGIN
      IF DBMS_DB_VERSION.VERSION = 11 THEN
         os_command(p_command => p_command,
                    p_credential_name => p_credential_name,
                    p_timeout => p_timeout,
                    p_status => lv_status,
                    p_output => lv_output,
                    p_success_message => lv_success_message,
                    p_failure_message => lv_failure_message);
      ELSIF DBMS_DB_VERSION.VERSION >= 12 THEN
         os_command2(p_command => p_command,
                     p_credential_name => p_credential_name,
                     p_timeout => p_timeout,
                     p_status => lv_status,
                     p_output => lv_output,
                     p_success_message => lv_success_message,
                     p_failure_message => lv_failure_message);
      ELSE
         RAISE_APPLICATION_ERROR(-20001, 'Oracle Version not supported');
      END IF;
      IF lv_status = 'SUCCEEDED' THEN
         HTP.PRN('<p style="color:green;">');
         HTP.PRN(lv_success_message);
         HTP.PRN('</p>');
         print_clob(lv_output);
      ELSIF lv_status = 'FAILED' THEN
         HTP.PRN('<p style="color:red;">');
         HTP.PRN(lv_failure_message);
         HTP.PRN('</p>');
         print_clob(lv_output);
      ELSE
         HTP.PRN('<p style="color:red;">');
         HTP.PRN('Command returned with status '||lv_status||'.');
         HTP.PRN('</p>');
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.RUN_OS_COMMAND_FROM_APEX', p_error_text => SQLERRM);
      RAISE;
   END run_os_command_from_apex;

   PROCEDURE drop_scheduled_job(p_job_name IN VARCHAR2) IS
      --
      -- Purpose: To drop all components of a scheduled job
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      --
   BEGIN
      IF job_exists(p_job_name => p_job_name) THEN
         drop_job(p_job_name => p_job_name);
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DROP_SCHEDULED_JOB', p_error_text => SQLERRM);
      RAISE;
   END drop_scheduled_job;

   PROCEDURE drop_aca_job(p_job_name IN VARCHAR2) IS
      --
      -- Purpose: To drop an ACA job that is not flagged as permanent (Template)
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      --
   BEGIN
      DELETE FROM aca_jobs
       WHERE name = p_job_name
         AND permanent = 'NO';
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DROP_ACA_JOB', p_error_text => SQLERRM);
      RAISE;
   END drop_aca_job;

   PROCEDURE delete_job_log_entries(p_job_name IN VARCHAR2) IS
      --
      -- Purpose: To delete job log entries.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/21/2015  Creation
      --
      --
   BEGIN
      DELETE FROM aca_job_log
       WHERE name = p_job_name
         AND status = 'JOB_SCHEDULED';
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DELETE_JOB_LOG_ENTRIES', p_error_text => SQLERRM);
      RAISE;
   END delete_job_log_entries;

   PROCEDURE drop_job_all(p_job_name IN VARCHAR2) IS
      --
      -- Purpose: To drop a scheduled job, an aca job and delete job log entries.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/22/2015  Creation
      --
      --
   BEGIN
      drop_scheduled_job(p_job_name => p_job_name);
      drop_aca_job(p_job_name => p_job_name);
      delete_job_log_entries(p_job_name => p_job_name);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.DELETE_JOB_ALL', p_error_text => SQLERRM);
      RAISE;
   END drop_job_all;

   PROCEDURE set_apex_smtp_parameters IS
      --
      -- Purpose: To run an OS command from APEX
      --    Note: Direct grant on APEX_INSTANCE_ADMIN is required.
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
   BEGIN
       APEX_INSTANCE_ADMIN.SET_PARAMETER('SMTP_HOST_ADDRESS', 'localhost');
       APEX_INSTANCE_ADMIN.SET_PARAMETER('SMTP_HOST_PORT', '25');
       COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.SET_APEX_SMTP_PARAMETERS', p_error_text => SQLERRM);
      RAISE;
   END set_apex_smtp_parameters;

   PROCEDURE update_log_filename(p_name IN VARCHAR2,
                                 p_log_filename IN VARCHAR2) IS
      --
      -- Purpose: To update the log filename
      --    Note: This can be called by SQL*Plus from an OS script after
      --          a log has been moved e.g. Daily exports
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
   BEGIN
      UPDATE aca_job_log
         SET log_filename = p_log_filename
       WHERE name = p_name
         AND status = 'JOB_SCHEDULED';
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.UPDATE_LOG_FILENAME', p_error_text => SQLERRM);
      RAISE;
   END update_log_filename;

   FUNCTION get_log_filename(p_log_id IN NUMBER,
                             p_position IN NUMBER DEFAULT 1) RETURN VARCHAR2 IS
      --
      -- Purpose: To get the log filename given the job ID
      --    Note: Supports multiple filenames.
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders               Creation
      --
      logfiles APEX_APPLICATION_GLOBAL.VC_ARR2;
      lv_logfile VARCHAR2(1000);
      CURSOR c1 IS
      SELECT log_filename
        FROM aca_job_log
       WHERE id = p_log_id;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_logfile;
      CLOSE c1;
      logfiles := APEX_UTIL.STRING_TO_TABLE(REPLACE(lv_logfile, ' ', ''), ',');
      RETURN logfiles(p_position);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_LOG_FILENAME', p_error_text => SQLERRM);
      RAISE;
   END get_log_filename;

   FUNCTION get_distinct_list(p_list IN VARCHAR2,
                              p_delimiter IN VARCHAR2 DEFAULT ',') RETURN VARCHAR2 IS
      --
      -- Purpose: To get a distinct list
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/11/2015  Creation
      --
       list_array APEX_APPLICATION_GLOBAL.VC_ARR2 := APEX_UTIL.STRING_TO_TABLE(p_list, p_delimiter);
       list_collection list_collection_type := list_collection_type();
       lv_list VARCHAR(32000);
   BEGIN
      FOR i IN 1..list_array.COUNT LOOP
         list_collection.EXTEND;
         list_collection(list_collection.LAST) := list_array(i);
      END LOOP;
      FOR rec IN (SELECT DISTINCT column_value list_entry
                    FROM TABLE(CAST(list_collection AS list_collection_type))
                   ORDER BY column_value DESC) LOOP
         lv_list := p_delimiter||rec.list_entry||lv_list;
      END LOOP;
      RETURN SUBSTR(lv_list, 2);
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DISTINCT_LIST', p_error_text => SQLERRM);
      RAISE;
   END get_distinct_list;

   FUNCTION validate_ora_name(p_name IN VARCHAR2,
                              p_label IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To validate a name. Returning an error string.
      --    Note: This function considers $ and # as invalid
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/28/2015  Creation
      -- GL Skillbuilders   30/09/2015  Removed setting p_name to NULL
      --
   BEGIN
      APEX_UTIL.SET_SESSION_STATE(p_name, UPPER(V(p_name)));
      IF NOT REGEXP_LIKE(V(p_name), '^[a-zA-Z]{1}[A-Za-z0-9_]*$') THEN
         RETURN p_label||' is invalid.';
      ELSE
         RETURN NULL;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.VALIDATE_ORA_NAME', p_error_text => SQLERRM);
      RAISE;
   END validate_ora_name;

   FUNCTION test_os_directory_writable(p_directory IN VARCHAR2) RETURN BOOLEAN IS
      --
      -- Purpose: To test if an OS directory is writable
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   03/21/2014  Creation
      --
      lv_status VARCHAR2(30);
      lv_output CLOB;
      lv_success_message VARCHAR2(32676);
      lv_failure_message VARCHAR2(32676);
      lv_home_directory VARCHAR2(1000) := aca_util.get_config_value('OS_HOME_DIRECTORY');
      lv_scripts_directory VARCHAR2(1000) := aca_util.get_config_value('OS_SCRIPTS_DIRECTORY');
      lv_script VARCHAR2(80) := '/testDirectoryWritable.sh';
   BEGIN
      IF aca_util.get_config_value('OS_TYPE') = 'WINDOWS' THEN
         lv_script := '\testDirectoryWritable.bat';
      END IF;
      run_os_command_with_output(p_command => lv_scripts_directory||lv_script||' '||lv_home_directory||' '||p_directory,
                                 p_credential_name => aca_util.get_config_value('OS_CREDENTIAL_NAME'),
                                 p_status => lv_status,
                                 p_output => lv_output,
                                 p_success_message => lv_success_message,
                                 p_failure_message => lv_failure_message);

     IF SUBSTR(lv_output, 1, 3) = 'YES' THEN
        RETURN TRUE;
     ELSE
        RETURN FALSE;
     END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.TEST_OS_DIRECTORY_WRITABLE', p_error_text => SQLERRM);
      RAISE;
   END test_os_directory_writable;

   FUNCTION aca_check_unique(p_name IN VARCHAR2,
                             p_table_name IN VARCHAR2,
                             p_id IN NUMBER DEFAULT NULL) RETURN VARCHAR2 IS
      --
      --
      -- Purpose: To check unique names over multiple tables
      --    NOTE: The list of tables is hard coded and has to be modified if
      --          a table that needs the unique check is added.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  -------------------------------------------
      -- GL Skillbuilders   04/16/2015  Creation
      --

         c1 SYS_REFCURSOR;
         lv_p_id NUMBER := NVL(p_id, 0);
         lv_id NUMBER;
         lv_table_name VARCHAR2(30);
         table_array APEX_APPLICATION_GLOBAL.VC_ARR2 := APEX_UTIL.STRING_TO_TABLE('ACA_JOBS,'||
                                                                                  'ACA_SCHEDULER_JOBS,'||
                                                                                  'ACA_APEX_EXPORT_SCHEDULES,'||
                                                                                  'ACA_SQL_REPOSITORY,'||
                                                                                  'ACA_DATAPUMP_JOBS,'||
                                                                                  'ACA_CLONE_SCHEDULES,'||
                                                                                  'ACA_BACKUP_SCHEDULES', ',');

         cursor_statement VARCHAR2(4000);

   BEGIN
      FOR i IN 1..table_array.COUNT LOOP
         cursor_statement := '
SELECT '''||table_array(i)||''' table_name, id
  FROM '||table_array(i)||'
 WHERE (name = '''||p_name||''' AND '''||table_array(i)||''' != '''||p_table_name||''')
        OR
       (name = '''||p_name||''' AND '''||table_array(i)||''' = '''||p_table_name||''' AND id <> '||lv_p_id||')
        OR
       (name = '''||p_name||''' AND '''||table_array(i)||''' = '''||p_table_name||''' AND 0 = '||lv_p_id||')';
         OPEN c1 FOR cursor_statement;
            FETCH c1 INTO lv_table_name, lv_id;
         CLOSE c1;
      END LOOP;

      IF lv_id IS NOT NULL THEN
         RETURN('An object with this name already exists. Table: '||lv_table_name||' ID: '||TO_CHAR(lv_id));
      ELSE
         RETURN NULL;
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.ACA_CHECK_UNIQUE', p_error_text => SQLERRM);
      RAISE;
   END aca_check_unique;

   FUNCTION get_metric_unit(p_metric_id IN NUMBER) RETURN VARCHAR2 IS
      --
      -- Purpose: To get a metric unit given it's id.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   04/28/2015  Creation
      --
      CURSOR c1 IS
      SELECT metric_unit
        FROM aca_metrics
       WHERE metric_id = p_metric_id;
       lv_metric_unit aca_metrics.metric_unit%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_metric_unit;
      CLOSE c1;
      RETURN lv_metric_unit;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_METRIC_UNIT', p_error_text => SQLERRM);
      RAISE;
   END get_metric_unit;

   PROCEDURE init_scheduler_event_queue IS
      --
      -- Purpose: To initialize the scheduler event queue
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   12/17/2014  Creation
      -- GL Skillbuilders   05/25/2015  Added schema USER
      --
   BEGIN
      DBMS_SCHEDULER.REMOVE_EVENT_QUEUE_SUBSCRIBER;
      DBMS_SCHEDULER.ADD_EVENT_QUEUE_SUBSCRIBER;
      DBMS_AQ.REGISTER(SYS.AQ$_REG_INFO_LIST(SYS.AQ$_REG_INFO('SYS.SCHEDULER$_EVENT_QUEUE:'||USER,
                                                               DBMS_AQ.NAMESPACE_AQ,
                                                              'plsql://'||LOWER(USER)||'.aca_dequeue_scheduler_event',
                                                               HEXTORAW('FF'))), 1 );
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.INIT_SCHEDULER_EVENT_QUEUE', p_error_text => SQLERRM);
      RAISE;
   END init_scheduler_event_queue;

   PROCEDURE init_system_alert_queue IS
      --
      -- Purpose: To initialize the system alert queue
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   05/25/2015  Creation
      --
   BEGIN

      -- Remove subscriber
      BEGIN
         DBMS_AQADM.REMOVE_SUBSCRIBER(queue_name=>'SYS.ALERT_QUE', subscriber => SYS.AQ$_AGENT('ALERTAGENT','',0));
      EXCEPTION
         WHEN OTHERS THEN NULL;
      END;

      -- Drop Agent
      BEGIN
         DBMS_AQADM.DROP_AQ_AGENT(agent_name=> 'ALERTAGENT');
      EXCEPTION
         WHEN OTHERS THEN NULL;
      END;

      -- create a queue agent
      DBMS_AQADM.CREATE_AQ_AGENT(agent_name => 'ALERTAGENT');

      -- subscribe to alert_que
      DBMS_AQADM.ADD_SUBSCRIBER(queue_name => 'SYS.ALERT_QUE', subscriber => SYS.AQ$_AGENT('ALERTAGENT','',0));

      -- associate schema user with the secure queue
      DBMS_AQADM.ENABLE_DB_ACCESS(agent_name => 'ALERTAGENT', db_username => USER);

      -- grant queue privilege NOTE: This has to be done as user SYS
      -- DBMS_AQADM.GRANT_QUEUE_PRIVILEGE(privilege => 'DEQUEUE',queue_name => 'SYS.ALERT_QUE',grantee => USER, grant_option => FALSE);

      -- register queue callback procedure
      DBMS_AQ.REGISTER(SYS.AQ$_REG_INFO_LIST(SYS.AQ$_REG_INFO('SYS.ALERT_QUE:ALERTAGENT',
                                                              DBMS_AQ.NAMESPACE_AQ,
                                                              'plsql://'||LOWER(USER)||'.aca_dequeue_alert_event',
                                                              HEXTORAW('FF'))), 1 );

   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.INIT_SYSTEM_ALERT_QUEUE', p_error_text => SQLERRM);
      RAISE;
   END init_system_alert_queue;

   FUNCTION test_os_settings(p_os_type IN VARCHAR2,
                             p_os_user IN VARCHAR2,
                             p_os_password IN VARCHAR2,
                             p_os_home_directory IN VARCHAR2,
                             p_os_scripts_directory IN VARCHAR2,
                             p_os_log_directory IN VARCHAR2,
                             p_os_apex_directory IN VARCHAR2,
                             p_data_pump_directory_path IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To test OS setting on post installation
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   06/24/2015  Creation
      -- GL Skillbuilders   12/08/2015  Added p_os_apex_directory
      -- GL Skillbuilders   01/30/2016  Added OS_TYPE
      --
      os_command_failed EXCEPTION;
      PRAGMA EXCEPTION_INIT(os_command_failed, -20002);
      lv_status VARCHAR2(30);
      lv_output CLOB;
      lv_success_message VARCHAR2(32676);
      lv_failure_message VARCHAR2(32676);
      lv_credential_name VARCHAR2(30) := 'C'||TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
      lv_home_directory VARCHAR2(1000) := p_os_home_directory;
      lv_scripts_directory VARCHAR2(1000) := p_os_scripts_directory;
      lv_directory VARCHAR2(1000);
      lv_script VARCHAR2(80) := '/testDirectoryWritable.sh';
   BEGIN
      -- Set the OS_TYPE in the configuration
      aca_util.set_config_value('OS_TYPE', p_os_type);

      -- Create a temporary credential
      create_credential(p_credential_name => lv_credential_name,
                        p_username => p_os_user,
                        p_password => p_os_password);

      IF p_os_type = 'WINDOWS' THEN
         lv_script := '\testDirectoryWritable.bat';
      END IF;

      -- Check basic logon
      BEGIN
         run_os_command_with_output(p_command => 'echo hello',
                                    p_credential_name => lv_credential_name,
                                    p_status => lv_status,
                                    p_output => lv_output,
                                    p_success_message => lv_success_message,
                                    p_failure_message => lv_failure_message);
      EXCEPTION
         WHEN os_command_failed THEN
         drop_credential(lv_credential_name);
         RETURN 'Cannot logon with the credentials given. Username/Password incorrect.';
      END;

      -- Check Home Directory and Scripts Directory
      BEGIN
         run_os_command_with_output(p_command => lv_scripts_directory||lv_script||' '||lv_home_directory||' '||lv_home_directory,
                                    p_credential_name => lv_credential_name,
                                    p_status => lv_status,
                                    p_output => lv_output,
                                    p_success_message => lv_success_message,
                                    p_failure_message => lv_failure_message);
         IF SUBSTR(lv_output, 1, 2) = 'NO' THEN
            drop_credential(lv_credential_name);
            RETURN 'Cannot write to Home Directory. Check the path and privileges.';
         END IF;
      EXCEPTION
         WHEN os_command_failed THEN
         drop_credential(lv_credential_name);
         RETURN 'Cannot execute '||lv_scripts_directory||lv_script||' Check the path and privileges of the Scripts Directory.';
      END;

      -- Check Home Directory and Log Directory
      BEGIN
         lv_directory := p_os_log_directory;
         run_os_command_with_output(p_command => lv_scripts_directory||lv_script||' '||lv_home_directory||' '||lv_directory,
                                    p_credential_name => lv_credential_name,
                                    p_status => lv_status,
                                    p_output => lv_output,
                                    p_success_message => lv_success_message,
                                    p_failure_message => lv_failure_message);
         IF SUBSTR(lv_output, 1, 2) = 'NO' THEN
            drop_credential(lv_credential_name);
            RETURN 'Cannot write to Log Directory. Check the path and privileges.';
         END IF;
      EXCEPTION
         WHEN os_command_failed THEN
         drop_credential(lv_credential_name);
         RETURN 'Cannot execute '||lv_scripts_directory||lv_script||' Check the path and privileges of the Scripts Directory.';
      END;

      -- Check Home Directory and Apex Directory
      BEGIN
         lv_directory := p_os_apex_directory;
         run_os_command_with_output(p_command => lv_scripts_directory||lv_script||' '||lv_home_directory||' '||lv_directory,
                                    p_credential_name => lv_credential_name,
                                    p_status => lv_status,
                                    p_output => lv_output,
                                    p_success_message => lv_success_message,
                                    p_failure_message => lv_failure_message);
         IF SUBSTR(lv_output, 1, 2) = 'NO' THEN
            drop_credential(lv_credential_name);
            RETURN 'Cannot write to Apex Export Directory. Check the path and privileges.';
         END IF;
      EXCEPTION
         WHEN os_command_failed THEN
         drop_credential(lv_credential_name);
         RETURN 'Cannot execute '||lv_scripts_directory||lv_script||' Check the path and privileges of the Scripts Directory.';
      END;

      -- Check Home Directory and Data Pump Directory
      BEGIN
         lv_directory := p_data_pump_directory_path;
         run_os_command_with_output(p_command => lv_scripts_directory||lv_script||' '||lv_home_directory||' '||lv_directory,
                                    p_credential_name => lv_credential_name,
                                    p_status => lv_status,
                                    p_output => lv_output,
                                    p_success_message => lv_success_message,
                                    p_failure_message => lv_failure_message);

         IF SUBSTR(lv_output, 1, 2) = 'NO' THEN
            drop_credential(lv_credential_name);
            RETURN 'Cannot write to Data Pump Directory. Check the path and privileges.';
         END IF;
      EXCEPTION
         WHEN os_command_failed THEN
         drop_credential(lv_credential_name);
         RETURN 'Cannot execute '||lv_scripts_directory||lv_script||' Check the path and privileges of the Scripts Directory.';
      END;

      drop_credential(lv_credential_name);
      RETURN NULL;

   EXCEPTION
      WHEN OTHERS THEN
      drop_credential(lv_credential_name);
      RETURN SQLERRM;
   END test_os_settings;

   FUNCTION test_db_settings(p_db_host IN VARCHAR2,
                             p_db_port IN VARCHAR2,
                             p_db_service_name IN VARCHAR2,
                             p_db_user IN VARCHAR2,
                             p_db_password IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To test if the DB user and password are valid using a DB Link.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   06/25/2015  Creation
      -- GL Skillbuilders   09/14/2015  Replaced SYS_CONTEXT('USERENV', 'SERVICE_NAME')
      --                                with v$parameter service_names
      -- GL Skillbuilders   01/02/2016  Added p_db_host
      -- GL Skillbuilders   02/21/2019  Added p_db_service_name
      -- GL Skillbuilders   02/21/2019  Removed all code related to SID
      --
      lv_db_link_name VARCHAR2(30) := 'DBLINK'||TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
      lv_dummy VARCHAR2(1);
   BEGIN
      EXECUTE IMMEDIATE
      'CREATE DATABASE LINK '||lv_db_link_name||'
      CONNECT TO '||p_db_user||' IDENTIFIED BY '||p_db_password||'
      USING ''(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST='||p_db_host||')(PORT='||p_db_port||'))(CONNECT_DATA=(SERVICE_NAME='||p_db_service_name||')))''';
      EXECUTE IMMEDIATE 'SELECT dummy FROM dual@'||lv_db_link_name INTO lv_dummy;
      EXECUTE IMMEDIATE 'DROP DATABASE LINK '||lv_db_link_name;
      IF lv_dummy = 'X' THEN
         RETURN NULL;
      ELSE
         RETURN 'Could not query the database using the credentials given.';
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      BEGIN
         EXECUTE IMMEDIATE 'DROP DATABASE LINK '||lv_db_link_name;
      EXCEPTION
         WHEN OTHERS THEN
         RETURN 'Could not query the database using the credentials given. '||SQLERRM;
      END;
      RETURN 'Could not query the database using the credentials given. '||SQLERRM;
   END test_db_settings;

   FUNCTION test_cdb_settings(p_db_host IN VARCHAR2,
                              p_db_port IN VARCHAR2,
                              p_db_service_name IN VARCHAR2,
                              p_db_user IN VARCHAR2,
                              p_db_password IN VARCHAR2) RETURN VARCHAR2 IS
      --
      -- Purpose: To test if the CDB user and password are valid using a DB Link.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/28/2019  Creation
      --
      lv_db_link_name VARCHAR2(30) := 'DBLINK'||TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
      lv_dummy VARCHAR2(1);
   BEGIN
      EXECUTE IMMEDIATE
      'CREATE DATABASE LINK '||lv_db_link_name||'
      CONNECT TO '||p_db_user||' IDENTIFIED BY '||p_db_password||'
      USING ''(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST='||p_db_host||')(PORT='||p_db_port||'))(CONNECT_DATA=(SERVICE_NAME='||p_db_service_name||')))''';
      EXECUTE IMMEDIATE 'SELECT dummy FROM dual@'||lv_db_link_name INTO lv_dummy;
      EXECUTE IMMEDIATE 'DROP DATABASE LINK '||lv_db_link_name;
      IF lv_dummy = 'X' THEN
         RETURN NULL;
      ELSE
         RETURN 'Could not query the CDB database using the credentials given.';
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      BEGIN
         EXECUTE IMMEDIATE 'DROP DATABASE LINK '||lv_db_link_name;
      EXCEPTION
         WHEN OTHERS THEN
         RETURN 'Could not query the CDB database using the credentials given. '||SQLERRM;
      END;
      RETURN 'Could not query the CDB database using the credentials given. '||SQLERRM;
   END test_cdb_settings;

   PROCEDURE restart_internal_jobs IS
   BEGIN
      drop_job(p_job_name => 'REFRESH_ACA_BACKUP_SETS');
      drop_job(p_job_name => 'REMOVE_TEMPORARY_JOBS');
      drop_job(p_job_name => 'SCAN_ALERT_LOG');
      drop_job(p_job_name => 'SCAN_TABLESPACE_USAGE');
      schedule_job(p_job_id => get_job_id(p_name => 'REFRESH_ACA_BACKUP_SETS'));
      schedule_job(p_job_id => get_job_id(p_name => 'REMOVE_TEMPORARY_JOBS'));
      schedule_job(p_job_id => get_job_id(p_name => 'SCAN_ALERT_LOG'));
      schedule_job(p_job_id => get_job_id(p_name => 'SCAN_TABLESPACE_USAGE'));
   END restart_internal_jobs;

   PROCEDURE import_help IS
      --
      -- Purpose: To import the online help.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  --------------------------------------------------
      -- GL Skillbuilders   01/06/2016  Creation
      -- GL Skillbuilders   01/20/2016  Modified for Windows
      -- GL Skillbuilders   01/26/2016  Added p_content
      --
      lv_template_name VARCHAR2(30) := 'IMPORT_HELP_TEMPLATE';
   BEGIN
      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         lv_template_name := 'WIN_IMPORT_HELP_TEMPLATE';
      END IF;
      aca_datapump_util.run_import(p_template_name => lv_template_name,
                                   p_name => 'IMPSBAHELP',
                                   p_description => 'SBA Help',
                                   p_datapump_type => 'IMPORT',
                                   p_datapump_directory => NULL,
                                   p_dump_file => 'SBAHELP.dmp',
                                   p_log_file => 'IMPSBAHELP-'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HH24-MI-SS')||'.log',
                                   p_parallel_threads => NULL,
                                   p_table_exists_action => 'TRUNCATE',
                                   p_content  => 'DATA_ONLY',
                                   p_encryption_pwd => NULL,
                                   p_datapump_mode => 'TABLE',
                                   p_schema => 'SBA',
                                   p_tables => 'SBH_HELP,SBH_PAGE_LINKS',
                                   p_remap_schema_to => aca_util.get_config_value(p_name => 'DB_USER'),
                                   p_remap_tablespace_from => 'USERS',
                                   p_remap_tablespace_to => aca_database_util.get_users_default_tablespace
                                   (aca_util.get_config_value(p_name => 'DB_USER')));
   END import_help;

   PROCEDURE set_rman_configuration(p_dummy IN VARCHAR2 DEFAULT NULL) IS
      --
      -- Purpose: To set RMAN configuration.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  --------------------------------------------------
      -- GL Skillbuilders   01/13/2016  Creation
      --
   BEGIN
      IF aca_util.get_config_value(p_name => 'OS_TYPE') = 'UNIX' THEN
         aca_util.run_os_command(p_command => aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY')||'/RMANsetConfig.sh '||
                                              aca_util.get_config_value(p_name => 'OS_HOME_DIRECTORY')||' '||
                                              aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY'),
                                 p_credential_name => aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME'));
      ELSIF aca_util.get_config_value(p_name => 'OS_TYPE') = 'WINDOWS' THEN
         aca_util.run_os_command(p_command => aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY')||'\RMANsetConfig.bat '||
                                              aca_util.get_config_value(p_name => 'WIN_PROGRAMS_PATH')||' '||
                                              aca_util.get_config_value(p_name => 'OS_SCRIPTS_DIRECTORY')||' '||
                                              aca_util.get_oracle_home||' '||
                                              aca_util.get_oracle_sid,
                                 p_credential_name => aca_util.get_config_value(p_name => 'OS_CREDENTIAL_NAME'));
      END IF;
   END set_rman_configuration;

   PROCEDURE post_installation(p_apex_workspace IN VARCHAR2,
                               p_app_identifier IN VARCHAR2,
                               p_app_email_from IN VARCHAR2,
                               p_sysadmin_password IN VARCHAR2,
                               p_os_type IN VARCHAR2,
                               p_win_programs_path IN VARCHAR2,
                               p_os_user IN VARCHAR2,
                               p_os_password IN VARCHAR2,
                               p_os_home_directory IN VARCHAR2,
                               p_os_scripts_directory IN VARCHAR2,
                               p_os_log_directory IN VARCHAR2,
                               p_os_apex_directory IN VARCHAR2,
                               p_data_pump_directory_path IN VARCHAR2,
                               p_db_edition IN VARCHAR2,
                               p_oracle_home IN VARCHAR2,
                               p_db_host IN VARCHAR2,
                               p_db_port IN VARCHAR2,
                               p_db_service_name IN VARCHAR2,
                               p_db_user IN VARCHAR2,
                               p_db_password IN VARCHAR2,
                               p_media_manager IN VARCHAR2,
                               p_asm IN VARCHAR2,
                               p_asm_hostname IN VARCHAR2,
                               p_asm_port IN VARCHAR2,
                               p_asm_sid IN VARCHAR2,
                               p_sysasm_user IN VARCHAR2,
                               p_sysasm_password IN VARCHAR2) IS
      --
      -- Purpose: To set configuration and initialize the application.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  --------------------------------------------------
      -- GL Skillbuilders   07/05/2015  Creation
      -- GL Skillbuilders   08/28/2015  Changed to ignore existing entry in aca_directories
      -- GL Skillbuilders   10/06/2015  Added License Key
      -- GL Skillbuilders   11/10/2015  Removed reference to aca_directories
      -- GL Skillbuilders   12/08/2015  Added p_os_apex_directory
      -- GL Skillbuilders   12/09/2015  Added call to restart_internal_jobs
      -- GL Skillbuilders   01/06/2016  Added Import Help
      -- GL Skillbuilders   01/13/2016  Added set_rman_configuration
      -- GL Skillbuilders   01/25/2016  Added p_win_programs_path
      -- GL Skillbuilders   01/30/2016  Added p_oracle_home
      -- GL Skillbuilders   01/05/2017  Removed LICENSE_KEY
      -- GL Skillbuilders   02/21/2019  Added p_db_host, p_db_port and p_db_service_name
      --
   BEGIN

      -- Set configuration values
      set_config_value(p_name => 'APEX_WORKSPACE', p_value => p_apex_workspace);
      set_config_value(p_name => 'APP_IDENTIFIER', p_value => p_app_identifier);
      set_config_value(p_name => 'APP_EMAIL_FROM', p_value => p_app_email_from);
      set_config_value(p_name => 'OS_TYPE', p_value => p_os_type);
      set_config_value(p_name => 'OS_USER', p_value => p_os_user);
      set_config_value(p_name => 'OS_PASSWORD', p_value => p_os_password);
      set_config_value(p_name => 'OS_HOME_DIRECTORY', p_value => p_os_home_directory);
      set_config_value(p_name => 'OS_SCRIPTS_DIRECTORY', p_value => p_os_scripts_directory);
      set_config_value(p_name => 'OS_LOG_DIRECTORY', p_value => p_os_log_directory);
      set_config_value(p_name => 'OS_APEX_DIRECTORY', p_value => p_os_apex_directory);
      set_config_value(p_name => 'DATA_PUMP_DIRECTORY_PATH', p_value => p_data_pump_directory_path);
      set_config_value(p_name => 'DB_EDITION', p_value => p_db_edition);
      set_config_value(p_name => 'ORACLE_HOME', p_value => p_oracle_home);
      set_config_value(p_name => 'DB_HOST', p_value => p_db_host);
      set_config_value(p_name => 'DB_PORT', p_value => p_db_port);
      set_config_value(p_name => 'DB_SERVICE_NAME', p_value => p_db_service_name);
      set_config_value(p_name => 'DB_USER', p_value => p_db_user);
      set_config_value(p_name => 'DB_PASSWORD', p_value => p_db_password);
      set_config_value(p_name => 'MEDIA_MANAGER', p_value => p_media_manager);
      set_config_value(p_name => 'ASM', p_value => p_asm);
      set_config_value(p_name => 'ASM_HOSTNAME', p_value => p_asm_hostname);
      set_config_value(p_name => 'ASM_PORT', p_value => p_asm_port);
      set_config_value(p_name => 'ASM_SID', p_value => p_asm_sid);
      set_config_value(p_name => 'ASM_SYSASM_USER', p_value => p_sysasm_user);
      set_config_value(p_name => 'ASM_SYSASM_PASSWORD', p_value => p_sysasm_password);
      set_config_value(p_name => 'WIN_PROGRAMS_PATH', p_value => p_win_programs_path);

      -- Set SYSADMIN password
      sec_util.set_password(p_username => 'SYSADMIN', p_password => p_sysadmin_password);

      -- Create credential
      IF NOT credential_exists(p_credential_name => 'OS_USER') THEN
         DBMS_SCHEDULER.CREATE_CREDENTIAL(credential_name => 'OS_USER',
                                          username => p_os_user,
                                          password => p_os_password);
      END IF;

      -- Save configuration if something fails later
      COMMIT;

      -- Create SBA data pump directory
      aca_database_util.create_app_datapump_dir;

      -- Set RMAN Configuration
      set_rman_configuration;

      -- Import Help
      import_help;

      -- Clear all logs
      DELETE FROM aca_alert_log;
      DELETE FROM aca_application_errors;
      DELETE FROM aca_job_log;
      DELETE FROM aca_system_alerts;
      DELETE FROM aca_system_alerts_log;
      COMMIT;

      -- Start internal jobs
      restart_internal_jobs;

      -- Clear selected logs
      DELETE FROM aca_alert_log;
      DELETE FROM aca_application_errors;
      DELETE FROM aca_system_alerts;
      DELETE FROM aca_system_alerts_log;
      COMMIT;

      -- Set installation complete
      UPDATE aca_configuration SET value = 'YES'
      WHERE NAME = 'INSTALLATION_COMPLETE';

      COMMIT;

   END post_installation;

   FUNCTION get_db_services RETURN list_collection_type PIPELINED IS
      --
      -- Purpose: To get a result set of the available DB services.
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/02/2016  Creation
      --
       list_array APEX_APPLICATION_GLOBAL.VC_ARR2;
       lv_services VARCHAR(4000);
   BEGIN
      BEGIN
         SELECT value INTO lv_services FROM v$parameter WHERE NAME = 'service_names';
      EXCEPTION
         WHEN NO_DATA_FOUND THEN NULL;
      END;
      list_array := APEX_UTIL.STRING_TO_TABLE(lv_services, ',');
      FOR i IN 1..list_array.COUNT LOOP
         PIPE ROW (TRIM(list_array(i)));
      END LOOP;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DB_SERVICES', p_error_text => SQLERRM);
      RAISE;
   END get_db_services;

   FUNCTION get_oracle_sid RETURN VARCHAR2 IS
      --
      -- Purpose: To get the ORACLE_SID
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/13/2016  Creation
      --
       lv_name VARCHAR(4000);
   BEGIN
      SELECT name INTO lv_name FROM v$database;
      RETURN lv_name;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_DB_SID', p_error_text => SQLERRM);
      RAISE;
   END get_oracle_sid;

   FUNCTION get_oracle_home RETURN VARCHAR2 IS
      --
      -- Purpose: To get the ORACLE_HOME
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/13/2016  Creation
      -- GL Skillbuilders   01/30/2016  Added ORACLE_HOME for 11g
      --
       lv_home VARCHAR(4000);
   BEGIN
      IF get_db_version > 11 THEN
         SELECT SYS_CONTEXT('userenv','oracle_home') INTO lv_home from dual;
      ELSE
         lv_home := aca_util.get_config_value(p_name => 'ORACLE_HOME');
      END IF;
      RETURN lv_home;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_ORACLE_HOME', p_error_text => SQLERRM);
      RAISE;
   END get_oracle_home;

   FUNCTION get_os_type RETURN VARCHAR2 IS
      --
      -- Purpose: To get the OS type
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/21/2016  Creation
      --
       lv_port_string VARCHAR(4000);
   BEGIN
      SELECT DBMS_UTILITY.PORT_STRING INTO lv_port_string FROM DUAL;
      IF UPPER(lv_port_string) LIKE '%WIN%' THEN
         RETURN 'WINDOWS';
      ELSE
         RETURN 'UNIX';
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.GET_OS_TYPE', p_error_text => SQLERRM);
      RAISE;
   END get_os_type;

   PROCEDURE send_notification(p_to IN VARCHAR2,
                               p_subject IN VARCHAR2,
                               p_message IN VARCHAR2) IS
      --
      -- Purpose: To send an email notification
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   01/30/2017  Creation
      -- GL Skillbuilders   03/23/2017  Added line break to lv_message_html
      --
      crlf VARCHAR2(2) := '
';
      lv_workspace_id NUMBER;
      lv_message_html VARCHAR2(32000) := REPLACE(p_message, crlf, '<br/>');
      lv_body VARCHAR2(32000) := '
SkillBuilders Oracle Database Manager
Installation ID: '||aca_util.get_config_value(p_name => 'APP_IDENTIFIER')||'
Date: '||TO_CHAR(SYSDATE, 'Day, Month DD, YYYY')||'
Time: '||TO_CHAR(SYSDATE, 'HH:MI AM')||'
Notification:
'||p_message||'
';
      lv_body_html VARCHAR2(32000) := '
<!DOCTYPE html>
<html>
   <head>
      <title>Skillbuilders Oracle Database Manager</title>
   </head>
   <body style="width:80%;margin-left:auto;margin-right:auto;">
      <table style="width:100%;">
         <tr style="background-color: #00426A;">
            <td style="text-align:center;vertical-align:middle;padding:10px;">
               <span style="font-family:Arial;font-size:24pt;color:white;">SkillBuilders</span>
            </td>
         </tr>
         <tr style="background-color: #00426A;">
            <td style="text-align:center;vertical-align:middle;padding:10px;">
               <span style="font-family:Arial;font-size:18pt;color:white;">Oracle Database Manager</span>
            </td>
         </tr>
         <tr>
            <td style="padding:10px;">
               <table>
                  <tr>
                     <td style="vertical-align:top;text-align:right;font-family:Arial;font-size:12pt;color:#00426A;">Installation&nbsp;ID: </td>
                     <td style="vertical-align:top;text-align:left;font-family:Arial;font-size:12pt;color:#00426A;">'||aca_util.get_config_value(p_name => 'APP_IDENTIFIER')||'</td>
                  </tr>
                  <tr>
                     <td style="vertical-align:top;text-align:right;font-family:Arial;font-size:12pt;color:#00426A;">Date: </td>
                     <td style="vertical-align:top;text-align:left;font-family:Arial;font-size:12pt;color:#00426A;">'||TO_CHAR(SYSDATE, 'Day, Month DD, YYYY')||'</td>
                  </tr>
                  <tr>
                     <td style="vertical-align:top;text-align:right;font-family:Arial;font-size:12pt;color:#00426A;">Time: </td>
                     <td style="vertical-align:top;text-align:left;font-family:Arial;font-size:12pt;color:#00426A;">'||TO_CHAR(SYSDATE, 'HH:MI AM')||'</td>
                  </tr>
                  <tr>
                     <td colspan="2" style="vertical-align:top;text-align:left;font-family:Arial;font-size:12pt;color:#00426A;">Notification: </td>
                  </tr>
                  <tr>
                     <td colspan="2" style="vertical-align:top;text-align:left;font-family:Arial;font-size:12pt;color:#00426A;">'||lv_message_html||'</td>
                  </tr>
               </table>
            </td>
         </tr>
         <tr style="background-color: #00426A;">
            <td style="text-align:center;vertical-align:middle;padding:10px;">
               <span style="font-family:Arial;font-size:8pt;color:white;">Oracle APEX Development - Oracle APEX Hosting - Oracle Database Administration - Oracle Cloud Administration - Oracle Training</span>
            </td>
         </tr>
         <tr style="background-color: #00426A;">
            <td style="text-align:center;vertical-align:middle;padding:10px;">
               <a target="_blank" href="http://www.skillbuilders.com"><span style="font-family:Arial;font-size:12pt;color:white;">www.skillbuilders.com</span></a>
            </td>
         </tr>
      </table>
   </body>
</html>
';
   BEGIN
      SELECT workspace_id INTO lv_workspace_id
        FROM apex_workspaces
       WHERE workspace = aca_util.get_config_value(p_name => 'APEX_WORKSPACE');

      APEX_UTIL.SET_SECURITY_GROUP_ID(lv_workspace_id);
      APEX_MAIL.SEND(p_to        => p_to,
                     p_from      => aca_util.get_config_value(p_name => 'APP_EMAIL_FROM'),
                     p_body      => lv_body,
                     p_body_html => lv_body_html,
                     p_subj      => 'SkillBuilders ODM - '||
                                    aca_util.get_config_value(p_name => 'APP_IDENTIFIER')||' - '||p_subject);
      APEX_MAIL.PUSH_QUEUE;

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'ACA_UTIL.SEND_NOTIFICATION', p_error_text => SQLERRM);
      RAISE;
   END send_notification;

END aca_util;
/


CREATE OR REPLACE PACKAGE BODY SBH_HELP_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: This package provides all the utilities for APEX module SBH
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/02/2015  Creation
   --

   PROCEDURE show_text(p_help_id IN NUMBER) IS
   --
   -- Purpose: Show help text
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/02/2015  Creation
   --
      CURSOR c1 IS
      SELECT text
        FROM sbh_help
       WHERE id = p_help_id;
      lv_text VARCHAR2(32000);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_text;
      CLOSE c1;
      HTP.P(lv_text);
   END show_text;

   PROCEDURE show_url(p_help_id IN NUMBER) IS
   --
   -- Purpose: Show help URL
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/05/2015  Creation
   --
      CURSOR c1 IS
      SELECT *
        FROM sbh_help
       WHERE id = p_help_id;
      r1 c1%ROWTYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO r1;
      CLOSE c1;
      HTP.P('<p>The page linked here is external to the application and will be shown in a new window or tab.</p>');
      HTP.P('<p><strong><a target="_blank" href="'||r1.external_url||'">'||r1.title||'</a></strong></p>');
   END show_url;

   FUNCTION get_help_id(p_page_id IN NUMBER) RETURN NUMBER IS
   --
   -- Purpose: To get the help topic id for a given page
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/02/2015  Creation
   -- GL Skillbuilders   01/16/2017  Added check for enabled and auth_scheme
   --
      CURSOR c1 IS
      SELECT help_id
        FROM sbh_page_links
       WHERE id = p_page_id
         AND help_id IS NOT NULL;
      lv_help_id NUMBER := 0;
      CURSOR c2 IS
      SELECT enabled
        FROM sbh_help
       WHERE id = lv_help_id
         AND (sec_util.user_in_role2(p_username => V('APP_USER'), p_role => auth_scheme) = 'YES' OR auth_scheme IS NULL);
      lv_enabled sbh_help.enabled%TYPE := 'NO';
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_help_id;
      CLOSE c1;
      OPEN c2;
         FETCH c2 INTO lv_enabled;
      CLOSE c2;
      IF lv_enabled = 'NO' THEN
         lv_help_id := 0;
      END IF;
      RETURN lv_help_id;
   END get_help_id;

   FUNCTION get_title(p_help_id IN NUMBER) RETURN VARCHAR2 IS
   --
   -- Purpose: Get help text title
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/02/2015  Creation
   --
      CURSOR c1 IS
      SELECT title
        FROM sbh_help
       WHERE id = p_help_id;
      lv_title sbh_help.title%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_title;
      CLOSE c1;
      RETURN lv_title;
   END get_title;

   FUNCTION get_object_type(p_help_id IN NUMBER) RETURN VARCHAR2 IS
   --
   -- Purpose: Get help type
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/05/2015  Creation
   --
      CURSOR c1 IS
      SELECT object_type
        FROM sbh_help
       WHERE id = p_help_id;
      lv_object_type sbh_help.object_type%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_object_type;
      CLOSE c1;
      RETURN lv_object_type;
   END get_object_type;

END sbh_help_util;
/


CREATE OR REPLACE PACKAGE BODY SB_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: This package provides productivity utilities
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/23/2014  Creation
   --
   PROCEDURE create_table(p_app_short_name IN VARCHAR2,
                          p_table_name IN VARCHAR2,
                          p_table_short_name IN VARCHAR2,
                          p_primary_key_name IN VARCHAR2 DEFAULT 'ID',
                          p_primary_key_length IN NUMBER,
                          p_natural_key_name IN VARCHAR2 DEFAULT 'NAME',
                          p_natural_key_length IN NUMBER DEFAULT 80) IS
   --
   -- Purpose: To create a basic table and associated sequence.
   --   Usage: 1. Create a table.
   --          2. Import it into SQL Developer Data Modeler.
   --          3. Add additional columns, indexes and constraints etc
   --          4. Generate the DDL
   --          5. Drop the table
   --          6. Run the DDL
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/23/2014  Creation
   --
   BEGIN

      -- SEQUENCE

      EXECUTE IMMEDIATE '
CREATE SEQUENCE '||p_app_short_name||'_'||p_table_short_name||'_pk_seq
       INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE '||LPAD('9', p_primary_key_length, '9')||'
       NOCYCLE
       ORDER
       NOCACHE
';

      -- TABLE

      EXECUTE IMMEDIATE '
CREATE TABLE '||p_app_short_name||'_'||p_table_name||'
    (
     '||p_primary_key_name||' NUMBER ('||TO_CHAR(p_primary_key_length)||')  NOT NULL ,
     '||p_natural_key_name||' VARCHAR2 ('||TO_CHAR(p_natural_key_length)||')  NOT NULL ,
     DESCRIPTION VARCHAR2(4000) ,
     ENABLED VARCHAR2(3) DEFAULT ''YES''  NOT NULL ,
     NOTES VARCHAR2(4000) ,
     ORDER_SEQUENCE NUMBER ('||TO_CHAR(p_primary_key_length)||') ,
     CREATED_BY VARCHAR2(80)  NOT NULL ,
     CREATION_DATE DATE NOT NULL ,
     MODIFIED_BY VARCHAR2(80)  NOT NULL ,
     MODIFICATION_DATE DATE  NOT NULL
    )
';

      -- INDEXES

      EXECUTE IMMEDIATE '
CREATE UNIQUE INDEX '||p_app_short_name||'_'||p_table_short_name||'_PK_IDX ON '||p_app_short_name||'_'||p_table_name||'
    (
     '||p_primary_key_name||'
    )
';

      EXECUTE IMMEDIATE '
CREATE UNIQUE INDEX '||p_app_short_name||'_'||p_table_short_name||'_'||p_natural_key_name||'_UK_IDX ON '||p_app_short_name||'_'||p_table_name||'
    (
     '||p_natural_key_name||'
    )
';

      -- CONSTRAINTS

      EXECUTE IMMEDIATE '
ALTER TABLE '||p_app_short_name||'_'||p_table_name||'
    ADD CONSTRAINT '||p_app_short_name||'_'||p_table_short_name||'_PK PRIMARY KEY ('||p_primary_key_name||')
';

      EXECUTE IMMEDIATE '
ALTER TABLE '||p_app_short_name||'_'||p_table_name||'
    ADD CONSTRAINT '||p_app_short_name||'_'||p_table_short_name||'_'||p_natural_key_name||'_UK UNIQUE ('||p_natural_key_name||')
';

      EXECUTE IMMEDIATE '
ALTER TABLE '||p_app_short_name||'_'||p_table_name||'
    ADD CONSTRAINT '||p_app_short_name||'_'||p_table_short_name||'_ENABLED_CHK CHECK ( ENABLED IN (''NO'', ''YES''))
';

      -- TRIGGER

      EXECUTE IMMEDIATE '
CREATE OR REPLACE TRIGGER '||p_app_short_name||'_'||p_table_short_name||'_BIU_TRG
    BEFORE INSERT OR UPDATE ON '||p_app_short_name||'_'||p_table_name||'
    FOR EACH ROW
BEGIN
   IF INSERTING THEN
      IF :NEW.'||p_primary_key_name||' IS NULL THEN
         SELECT '||p_app_short_name||'_'||p_table_short_name||'_pk_seq.NEXTVAL INTO :NEW.'||p_primary_key_name||' FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := ''YES'';
      END IF;
      :NEW.created_by := NVL(V(''APP_USER''), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V(''APP_USER''), USER);
   :NEW.modification_date := SYSDATE;
END;
';

   END create_table;

   PROCEDURE create_intersect_table(p_app_short_name IN VARCHAR2,
                                    p_table_name IN VARCHAR2,
                                    p_table_short_name IN VARCHAR2,
                                    p_primary_key_name IN VARCHAR2,
                                    p_primary_key_length IN NUMBER,
                                    p_foreign_key1_name IN VARCHAR2,
                                    p_foreign_key1_length IN NUMBER,
                                    p_foreign_key2_name IN VARCHAR2,
                                    p_foreign_key2_length IN NUMBER) IS
   --
   -- Purpose: To create a intersect table and associated sequence.
   --   Usage: 1. Create a table.
   --          2. Import it into SQL Developer Data Modeler.
   --          3. Add additional columns, indexes and constraints etc
   --          4. Generate the DDL
   --          5. Drop the table
   --          6. Run the DDL
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/23/2014  Creation
   --
   BEGIN

      -- SEQUENCE

      EXECUTE IMMEDIATE '
CREATE SEQUENCE '||p_app_short_name||'_'||p_table_short_name||'_pk_seq
       INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE '||LPAD('9', p_primary_key_length, '9')||'
       NOCYCLE
       ORDER
       NOCACHE
';

      -- TABLE

      EXECUTE IMMEDIATE '
CREATE TABLE '||p_app_short_name||'_'||p_table_name||'
    (
     '||p_primary_key_name||'  NUMBER ('||TO_CHAR(p_primary_key_length)||')   NOT NULL ,
     '||p_foreign_key1_name||' NUMBER ('||TO_CHAR(p_foreign_key1_length)||')  NOT NULL ,
     '||p_foreign_key2_name||' NUMBER ('||TO_CHAR(p_foreign_key2_length)||')  NOT NULL ,
     ENABLED VARCHAR2(3) DEFAULT ''YES''  NOT NULL ,
     NOTES VARCHAR2(4000) ,
     ORDER_SEQUENCE NUMBER ('||TO_CHAR(p_primary_key_length)||') ,
     CREATED_BY VARCHAR2(80)  NOT NULL ,
     CREATION_DATE DATE NOT NULL ,
     MODIFIED_BY VARCHAR2(80)  NOT NULL ,
     MODIFICATION_DATE DATE  NOT NULL
    )
';

      -- INDEXES

      EXECUTE IMMEDIATE '
CREATE UNIQUE INDEX '||p_app_short_name||'_'||p_table_short_name||'_PK_IDX ON '||p_app_short_name||'_'||p_table_name||'
    (
     '||p_primary_key_name||'
    )
';

      EXECUTE IMMEDIATE '
CREATE UNIQUE INDEX '||p_app_short_name||'_'||p_table_short_name||'_UK_IDX ON '||p_app_short_name||'_'||p_table_name||'
    (
     '||p_foreign_key1_name||','||p_foreign_key2_name||'
    )
';

      -- CONSTRAINTS

      EXECUTE IMMEDIATE '
ALTER TABLE '||p_app_short_name||'_'||p_table_name||'
    ADD CONSTRAINT '||p_app_short_name||'_'||p_table_short_name||'_PK PRIMARY KEY ('||p_primary_key_name||')
';

      EXECUTE IMMEDIATE '
ALTER TABLE '||p_app_short_name||'_'||p_table_name||'
    ADD CONSTRAINT '||p_app_short_name||'_'||p_table_short_name||'_UK UNIQUE ('||p_foreign_key1_name||','||p_foreign_key2_name||')
';

      EXECUTE IMMEDIATE '
ALTER TABLE '||p_app_short_name||'_'||p_table_name||'
    ADD CONSTRAINT '||p_app_short_name||'_'||p_table_short_name||'_ENABLED_CHK CHECK ( ENABLED IN (''NO'', ''YES''))
';

      -- TRIGGER

      EXECUTE IMMEDIATE '
CREATE OR REPLACE TRIGGER '||p_app_short_name||'_'||p_table_short_name||'_BIU_TRG
    BEFORE INSERT OR UPDATE ON '||p_app_short_name||'_'||p_table_name||'
    FOR EACH ROW
BEGIN
   IF INSERTING THEN
      IF :NEW.'||p_primary_key_name||' IS NULL THEN
         SELECT '||p_app_short_name||'_'||p_table_short_name||'_pk_seq.NEXTVAL INTO :NEW.'||p_primary_key_name||' FROM DUAL;
      END IF;
      IF :NEW.enabled IS NULL THEN
         :NEW.enabled := ''YES'';
      END IF;
      :NEW.created_by := NVL(V(''APP_USER''), USER);
      :NEW.creation_date := SYSDATE;
   END IF;
   :NEW.modified_by := NVL(V(''APP_USER''), USER);
   :NEW.modification_date := SYSDATE;
END;
';

   END create_intersect_table;

   PROCEDURE drop_all_objects(p_app_short_name IN VARCHAR2) IS
   --
   -- Purpose: To drop all objects beginning with p_app_short_name
   --
   --    NOTE: DO NOT RUN THIS UNLESS YOU KNOW WHAT YOU ARE DOING!
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/23/2014  Creation
   --
      CURSOR c1 IS
      SELECT 'ALTER TABLE '||table_name||' DROP CONSTRAINT '||constraint_name ddl_statement
        FROM user_constraints
       WHERE constraint_name LIKE UPPER(p_app_short_name)||'\_%' ESCAPE '\'
         AND constraint_type = 'R';

      CURSOR c2 IS
      SELECT 'DROP '||object_type||' '||object_name ddl_statement
        FROM user_objects
       WHERE object_name LIKE UPPER(p_app_short_name)||'\_%' ESCAPE '\'
         AND object_type IN ('VIEW', 'PROCEDURE', 'FUNCTION', 'PACKAGE', 'TABLE', 'SEQUENCE', 'TYPE')
       ORDER BY DECODE(object_type, 'VIEW', 5,
                                    'PROCEDURE', 1,
                                    'FUNCTION', 2,
                                    'PACKAGE', 3,
                                    'TABLE', 4,
                                    'SEQUENCE', 6,
                                    'TYPE', 7, 8),object_name;

   BEGIN
      -- Drop all foreign key constraints
      FOR r1 IN c1 LOOP
         EXECUTE IMMEDIATE r1.ddl_statement;
      END LOOP;
      -- Drop all schema objects
      FOR r2 IN c2 LOOP
         EXECUTE IMMEDIATE r2.ddl_statement;
      END LOOP;
   END drop_all_objects;

END SB_UTIL;
/


CREATE OR REPLACE PACKAGE BODY SEC_UTIL IS
   --
   -- Copyright 2015 2016 2017 SkillBuilders Inc.
   --
   -- Purpose: To provide all the utilities for the APEX application module SEC
   --
   -- MODIFICATION HISTORY
   -- Person             Date        Comments
   -- ----------------   ----------  ------------------------------------------
   -- GL Skillbuilders   03/23/2014  Creation
   --

   gv_process VARCHAR2(4000);

   FUNCTION custom_hash(p_username IN VARCHAR2, p_password IN VARCHAR2) RETURN VARCHAR2 IS
   --
   -- Purpose: To hash the users password
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person              Date        Comments
   -- ------------------  ----------  ------------------------------------------
   -- GL - Skillbuilders  03/23/2014  Creation
   --
      lv_password_hash sec_users.password_hash%TYPE;
      lv_salt VARCHAR2(30) := 'ANOVJRN6I8FB4LRWEFVHQI9Y4ZEW8A';
   BEGIN
      lv_password_hash :=
      UTL_RAW.CAST_TO_RAW(DBMS_OBFUSCATION_TOOLKIT.MD5
                         (input_string => p_password||SUBSTR(lv_salt, 10, 13)||UPPER(p_username)||SUBSTR(lv_salt, 4, 10)));
      RETURN lv_password_hash;
   END custom_hash;

   PROCEDURE set_password(p_username IN VARCHAR2, p_password IN VARCHAR2) IS
   --
   -- Purpose: To set the user's password hash.
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person              Date        Comments
   -- ------------------  ----------  ------------------------------------------
   -- GL - Skillbuilders  03/23/2014  Creation
   --
      lv_password_hash sec_users.password_hash%TYPE := custom_hash(p_username => UPPER(p_username), p_password => p_password);
   BEGIN
      UPDATE sec_users SET password_hash = lv_password_hash
       WHERE UPPER(username) = UPPER(p_username);
   END set_password;

   FUNCTION custom_auth(p_username IN VARCHAR2, p_password IN VARCHAR2) RETURN BOOLEAN IS
   --
   -- Purpose: To provide custom authentication
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person              Date        Comments
   -- ------------------  ----------  ------------------------------------------
   -- GL - Skillbuilders  03/23/2014  Creation
   --
      CURSOR c1 IS
      SELECT password_hash
        FROM sec_users
       WHERE enabled = 'YES'
         AND UPPER(username) = UPPER(p_username);
      lv_stored_hash sec_users.password_hash%TYPE;
      lv_password_hash sec_users.password_hash%TYPE := custom_hash(UPPER(p_username), p_password);
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_stored_hash;
      CLOSE c1;
      IF lv_stored_hash IS NOT NULL THEN
         IF lv_password_hash = lv_stored_hash THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      ELSE
         RETURN FALSE;
      END IF;
   END custom_auth;

   FUNCTION gen_password(p_chars_chr NUMBER DEFAULT 5,
                         p_chars_num NUMBER DEFAULT 2,
                         p_chars_spc NUMBER DEFAULT 0) RETURN VARCHAR2 IS
   --
   -- Purpose: To generate a random password e.g. forgotten password
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person           Date        Comments
   -- ---------------  ----------  ------------------------------------------
   -- GL               03/23/2014  Created. Orginal by Stefan Moeding
   -- -----------------------------------------------------------------------
   --
   -- Copyright (c) 2011 Stefan Moeding, http://www.moeding.net/
   -- All rights reserved.
   --
   -- Redistribution and use in source and binary forms, with or without
   -- modification, are permitted provided that the following conditions
   -- are met:
   -- 1. Redistributions of source code must retain the above copyright
   --    notice, this list of conditions and the following disclaimer.
   -- 2. Redistributions in binary form must reproduce the above copyright
   --    notice, this list of conditions and the following disclaimer in the
   --    documentation and/or other materials provided with the distribution.
   --
   -- THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND
   -- ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   -- IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   -- ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
   -- FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
   -- DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
   -- OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
   -- HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
   -- LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   -- OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   -- SUCH DAMAGE.
   --
   -- gen_password - Generate a reasonably secure password
   --
   -- Parameter:
   -- p_chars_chr : number of alpha characters in the password
   -- p_chars_num : number of numeric characters in the password
   -- p_chars_spc : number of special characters in the password
   --
   -- Valid ranges are between 0 and 20 for every input parameter.
   -- Characters that get easily mixed up ('1' and 'l' or 'I',
   -- '0' and 'O', ...) are left out.
   --
   -- Example usage:
   -- SQL> select gen_password() from dual;
   --
   -- GEN_PASSWORD()
   -- ------------------------------------
   -- MXbjA6%4
   --
      lv_chr VARCHAR2(60) := 'bcdfhjkmnprstvwxyzBCDFGHJKLMNPQRSTVWXYZ';
      lv_num VARCHAR2(60) := '23456789';
      lv_spc VARCHAR2(60) := '!$%&/()=?+*#-@:<>';
      --
      lv_pwd VARCHAR2(60) := '';
      lv_sel VARCHAR2(60) := '';
   BEGIN
      --
      -- Raise an error if the input is out of sensible bounds
      --
      IF (p_chars_chr NOT BETWEEN 0 AND 20) OR
         (p_chars_num NOT BETWEEN 0 AND 20) OR
         (p_chars_spc NOT BETWEEN 0 AND 20) THEN
         RAISE value_error;
      END IF;
      --
      lv_sel := lv_sel||RPAD('a', p_chars_chr, 'a');
      lv_sel := lv_sel||RPAD('n', p_chars_num, 'n');
      lv_sel := lv_sel||RPAD('s', p_chars_spc, 's');
      --
      -- Loop over selector in random order and build the password by
      -- choosing a random character from the class denoted by the
      -- selector.
      --
      FOR rec IN (SELECT LEVEL
                    FROM DUAL
                 CONNECT BY LEVEL <= LENGTH(lv_sel)
                   ORDER BY DBMS_RANDOM.VALUE()) LOOP
         CASE SUBSTR(lv_sel, rec.LEVEL, 1)
            WHEN 'a' THEN
               lv_pwd := lv_pwd||SUBSTR(lv_chr, DBMS_RANDOM.VALUE(1, LENGTH(lv_chr)), 1);
            WHEN 'n' THEN
               lv_pwd := lv_pwd||SUBSTR(lv_num, DBMS_RANDOM.VALUE(1, LENGTH(lv_num)), 1);
            WHEN 's' THEN
               lv_pwd := lv_pwd||SUBSTR(lv_spc, DBMS_RANDOM.VALUE(1, LENGTH(lv_spc)), 1);
            ELSE
               NULL;
         END CASE;
      END LOOP;
      --
      RETURN lv_pwd;
      --
   END gen_password;

   FUNCTION get_user_id(p_username IN VARCHAR2) RETURN NUMBER IS
   --
   -- Purpose: To get the id from table SEC_USERS given the username
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person           Date        Comments
   -- ---------------  ----------  ------------------------------------------
   -- GL Skillbuilders  03/23/2014  Creation
   --
      CURSOR c1 IS
      SELECT id FROM sec_users
       WHERE UPPER(username) = UPPER(p_username);
      lv_id sec_users.id%TYPE;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_id;
      CLOSE c1;
      RETURN lv_id;
   END get_user_id;

   FUNCTION get_roles_granted(p_user_id IN NUMBER) RETURN VARCHAR2 IS
   --
   -- Purpose: To get roles granted for a given User
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person            Date        Comments
   -- ----------------  ----------  ------------------------------------------
   -- GL Skillbuilders  03/23/2014  Creation
   --
      CURSOR c1 IS
      SELECT TO_CHAR(role_id) AS role_id
        FROM sec_roles_granted
       WHERE user_id = p_user_id
       ORDER BY id DESC;
      lv_roles_granted VARCHAR2(32000);
   BEGIN
      FOR r1 IN c1 LOOP
         lv_roles_granted := ':'||r1.role_id||lv_roles_granted;
      END LOOP;
      RETURN SUBSTR(lv_roles_granted, 2);
   END get_roles_granted;

   PROCEDURE set_roles_granted(p_user_id IN NUMBER, p_roles_granted IN VARCHAR2) IS
   --
   -- Purpose: To set roles granted for a given User
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person            Date        Comments
   -- ----------------  ----------  ------------------------------------------
   -- GL Skillbuilders  03/23/2014  Creation
   -- GL Skillbuilders  08/28/2015  Changed to exclude role 0 (SYSADMIN) from delete.
   --
      roles_array APEX_APPLICATION_GLOBAL.VC_ARR2 := APEX_UTIL.STRING_TO_TABLE(p_roles_granted);
   BEGIN
      DELETE FROM sec_roles_granted
       WHERE user_id = p_user_id
         AND INSTR(':'||p_roles_granted||':', ':'||role_id||':') = 0
         AND role_id <> 0;
      FOR i IN 1..roles_array.COUNT LOOP
         BEGIN
            INSERT INTO sec_roles_granted(user_id, role_id)
            VALUES (p_user_id, TO_NUMBER(roles_array(i)));
         EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN NULL;
         END;
      END LOOP;
   END set_roles_granted;

   FUNCTION user_in_role(p_username IN VARCHAR2, p_role IN VARCHAR2) RETURN BOOLEAN IS
   --
   -- Purpose: To check if a user is in a given role.
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person            Date        Comments
   -- ----------------  ----------  ------------------------------------------------
   -- GL Skillbuilders  03/23/2014  Creation
   --
      CURSOR c1 IS
      SELECT 1
        FROM sec_roles_granted A, sec_users B, sec_roles C
       WHERE A.user_id = B.id
         AND A.role_id = C.id
         AND UPPER(B.username) = UPPER(p_username)
         AND UPPER(C.name) = UPPER(p_role);
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
   END user_in_role;

   FUNCTION user_in_role2(p_username IN VARCHAR2, p_role IN VARCHAR2) RETURN VARCHAR2 IS
   --
   -- Purpose: To check if a user is in a given role. Returns VARCHAR2.
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person            Date        Comments
   -- ----------------  ----------  ------------------------------------------------
   -- GL Skillbuilders  03/23/2014  Creation
   --
      CURSOR c1 IS
      SELECT 1
        FROM sec_roles_granted A, sec_users B, sec_roles C
       WHERE A.user_id = B.id
         AND A.role_id = C.id
         AND UPPER(B.username) = UPPER(p_username)
         AND UPPER(C.name) = UPPER(p_role);
      lv_found NUMBER(1) := 0;
   BEGIN
      OPEN c1;
         FETCH c1 INTO lv_found;
      CLOSE c1;
      IF lv_found = 1 THEN
         RETURN 'YES';
      ELSE
         RETURN 'NO';
      END IF;
   END user_in_role2;

   FUNCTION get_notification_users RETURN VARCHAR2 IS
   --
   -- Purpose: To get E-Mail addresses of users where notification is set to YES
   --   Usage: Application module: SEC
   --
   -- MODIFICATION HISTORY
   -- Person            Date        Comments
   -- ----------------  ----------  ------------------------------------------
   -- GL Skillbuilders  02/11/2015  Creation
   --
      CURSOR c1 IS
      SELECT email
        FROM sec_users
       WHERE notifications = 'YES'
       ORDER BY 1 DESC;
      lv_notification_users VARCHAR2(32000);
   BEGIN
      FOR r1 IN c1 LOOP
         lv_notification_users := ','||r1.email||lv_notification_users;
      END LOOP;
      RETURN SUBSTR(lv_notification_users, 2);
   END get_notification_users;

   PROCEDURE send_users_password(p_username IN VARCHAR2) IS
   --
   -- Purpose: To send a password to the email of the user given the username.
   --
   -- MODIFICATION HISTORY
   -- Person            Date        Comments
   -- ----------------  ----------  ------------------------------------------
   -- GL Skillbuilders  10/27/2015  Creation
   -- GL Skillbuilders  01/30/2017  Added call to aca_util.send_notification.
   --
      email_does_not_exist EXCEPTION;
      CURSOR c1 IS
      SELECT email
        FROM sec_users
       WHERE UPPER(username) = UPPER(p_username)
         AND enabled = 'YES';
      lv_email sec_users.email%TYPE;
      lv_password VARCHAR2(30) := gen_password();
      crlf VARCHAR2(2) := '
';
   BEGIN
      set_password(p_username => UPPER(p_username), p_password => lv_password);
      OPEN c1;
         FETCH c1 INTO lv_email;
      CLOSE c1;
      IF lv_email IS NULL THEN
         RAISE email_does_not_exist;
      END IF;
      aca_util.send_notification(p_to => lv_email,
                                 p_subject => 'User password reset',
                                 p_message => 'The password for user: '||UPPER(p_username)||' has been reset to '||lv_password||crlf||
                                              'Please change this password after logging in.');
   EXCEPTION
      WHEN email_does_not_exist THEN
         RAISE;
      WHEN OTHERS THEN
      aca_error_util.log_error(p_program_name => 'SEC_UTIL.SEND_USERS_PASSWORD', p_error_text => SQLERRM);
      RAISE;
   END send_users_password;

   PROCEDURE init IS
   --
   -- Purpose: Basic application initialization
   --   Usage: Application module: SEC
   --    Note:
   -- WARNING: DO NOT RUN THIS UNLESS YOU KNOW WHAT YOU ARE DOING.
   --
   -- MODIFICATION HISTORY
   -- Person              Date        Comments
   -- ------------------  ----------  ------------------------------------------
   -- GL - Skillbuilders  03/23/2014  Creation
   --
   BEGIN
      INSERT INTO sec_users (ID,USERNAME,PASSWORD_HASH,ENABLED,NOTES)
      VALUES(0,'SYSADMIN','6454316D8F5337E3662E07AFC67CE08D','YES','System Administrator');
      INSERT INTO sec_roles (ID,NAME,DESCRIPTION,ENABLED)
      VALUES(0,'SYSADMIN','System Administration','YES');
      INSERT INTO sec_roles (ID,NAME,DESCRIPTION,ENABLED)
      VALUES(1, 'ADMIN','Administration','YES');
      INSERT INTO sec_roles (ID,NAME,DESCRIPTION,ENABLED)
      VALUES(2, 'HELPADMIN','Help Administration','YES');
      INSERT INTO sec_roles_granted (ID,USER_ID,ROLE_ID,ENABLED)
      VALUES(0,0,0,'YES');
      INSERT INTO sec_roles_granted (USER_ID,ROLE_ID,ENABLED)
      VALUES(0,1,'YES');
      INSERT INTO sec_roles_granted (USER_ID,ROLE_ID,ENABLED)
      VALUES(0,2,'YES');
      COMMIT;
   END init;

END sec_util;
/

---

EXEC sec_util.init;

EXEC aca_install_util.init;

EXEC aca_util.init_scheduler_event_queue

COMMIT;

PROMPT End of Script

SPOOL OFF

EXIT