SPOOL SBODM210-CDB-USER.log

SET ECHO ON
SET VERIFY OFF
SET SQLBLANKLINES ON
SET DEFINE ON

WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK

PROMPT Creating CDB User IMPORTANT Username MUST begin with C##

CREATE USER &&USERNAME IDENTIFIED BY &&PASSWORD;

PROMPT Granting Roles

GRANT DBA TO &&USERNAME;

PROMPT Granting System Privileges

GRANT ALTER ANY INDEX TO &&USERNAME;
GRANT ALTER ANY PROCEDURE TO &&USERNAME;
GRANT ALTER ANY TABLE TO &&USERNAME;
GRANT ALTER ANY TRIGGER TO &&USERNAME;
GRANT ALTER DATABASE TO &&USERNAME;
GRANT ALTER SYSTEM TO &&USERNAME;
GRANT ALTER TABLESPACE TO &&USERNAME;
GRANT ALTER USER TO &&USERNAME;
GRANT CREATE ANY CONTEXT TO &&USERNAME;
GRANT CREATE ANY DIRECTORY TO &&USERNAME;
GRANT CREATE CLUSTER TO &&USERNAME;
GRANT CREATE DIMENSION TO &&USERNAME;
GRANT CREATE EXTERNAL JOB TO &&USERNAME;
GRANT CREATE INDEXTYPE TO &&USERNAME;
GRANT CREATE JOB TO &&USERNAME;
GRANT CREATE MATERIALIZED VIEW TO &&USERNAME;
GRANT CREATE OPERATOR TO &&USERNAME;
GRANT CREATE PROCEDURE TO &&USERNAME;
GRANT CREATE SEQUENCE TO &&USERNAME;
GRANT CREATE SESSION TO &&USERNAME;
GRANT CREATE SYNONYM TO &&USERNAME;
GRANT CREATE TABLE TO &&USERNAME;
GRANT CREATE TABLESPACE TO &&USERNAME;
GRANT CREATE TRIGGER TO &&USERNAME;
GRANT CREATE TYPE TO &&USERNAME;
GRANT CREATE USER TO &&USERNAME;
GRANT CREATE VIEW TO &&USERNAME;
GRANT CREATE DATABASE LINK TO &&USERNAME;
GRANT DROP ANY DIRECTORY TO &&USERNAME;
GRANT DROP TABLESPACE TO &&USERNAME;
GRANT GRANT ANY PRIVILEGE TO &&USERNAME;
GRANT GRANT ANY ROLE TO &&USERNAME;
GRANT ADVISOR TO &&USERNAME;

PROMPT Granting Object Privileges

GRANT SELECT ON DBA_DATA_FILES TO &&USERNAME;
GRANT SELECT ON DBA_DIRECTORIES TO &&USERNAME;
GRANT SELECT ON DBA_FREE_SPACE TO &&USERNAME;
GRANT SELECT ON DBA_ROLE_PRIVS TO &&USERNAME;
GRANT SELECT ON DBA_SCHEDULER_JOB_RUN_DETAILS TO &&USERNAME;
GRANT SELECT ON DBA_SCHEDULER_JOBS TO &&USERNAME;
GRANT SELECT ON DBA_SEGMENTS TO &&USERNAME;
GRANT SELECT ON DBA_SYS_PRIVS TO &&USERNAME;
GRANT SELECT ON DBA_TABLESPACES TO &&USERNAME;
GRANT SELECT ON DBA_TEMP_FILES TO &&USERNAME;
GRANT SELECT ON DBA_USERS TO &&USERNAME;
GRANT SELECT ON V_$ASM_DISKGROUP TO &&USERNAME;
GRANT SELECT ON V_$BACKUP_FILES TO &&USERNAME;
GRANT SELECT ON V_$BACKUP_PIECE_DETAILS TO &&USERNAME;
GRANT SELECT ON V_$BACKUP_SET TO &&USERNAME;
GRANT SELECT ON V_$DATABASE TO &&USERNAME;
GRANT SELECT ON V_$DATAFILE TO &&USERNAME;
GRANT SELECT ON V_$DIAG_ALERT_EXT TO &&USERNAME;
GRANT SELECT ON V_$DIAG_DIR_EXT TO &&USERNAME;
GRANT SELECT ON V_$INSTANCE TO &&USERNAME;
GRANT SELECT ON V_$OSSTAT TO &&USERNAME;
GRANT SELECT ON V_$PARAMETER TO &&USERNAME;
GRANT SELECT ON V_$RECOVERY_AREA_USAGE TO &&USERNAME;
GRANT SELECT ON V_$RMAN_CONFIGURATION TO &&USERNAME;
GRANT SELECT ON V_$TABLESPACE TO &&USERNAME;
GRANT SELECT ON V_$TEMPFILE TO &&USERNAME;
GRANT EXECUTE ON DBMS_AQ TO &&USERNAME;
GRANT EXECUTE ON DBMS_AQADM TO &&USERNAME;
GRANT EXECUTE ON DBMS_BACKUP_RESTORE TO &&USERNAME;
GRANT EXECUTE ON DBMS_LOCK TO &&USERNAME;
GRANT EXECUTE ON DBMS_SERVER_ALERT TO &&USERNAME;
GRANT EXECUTE ON DBMS_SCHEDULER TO &&USERNAME;
GRANT EXECUTE ON DBMS_RANDOM TO &&USERNAME;
GRANT EXECUTE ON UTL_FILE TO &&USERNAME;
GRANT EXECUTE ON DBMS_ADVISOR TO &&USERNAME;

-- PROMPT System Alert Queue

BEGIN
   -- Remove subscriber
   BEGIN
      DBMS_AQADM.REMOVE_SUBSCRIBER(queue_name=>'SYS.ALERT_QUE', subscriber => SYS.AQ$_AGENT('ALERTAGENT','',0));
   EXCEPTION
      WHEN OTHERS THEN NULL;
   END;
   -- Drop Agent
   BEGIN
      DBMS_AQADM.DROP_AQ_AGENT(agent_name=> 'ALERTAGENT');
   EXCEPTION
      WHEN OTHERS THEN NULL;
   END;
   -- create a queue agent
   DBMS_AQADM.CREATE_AQ_AGENT(agent_name => 'ALERTAGENT');
   -- subscribe to alert_que
   DBMS_AQADM.ADD_SUBSCRIBER(queue_name => 'SYS.ALERT_QUE', subscriber => SYS.AQ$_AGENT('ALERTAGENT','',0));
   -- associate schema user with the secure queue
   DBMS_AQADM.ENABLE_DB_ACCESS(agent_name => 'ALERTAGENT', db_username => '&&USERNAME');
   -- grant queue privilege NOTE: This has to be done as user SYS
   DBMS_AQADM.GRANT_QUEUE_PRIVILEGE(privilege => 'DEQUEUE',queue_name => 'SYS.ALERT_QUE',grantee => '&&USERNAME', grant_option => FALSE);
   -- register queue callback procedure
   DBMS_AQ.REGISTER(SYS.AQ$_REG_INFO_LIST(SYS.AQ$_REG_INFO('SYS.ALERT_QUE:ALERTAGENT',
                                                           DBMS_AQ.NAMESPACE_AQ,
                                                           'plsql://'||LOWER('&&USERNAME')||'.aca_dequeue_alert_event',
                                                           HEXTORAW('FF'))), 1 );
END;
/

COMMIT;

---------------------------------------------------------------------------------------------------------------------------------------------

PROMPT Loading SB-ODM CDB user objects.
ACCEPT DBHOST CHAR PROMPT 'Enter the database SQL*Net hostname or ip address >'
ACCEPT DBPORT CHAR PROMPT 'Enter the database SQL*Net port number >'
ACCEPT CDBSID CHAR PROMPT 'Enter the database SQL*Net CDB service name >'

CONNECT &&USERNAME/&&PASSWORD@&&DBHOST:&&DBPORT/&&CDBSID

CREATE SEQUENCE ACA_SAT_PK_SEQ 
    INCREMENT BY 1 
    MAXVALUE 999999999 
    MINVALUE 1 
    CYCLE 
    NOCACHE 
    ORDER 
;

CREATE TABLE ACA_SYSTEM_ALERTS 
    ( 
     ID            NUMBER (9)  NOT NULL , 
     MESSAGE_LEVEL VARCHAR2 (30 BYTE)  NOT NULL , 
     OBJECT_TYPE   VARCHAR2 (30 BYTE)  NOT NULL , 
     OBJECT_NAME   VARCHAR2 (30 BYTE)  NOT NULL , 
     REASON_ID     NUMBER  NOT NULL , 
     REASON        VARCHAR2 (4000 BYTE) , 
     CREATION_DATE DATE  NOT NULL 
    ) 
    LOGGING 
;


CREATE UNIQUE INDEX ACA_SAT_PK_IDX ON ACA_SYSTEM_ALERTS 
    ( 
     ID ASC 
    ) 
    LOGGING 
;

ALTER TABLE ACA_SYSTEM_ALERTS 
    ADD CONSTRAINT ACA_SAT_PK PRIMARY KEY ( ID ) 
    USING INDEX ACA_SAT_PK_IDX ;

CREATE TABLE ACA_SYSTEM_ALERTS_LOG 
    ( 
     ALERT_TIME   DATE , 
     MESSAGE      VARCHAR2 (4000 BYTE) , 
     MESSAGE_TYPE VARCHAR2 (100 BYTE) 
    ) 
    LOGGING 
;

CREATE OR REPLACE TRIGGER ACA_SAT_BIU_TRG 
    BEFORE INSERT OR UPDATE ON ACA_SYSTEM_ALERTS 
    FOR EACH ROW 
BEGIN
   IF INSERTING THEN
      IF :NEW.id IS NULL THEN
         SELECT aca_sat_pk_seq.NEXTVAL INTO :NEW.id FROM DUAL;
      END IF;
      :NEW.creation_date := SYSDATE;
   END IF;
END; 
/

PROMPT Loading SB-ODM objects for system alerts.
ACCEPT PDB_USER CHAR PROMPT 'Enter the database PDB username >'
ACCEPT PDB_PASSWORD CHAR PROMPT 'Enter the database PDB password >'
ACCEPT PDBSID CHAR PROMPT 'Enter the database PDB SQL*Net service name >'

CREATE DATABASE LINK dblink2pdb
CONNECT TO &&PDB_USER IDENTIFIED BY &&PDB_PASSWORD
USING '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=&&DBHOST)(PORT=&DBPORT))(CONNECT_DATA=(SERVICE_NAME=&&PDBSID)))';

CREATE OR REPLACE PROCEDURE ACA_DEQUEUE_ALERT_EVENT(context RAW,
                                                    reginfo SYS.AQ$_REG_INFO,
                                                    descr SYS.AQ$_DESCRIPTOR,
                                                    payload RAW,
                                                    payloadl NUMBER) IS

      --
      -- Copyright 2019 SkillBuilders Inc.
      --
      -- Purpose: To dequeue threshold alert events
      --
      -- MODIFICATION HISTORY
      -- Person             Date        Comments
      -- ----------------   ----------  ------------------------------------------
      -- GL Skillbuilders   02/27/2019  Creation.
      --

      dequeue_options DBMS_AQ.DEQUEUE_OPTIONS_T;
      message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
      message ALERT_TYPE;
      message_handle RAW(16);
      no_messages EXCEPTION;
      PRAGMA EXCEPTION_INIT(no_messages, -25228);
      lv_reason VARCHAR2(4000);
      lv_message VARCHAR2(32000);
      lv_mail_to VARCHAR2(32000);
      lv_message_level VARCHAR2(30);
      crlf VARCHAR2(2) := '
';
   BEGIN
      dequeue_options.msgid := descr.msg_id;
      dequeue_options.consumer_name := descr.consumer_name;
      DBMS_AQ.DEQUEUE(queue_name => 'SYS.ALERT_QUE',
                      dequeue_options => dequeue_options,
                      message_properties => message_properties,
                      payload => message,
                      msgid => message_handle);

      CASE
         WHEN message.message_level = 1  THEN lv_message_level := 'CRITICAL';
         WHEN message.message_level = 5  THEN lv_message_level := 'WARNING';
         WHEN message.message_level = 32 THEN lv_message_level := 'CLEAR';
      ELSE
         lv_message_level := 'UNKNOWN';
      END CASE;

      lv_reason := DBMS_SERVER_ALERT.EXPAND_MESSAGE(USERENV('LANGUAGE'), message.message_id,
                                                                         message.reason_argument_1,
                                                                         message.reason_argument_2,
                                                                         message.reason_argument_3,
                                                                         message.reason_argument_4,
                                                                         message.reason_argument_5);

      lv_message :=
      'Timestamp: '|| message.timestamp_originating||crlf||
      'Message Type: '||message.message_type||crlf||
      'Message Level: '||lv_message_level||crlf||
      'Reason ID: '||message.reason_id||crlf||
      'Reason: '||lv_reason||crlf||
      'Object Type: '||message.object_type||crlf||
      'Object Name: '||message.object_name;

      IF lv_message_level IN ('CRITICAL', 'WARNING') THEN
         INSERT INTO aca_system_alerts (message_level, object_type, object_name, reason_id, reason)
         VALUES (lv_message_level, message.object_type, message.object_name, message.reason_id, SUBSTR(lv_reason, 1, 4000));
      ELSIF lv_message_level = 'CLEAR' THEN
         DELETE FROM aca_system_alerts
          WHERE reason_id = message.reason_id
            AND object_type = message.object_type
            AND message.object_name = message.object_name;
      END IF;

      INSERT INTO aca_system_alerts_log (alert_time, message_type, message)
      VALUES (SYSDATE,
              message.message_type,
              lv_message);

      IF sec_util.get_notification_users@dblink2pdb IS NOT NULL THEN
         aca_util.send_notification@dblink2pdb(p_to => sec_util.get_notification_users@dblink2pdb,
                                               p_subject => 'ALERT - '||lv_message_level||' - '||SUBSTR(lv_reason, 1, 80),
                                               p_message => lv_message);
      END IF;

      COMMIT;

   EXCEPTION
      WHEN no_messages THEN
         INSERT INTO aca_system_alerts_log
         VALUES (SYSDATE, 'Notification', 'ALERT QUEUE EMPTY');
      WHEN OTHERS THEN
      aca_error_util.log_error@dblink2pdb(p_program_name => 'ACA_DEQUEUE_ALERT_EVENT@CDB', p_error_text => SQLERRM);
      RAISE;
   END aca_dequeue_alert_event;
/

SET DEFINE OFF

PROMPT End of Script

SPOOL OFF

EXIT